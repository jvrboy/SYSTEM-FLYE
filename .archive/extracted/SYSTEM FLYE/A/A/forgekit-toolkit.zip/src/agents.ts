import { runSandbox } from "./sandbox";
import type {
  AgentMemoryEntry,
  AgentMemoryStore,
  AgentPlan,
  AgentResult,
  AgentRole,
  AgentTask,
  CodingAgentOptions,
  CouncilOptions,
} from "./types";

export const AGENT_KNOWLEDGE: Record<AgentRole, string> = {
  arduino: "Arduino C/C++ sketches, boards, pins, serial communication, libraries, and embedded debugging patterns.",
  "raspberry-pi": "Raspberry Pi Linux, GPIO, Python, system services, device interfaces, networking, and hardware debugging patterns.",
  csharp: "C# language, .NET application structure, async code, testing, diagnostics, and common project conventions.",
  yaml: "YAML syntax, schemas, CI/CD configuration, Kubernetes-style manifests, validation, and safe configuration editing.",
  javascript: "Modern JavaScript and TypeScript, Node.js, package design, testing, async control flow, and web tooling.",
  python: "Modern Python, packaging, typing, testing, automation, data processing, and debugging workflows.",
};

const defaultSteps: Record<AgentRole, string[]> = {
  arduino: ["Identify board and pin assumptions", "Implement a minimal sketch", "Compile or lint in a controlled workspace", "Report hardware-specific risks"],
  "raspberry-pi": ["Identify OS and hardware interfaces", "Choose a least-privilege implementation", "Run tests without touching real GPIO", "Report deployment and permissions risks"],
  csharp: ["Identify target framework and project shape", "Implement typed, testable code", "Run the configured test command", "Report runtime and package risks"],
  yaml: ["Validate syntax and schema assumptions", "Make the smallest safe change", "Run a parser or project validation command", "Report interpolation and secret risks"],
  javascript: ["Inspect module and runtime constraints", "Implement typed, testable code", "Run unit tests and type checks", "Report dependency and runtime risks"],
  python: ["Inspect interpreter and package constraints", "Implement typed, testable code", "Run unit tests and static checks", "Report environment and dependency risks"],
};

export class InMemoryAgentMemory implements AgentMemoryStore {
  private readonly entries: AgentMemoryEntry[] = [];

  remember(entry: Omit<AgentMemoryEntry, "createdAt">): void {
    this.entries.push({ ...entry, createdAt: new Date().toISOString() });
  }

  recall(key?: string): AgentMemoryEntry[] {
    return this.entries.filter((entry) => key === undefined || entry.key === key).map((entry) => ({ ...entry }));
  }
}

function planFor(role: AgentRole, prompt: string): AgentPlan {
  const risks = [
    "No private model or vendor documentation is bundled; inject an AgentProvider for model-backed reasoning.",
    "Hardware and production commands must be tested in the target environment before deployment.",
  ];
  if (/secret|token|password|key/i.test(prompt)) risks.push("Prompt mentions credentials; keep secrets out of source and logs.");
  return { role, summary: `Plan prepared by the ${role} specialist for: ${prompt}`, steps: defaultSteps[role], risks };
}

export class CodingAgent {
  readonly role: AgentRole;
  readonly memory: AgentMemoryStore;
  private readonly options: CodingAgentOptions;

  constructor(role: AgentRole, options: CodingAgentOptions = {}) {
    this.role = role;
    this.options = options;
    this.memory = options.memory ?? new InMemoryAgentMemory();
  }

  async run(task: AgentTask): Promise<AgentResult> {
    const plan = planFor(this.role, task.prompt);
    const errors: string[] = [];
    let output: string | undefined;
    if (this.options.provider) {
      try {
        output = await this.options.provider.complete({
          role: this.role,
          prompt: task.prompt,
          knowledge: AGENT_KNOWLEDGE[this.role],
          memory: this.memory.recall(),
        });
      } catch (error) {
        errors.push(error instanceof Error ? error.message : String(error));
      }
    }

    let tests;
    if (this.options.autoTest && task.testCommand) {
      const [language, ...codeParts] = task.testCommand;
      if (language !== "javascript" && language !== "python" && language !== "bash" && language !== "cmd") {
        errors.push(`Unsupported test language: ${language}`);
      } else {
        tests = await (this.options.sandbox ?? runSandbox)({
          language,
          code: codeParts.join(" "),
          rootDir: process.cwd(),
        });
        if (!tests.ok) errors.push(tests.stderr || "Agent test command failed");
      }
    }

    this.memory.remember({ key: "last-task", value: task.prompt });
    return { role: this.role, plan, output, tests, errors, learned: this.memory.recall("last-task") };
  }
}

export class AgentCouncil {
  readonly agents: CodingAgent[];

  constructor(roles: readonly AgentRole[], options: CouncilOptions = {}) {
    const maxAgents = Math.min(Math.max(options.maxAgents ?? roles.length, 1), 700);
    this.agents = roles.slice(0, maxAgents).map((role) => new CodingAgent(role, options));
  }

  async deliberate(task: AgentTask): Promise<AgentResult[]> {
    return Promise.all(this.agents.map((agent) => agent.run(task)));
  }

  async report(task: AgentTask): Promise<{ results: AgentResult[]; errors: string[] }> {
    const results = await this.deliberate(task);
    return { results, errors: results.flatMap((result) => result.errors) };
  }
}

export function createDefaultCouncil(options: CouncilOptions = {}): AgentCouncil {
  return new AgentCouncil(
    ["arduino", "raspberry-pi", "csharp", "yaml", "javascript", "python"],
    options,
  );
}