import { spawn } from "node:child_process";
import { dirname, isAbsolute, relative, resolve } from "node:path";
import type { SandboxLanguage, SandboxOptions, SandboxResult } from "./types";

const languageCommands: Record<SandboxLanguage, (code: string) => [string, string[]]> = {
  javascript: (code) => ["node", ["--input-type=module", "-e", code]],
  python: (code) => ["python3", ["-c", code]],
  bash: (code) => ["bash", ["-euo", "pipefail", "-c", code]],
  cmd: (code) => ["cmd.exe", ["/d", "/s", "/c", code]],
};

const DEFAULT_MAX_OUTPUT = 1024 * 1024;
const DEFAULT_TIMEOUT = 10_000;

function safeCwd(candidate: string | undefined, rootDir: string): string {
  const root = resolve(rootDir);
  const cwd = resolve(candidate ?? root);
  const relativePath = relative(root, cwd);
  if (relativePath.startsWith("..") || isAbsolute(relativePath)) {
    throw new Error("Sandbox cwd must remain inside rootDir");
  }
  return cwd;
}

export async function runSandbox(options: SandboxOptions): Promise<SandboxResult> {
  if (options.language === "cmd" && process.platform !== "win32") {
    return {
      ok: false,
      exitCode: null,
      signal: null,
      stdout: "",
      stderr: "cmd language is only available on Windows hosts",
      durationMs: 0,
      timedOut: false,
      command: "cmd.exe",
    };
  }
  const [command, generatedArgs] = languageCommands[options.language](options.code);
  const allowedCommands = options.allowedCommands ?? ["node", "python3", "bash", "cmd.exe"];
  if (!allowedCommands.includes(command)) {
    throw new Error(`Command "${command}" is not allowed by this sandbox policy`);
  }
  const timeoutMs = Math.min(Math.max(options.timeoutMs ?? DEFAULT_TIMEOUT, 100), 30_000);
  const maxOutputBytes = Math.min(Math.max(options.maxOutputBytes ?? DEFAULT_MAX_OUTPUT, 1024), 10 * DEFAULT_MAX_OUTPUT);
  const rootDir = options.rootDir ?? process.cwd();
  const cwd = safeCwd(options.cwd, rootDir);
  const started = Date.now();

  return new Promise((resolveResult) => {
    const child = spawn(command, [...generatedArgs, ...(options.args ?? [])], {
      cwd,
      env: { PATH: process.env.PATH ?? "", ...options.env },
      shell: false,
      windowsHide: true,
    });
    let stdout = "";
    let stderr = "";
    let bytesSeen = 0;
    let truncated = false;
    let timedOut = false;
    const collect = (target: "stdout" | "stderr", chunk: Buffer): void => {
      if (bytesSeen >= maxOutputBytes) {
        truncated = true;
        return;
      }
      const remaining = maxOutputBytes - bytesSeen;
      const text = chunk.subarray(0, remaining).toString("utf8");
      bytesSeen += text.length;
      if (target === "stdout") stdout += text;
      else stderr += text;
      if (text.length < chunk.length) truncated = true;
    };
    child.stdout.on("data", (chunk: Buffer) => collect("stdout", chunk));
    child.stderr.on("data", (chunk: Buffer) => collect("stderr", chunk));
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGTERM");
      setTimeout(() => child.kill("SIGKILL"), 250);
    }, timeoutMs);
    child.on("error", (error) => {
      clearTimeout(timer);
      resolveResult({
        ok: false,
        exitCode: null,
        signal: null,
        stdout,
        stderr: `${stderr}${error.message}`,
        durationMs: Date.now() - started,
        timedOut,
        command,
      });
    });
    child.on("close", (exitCode, signal) => {
      clearTimeout(timer);
      if (truncated) stderr += "\n[output truncated by sandbox policy]";
      resolveResult({
        ok: exitCode === 0 && !timedOut,
        exitCode,
        signal,
        stdout,
        stderr,
        durationMs: Date.now() - started,
        timedOut,
        command,
      });
    });
  });
}

export function sandboxRootFor(filePath: string): string {
  return dirname(resolve(filePath));
}