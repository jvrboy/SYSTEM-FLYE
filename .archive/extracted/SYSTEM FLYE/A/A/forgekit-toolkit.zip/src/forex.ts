import type { Candle, ForexAnalysis, IndicatorSeries, NullableNumber } from "./types";

function assertPeriod(period: number): void {
  if (!Number.isInteger(period) || period < 1) throw new Error("period must be a positive integer");
}

function series(name: string, values: NullableNumber[]): IndicatorSeries {
  return { name, values };
}

export function sma(values: readonly number[], period: number): NullableNumber[] {
  assertPeriod(period);
  return values.map((_, index) =>
    index < period - 1 ? null : values.slice(index - period + 1, index + 1).reduce((sum, value) => sum + value, 0) / period,
  );
}

export function ema(values: readonly number[], period: number): NullableNumber[] {
  assertPeriod(period);
  const result: NullableNumber[] = Array(values.length).fill(null);
  if (values.length < period) return result;
  let current = values.slice(0, period).reduce((sum, value) => sum + value, 0) / period;
  result[period - 1] = current;
  const multiplier = 2 / (period + 1);
  for (let index = period; index < values.length; index += 1) {
    current = (values[index] - current) * multiplier + current;
    result[index] = current;
  }
  return result;
}

export function rsi(values: readonly number[], period = 14): NullableNumber[] {
  assertPeriod(period);
  const result: NullableNumber[] = Array(values.length).fill(null);
  if (values.length <= period) return result;
  let gains = 0;
  let losses = 0;
  for (let index = 1; index <= period; index += 1) {
    const change = values[index] - values[index - 1];
    gains += Math.max(change, 0);
    losses += Math.max(-change, 0);
  }
  let averageGain = gains / period;
  let averageLoss = losses / period;
  result[period] = averageLoss === 0 ? 100 : 100 - 100 / (1 + averageGain / averageLoss);
  for (let index = period + 1; index < values.length; index += 1) {
    const change = values[index] - values[index - 1];
    averageGain = (averageGain * (period - 1) + Math.max(change, 0)) / period;
    averageLoss = (averageLoss * (period - 1) + Math.max(-change, 0)) / period;
    result[index] = averageLoss === 0 ? 100 : 100 - 100 / (1 + averageGain / averageLoss);
  }
  return result;
}

export function macd(
  values: readonly number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9,
): { macd: NullableNumber[]; signal: NullableNumber[]; histogram: NullableNumber[] } {
  const fast = ema(values, fastPeriod);
  const slow = ema(values, slowPeriod);
  const line: NullableNumber[] = values.map((_, index) =>
    fast[index] === null || slow[index] === null ? null : fast[index] - slow[index],
  );
  const compact = line.filter((value): value is number => value !== null);
  const compactSignal = ema(compact, signalPeriod);
  const signal: NullableNumber[] = Array(line.length).fill(null);
  let compactIndex = 0;
  line.forEach((value, index) => {
    if (value !== null) {
      const signalValue = compactSignal[compactIndex];
      signal[index] = signalValue;
      compactIndex += 1;
    }
  });
  const histogram = line.map((value, index) =>
    value === null || signal[index] === null ? null : value - signal[index],
  );
  return { macd: line, signal, histogram };
}

export function bollingerBands(
  values: readonly number[],
  period = 20,
  standardDeviations = 2,
): { upper: NullableNumber[]; middle: NullableNumber[]; lower: NullableNumber[] } {
  assertPeriod(period);
  const middle = sma(values, period);
  const upper: NullableNumber[] = Array(values.length).fill(null);
  const lower: NullableNumber[] = Array(values.length).fill(null);
  values.forEach((_, index) => {
    if (index < period - 1) return;
    const window = values.slice(index - period + 1, index + 1);
    const mean = middle[index] ?? 0;
    const deviation = Math.sqrt(window.reduce((sum, value) => sum + (value - mean) ** 2, 0) / period);
    upper[index] = mean + standardDeviations * deviation;
    lower[index] = mean - standardDeviations * deviation;
  });
  return { upper, middle, lower };
}

export function atr(candles: readonly Candle[], period = 14): NullableNumber[] {
  assertPeriod(period);
  const trueRanges: number[] = candles.map((candle, index) => {
    if (index === 0) return candle.high - candle.low;
    const previousClose = candles[index - 1].close;
    return Math.max(candle.high - candle.low, Math.abs(candle.high - previousClose), Math.abs(candle.low - previousClose));
  });
  return ema(trueRanges, period);
}

export function analyzeForex(
  candles: readonly Candle[],
  options: { symbol?: string; period?: number } = {},
): ForexAnalysis {
  const period = options.period ?? 14;
  const closes = candles.map((candle) => candle.close);
  const movingAverage = sma(closes, period);
  const movingEma = ema(closes, period);
  const movingRsi = rsi(closes, period);
  const movingMacd = macd(closes);
  const bands = bollingerBands(closes, period);
  return {
    symbol: options.symbol,
    candles: [...candles],
    indicators: {
      sma: series(`SMA ${period}`, movingAverage),
      ema: series(`EMA ${period}`, movingEma),
      rsi: series(`RSI ${period}`, movingRsi),
      macd: series("MACD", movingMacd.macd),
      signal: series("Signal", movingMacd.signal),
      histogram: series("Histogram", movingMacd.histogram),
      upperBand: series("Upper band", bands.upper),
      middleBand: series("Middle band", bands.middle),
      lowerBand: series("Lower band", bands.lower),
      atr: series(`ATR ${period}`, atr(candles, period)),
    },
  };
}