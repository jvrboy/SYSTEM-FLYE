export interface PdfOptions {
  title?: string;
  author?: string;
  fontSize?: number;
  margin?: number;
  lineHeight?: number;
}

function pdfText(value: string): string {
  return value
    .replaceAll("\\", "\\\\")
    .replaceAll("(", "\\(")
    .replaceAll(")", "\\)")
    .replaceAll("\r", "");
}

function bytes(value: string): Uint8Array {
  return new TextEncoder().encode(value);
}

export function createPdf(lines: readonly string[], options: PdfOptions = {}): Uint8Array {
  const fontSize = options.fontSize ?? 11;
  const margin = options.margin ?? 54;
  const lineHeight = options.lineHeight ?? Math.ceil(fontSize * 1.45);
  const pageHeight = 792;
  const pageWidth = 612;
  const usableLines = Math.max(1, Math.floor((pageHeight - margin * 2) / lineHeight));
  const pages: string[][] = [];
  for (let index = 0; index < lines.length || index === 0; index += usableLines) {
    pages.push(lines.slice(index, index + usableLines).map(String));
  }

  const objects: string[] = [];
  const addObject = (value: string): number => {
    objects.push(value);
    return objects.length;
  };
  const catalogId = addObject("");
  const pagesId = addObject("");
  const fontId = addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  const pageIds: number[] = [];

  for (const pageLines of pages) {
    let stream = `BT\n/F1 ${fontSize} Tf\n${margin} ${pageHeight - margin - fontSize} Td\n`;
    pageLines.forEach((line, index) => {
      if (index > 0) stream += `0 -${lineHeight} Td\n`;
      stream += `(${pdfText(line)}) Tj\n`;
    });
    stream += "ET\n";
    const streamId = addObject(`<< /Length ${bytes(stream).length} >>\nstream\n${stream}endstream`);
    pageIds.push(
      addObject(
        `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 ${fontId} 0 R >> >> /Contents ${streamId} 0 R >>`,
      ),
    );
  }

  objects[catalogId - 1] = `<< /Type /Catalog /Pages ${pagesId} 0 R >>`;
  objects[pagesId - 1] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pageIds.length} >>`;
  const infoId = addObject(
    `<< /Title (${pdfText(options.title ?? "ForgeKit report")}) /Author (${pdfText(options.author ?? "ForgeKit")}) >>`,
  );

  let output = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(bytes(output).length);
    output += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = bytes(output).length;
  output += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach((offset) => {
    output += `${String(offset).padStart(10, "0")} 00000 n \n`;
  });
  output += `trailer\n<< /Size ${objects.length + 1} /Root ${catalogId} 0 R /Info ${infoId} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return bytes(output);
}