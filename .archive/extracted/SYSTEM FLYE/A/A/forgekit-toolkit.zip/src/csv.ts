export interface CsvOptions {
  delimiter?: string;
  newline?: string;
  includeHeader?: boolean;
}

function escapeCell(value: unknown, delimiter: string): string {
  const text = value === null || value === undefined ? "" : String(value);
  if (!new RegExp(`[",\\r\\n${delimiter}]`).test(text)) return text;
  return `"${text.replaceAll('"', '""')}"`;
}

export function toCsv(
  rows: readonly (readonly unknown[])[],
  options: CsvOptions = {},
): string {
  const delimiter = options.delimiter ?? ",";
  if (delimiter.length !== 1) {
    throw new Error("CSV delimiter must be exactly one character");
  }
  const newline = options.newline ?? "\r\n";
  return rows
    .map((row) => row.map((cell) => escapeCell(cell, delimiter)).join(delimiter))
    .join(newline);
}

export function objectsToCsv<T extends Record<string, unknown>>(
  rows: readonly T[],
  columns?: readonly (keyof T)[],
  options: CsvOptions = {},
): string {
  const keys = columns ? [...columns] : Object.keys(rows[0] ?? {}) as (keyof T)[];
  const body = rows.map((row) => keys.map((key) => row[key]));
  return toCsv(options.includeHeader === false ? body : [[...keys], ...body], options);
}

export function parseCsv(input: string, delimiter = ","): string[][] {
  if (delimiter.length !== 1) {
    throw new Error("CSV delimiter must be exactly one character");
  }
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;

  for (let i = 0; i < input.length; i += 1) {
    const character = input[i];
    const next = input[i + 1];
    if (quoted) {
      if (character === '"' && next === '"') {
        cell += '"';
        i += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        cell += character;
      }
    } else if (character === '"') {
      if (cell.length !== 0) throw new Error("Invalid CSV: quote inside an unquoted cell");
      quoted = true;
    } else if (character === delimiter) {
      row.push(cell);
      cell = "";
    } else if (character === "\n" || character === "\r") {
      if (character === "\r" && next === "\n") i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += character;
    }
  }

  if (quoted) throw new Error("Invalid CSV: unterminated quoted cell");
  if (cell.length > 0 || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}