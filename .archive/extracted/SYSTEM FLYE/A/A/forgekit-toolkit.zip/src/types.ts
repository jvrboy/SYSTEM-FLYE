export type NullableNumber = number | null;

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface IndicatorSeries {
  name: string;
  values: NullableNumber[];
}

export interface ForexAnalysis {
  symbol?: string;
  candles: Candle[];
  indicators: {
    sma: IndicatorSeries;
    ema: IndicatorSeries;
    rsi: IndicatorSeries;
    macd: IndicatorSeries;
    signal: IndicatorSeries;
    histogram: IndicatorSeries;
    upperBand: IndicatorSeries;
    middleBand: IndicatorSeries;
    lowerBand: IndicatorSeries;
    atr: IndicatorSeries;
  };
}

export type SandboxLanguage = "javascript" | "python" | "bash" | "cmd";

export interface SandboxOptions {
  language: SandboxLanguage;
  code: string;
  args?: string[];
  cwd?: string;
  rootDir?: string;
  env?: Record<string, string>;
  timeoutMs?: number;
  maxOutputBytes?: number;
  allowedCommands?: string[];
}

export interface SandboxResult {
  ok: boolean;
  exitCode: number | null;
  signal: string | null;
  stdout: string;
  stderr: string;
  durationMs: number;
  timedOut: boolean;
  command: string;
}

export type AgentRole =
  | "arduino"
  | "raspberry-pi"
  | "csharp"
  | "yaml"
  | "javascript"
  | "python";

export interface AgentTask {
  prompt: string;
  files?: Record<string, string>;
  testCommand?: string[];
}

export interface AgentMemoryEntry {
  key: string;
  value: string;
  createdAt: string;
}

export interface AgentMemoryStore {
  remember(entry: Omit<AgentMemoryEntry, "createdAt">): void;
  recall(key?: string): AgentMemoryEntry[];
}

export interface AgentPlan {
  role: AgentRole;
  summary: string;
  steps: string[];
  risks: string[];
}

export interface AgentResult {
  role: AgentRole;
  plan: AgentPlan;
  output?: string;
  tests?: SandboxResult;
  errors: string[];
  learned: AgentMemoryEntry[];
}

export interface AgentProvider {
  complete(input: {
    role: AgentRole;
    prompt: string;
    knowledge: string;
    memory: AgentMemoryEntry[];
  }): Promise<string>;
}

export interface CodingAgentOptions {
  provider?: AgentProvider;
  memory?: AgentMemoryStore;
  sandbox?: (options: SandboxOptions) => Promise<SandboxResult>;
  autoTest?: boolean;
}

export interface CouncilOptions extends CodingAgentOptions {
  maxAgents?: number;
}