import type { Candle, IndicatorSeries, NullableNumber } from "./types";

export interface LightweightChartLine {
  time: number;
  value: number;
}

export function toCandlestickData(candles: readonly Candle[]): Candle[] {
  return candles.map((candle) => ({ ...candle }));
}

export function toLineData(
  candles: readonly Candle[],
  values: readonly NullableNumber[],
): LightweightChartLine[] {
  if (candles.length !== values.length) throw new Error("candles and values must have equal length");
  return candles.flatMap((candle, index) => {
    const value = values[index];
    return value === null || !Number.isFinite(value) ? [] : [{ time: candle.time, value }];
  });
}

export function indicatorToLineData(
  candles: readonly Candle[],
  indicator: IndicatorSeries,
): LightweightChartLine[] {
  return toLineData(candles, indicator.values);
}