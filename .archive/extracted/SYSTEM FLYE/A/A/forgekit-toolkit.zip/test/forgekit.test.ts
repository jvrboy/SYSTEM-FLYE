import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  AgentCouncil,
  analyzeForex,
  createPdf,
  objectsToCsv,
  parseCsv,
  rsi,
  runSandbox,
  toLineData,
  toCsv,
} from "../src/index";

describe("CSV tools", () => {
  it("round trips quoted cells and object rows", () => {
    const csv = objectsToCsv([{ name: "Ada, Lovelace", note: 'said "hello"' }]);
    assert.deepEqual(parseCsv(csv), [
      ["name", "note"],
      ["Ada, Lovelace", 'said "hello"'],
    ]);
  });

  it("supports empty rows and custom delimiters", () => {
    assert.equal(toCsv([["a", "b"], ["", "c"]], { delimiter: ";" }), "a;b\r\n;c");
  });
});

describe("technical analysis", () => {
  it("computes RSI with warmup nulls", () => {
    const result = rsi([1, 2, 3, 4, 5], 3);
    assert.equal(result[0], null);
    assert.equal(result[3], 100);
    assert.equal(result[4], 100);
  });

  it("returns chart-ready indicator data", () => {
    const candles = Array.from({ length: 4 }, (_, time) => ({
      time,
      open: 1,
      high: 2,
      low: 0,
      close: time + 1,
    }));
    const analysis = analyzeForex(candles, { period: 2 });
    const line = toLineData(candles, analysis.indicators.sma.values);
    assert.equal(line.length, 3);
    assert.equal(line[0].value, 1.5);
  });
});

describe("sandbox", () => {
  it("runs JavaScript without a shell", async () => {
    const result = await runSandbox({ language: "javascript", code: "process.stdout.write('ok')" });
    assert.equal(result.ok, true);
    assert.equal(result.stdout, "ok");
  });

  it("enforces a timeout", async () => {
    const result = await runSandbox({ language: "javascript", code: "setTimeout(() => {}, 1000)", timeoutMs: 100 });
    assert.equal(result.timedOut, true);
    assert.equal(result.ok, false);
  });
});

describe("PDF tools", () => {
  it("creates a valid PDF header", () => {
    const pdf = createPdf(["ForgeKit report"]);
    assert.equal(new TextDecoder().decode(pdf.slice(0, 8)), "%PDF-1.4");
    assert.match(new TextDecoder().decode(pdf), /%%EOF/);
  });
});

describe("agent council", () => {
  it("runs specialist plans and aggregates errors", async () => {
    const council = new AgentCouncil(["javascript", "python"], { maxAgents: 700 });
    const report = await council.report({ prompt: "Review a typed data pipeline" });
    assert.equal(report.results.length, 2);
    assert.equal(report.results[0].plan.steps.length > 0, true);
  });
});