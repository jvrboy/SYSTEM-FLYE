# ForgeKit

ForgeKit is an embeddable TypeScript toolkit for building developer products that need safe local execution, structured file generation, market-data primitives, chart adapters, and coding-agent workflows.

## Included in this release

- **Sandbox runner** — JavaScript, Python, Bash, and Windows CMD profiles. Uses `spawn` with `shell: false`, an allowlist, a workspace boundary, timeout, and output limits.
- **CSV tools** — RFC-style escaping, object-to-CSV export, custom delimiters, and a quoted-field parser.
- **PDF creator** — dependency-free text PDF generation for reports and exports.
- **Forex technical analysis** — SMA, EMA, RSI, MACD, Bollinger Bands, ATR, and a combined analysis result.
- **Chart adapters** — converts candles and indicator series into data shapes accepted by TradingView Lightweight Charts.
- **Coding agents** — six specialist roles, shared memory, optional model provider, optional test execution, and council aggregation.

## Install and use

```bash
pnpm add @workspace/forgekit
```

```ts
import { analyzeForex, runSandbox, toCsv } from "@workspace/forgekit";

const result = await runSandbox({
  language: "javascript",
  code: "console.log('isolated task')",
  rootDir: process.cwd(),
  timeoutMs: 2_000,
});

const csv = toCsv([["symbol", "close"], ["EURUSD", 1.0842]]);
const analysis = analyzeForex(candles, { symbol: "EURUSD", period: 14 });
```

## Security model

This library does **not** claim to provide a VM, container, operating-system sandbox, or unrestricted command execution. `runSandbox` is a process policy helper and should run in a dedicated worker, container, or OS-level sandbox when executing untrusted code. Keep `rootDir` dedicated, pass explicit `allowedCommands`, use short timeouts, and never put credentials in `env` or prompts.

## Agents and model providers

The agent layer provides orchestration, specialist context, task memory, and error reports. It does not bundle a private neural network or silently train on user code. Pass an `AgentProvider` backed by your approved model gateway when model reasoning is needed. Memory is task memory, not model training.

The council supports up to 700 configured agent slots, while the default catalog ships six practical specialist roles. Add more roles or providers in your host application rather than pretending to include hundreds of independent models in a small package.

## Quality gates

```bash
pnpm --filter @workspace/forgekit run typecheck
pnpm --filter @workspace/forgekit run test
pnpm --filter @workspace/forgekit run build
```