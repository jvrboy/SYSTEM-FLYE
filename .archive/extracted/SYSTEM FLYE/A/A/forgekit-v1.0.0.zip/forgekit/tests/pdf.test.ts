import { describe, expect, test } from "bun:test";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { PdfDocument, createPdf, textWidth, PAGE_SIZES } from "../src/index.js";

describe("pdf", () => {
  test("creates a valid PDF structure with correct xref", () => {
    const doc = new PdfDocument({ title: "ForgeKit Test" });
    doc.text(50, 50, "Hello, ForgeKit!", { size: 14, bold: true });
    doc.line(50, 80, 200, 80);
    doc.rect(50, 100, 100, 40, { fill: true, color: [200, 120, 40] });
    doc.addPage();
    doc.text(50, 50, "Page two");

    const bytes = doc.save();
    const buffer = Buffer.from(bytes);
    const text = buffer.toString("latin1");

    expect(text.startsWith("%PDF-1.4")).toBe(true);
    expect(text.trimEnd().endsWith("%%EOF")).toBe(true);
    expect(doc.pageCount).toBe(2);
    expect(text).toContain("(Hello, ForgeKit!)");
    expect(text).toContain("/Type /Catalog");
    expect(text).toContain("/BaseFont /Helvetica-Bold");
    expect(text).toContain("stream");

    // Verify the xref table points at real object offsets.
    const startxrefMatch = /startxref\n(\d+)/.exec(text);
    expect(startxrefMatch).not.toBeNull();
    const xrefOffset = Number(startxrefMatch![1]);
    expect(text.slice(xrefOffset, xrefOffset + 4)).toBe("xref");

    const xrefBody = text.slice(xrefOffset + 4, text.indexOf("trailer"));
    const entries = xrefBody.trim().split("\n").slice(2); // skip count row + free entry
    expect(entries.length).toBeGreaterThan(3);
    entries.forEach((entry, index) => {
      const offset = Number(entry.slice(0, 10));
      const objectNo = index + 1; // xref entries are ordered 1..N
      expect(text.slice(offset, offset + `${objectNo} 0 obj`.length)).toBe(`${objectNo} 0 obj`);
    });
  });

  test("createPdf helper and page sizes", () => {
    const doc = createPdf({ pageWidth: PAGE_SIZES.letter.width, pageHeight: PAGE_SIZES.letter.height });
    expect(doc.width).toBe(612);
    expect(doc.height).toBe(792);
    const bytes = doc.save();
    expect(Buffer.from(bytes).toString("latin1")).toContain("[0 0 612 792]");
  });

  test("textWidth approximates string width", () => {
    expect(textWidth("abc", 12)).toBeCloseTo(18, 5);
  });

  test("saveToFile writes the document", async () => {
    const dir = await mkdtemp(join(tmpdir(), "forgekit-pdf-"));
    const path = join(dir, "out.pdf");
    try {
      const doc = new PdfDocument({ title: "File test" });
      doc.text(40, 40, "Written to disk");
      await doc.saveToFile(path);
      const read = await readFile(path);
      expect(read.toString("latin1").startsWith("%PDF-1.4")).toBe(true);
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  });

  test("non-ASCII text is escaped safely", () => {
    const doc = new PdfDocument();
    doc.text(10, 10, "héllo wörld — ✓");
    const text = Buffer.from(doc.save()).toString("latin1");
    // non-latin1 chars become "?", everything else passes through
    expect(text).toContain("(h?llo w?rld ? ?)");
  });
});
