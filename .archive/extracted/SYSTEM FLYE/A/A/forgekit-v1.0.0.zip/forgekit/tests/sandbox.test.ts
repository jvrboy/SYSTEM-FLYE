import { describe, expect, test } from "bun:test";
import {
  Sandbox,
  runProcess,
  runShell,
  runJavaScript,
  runPython,
  runBash,
  runCmd,
  isAvailable,
  MicroKernel,
  KernelPool,
  ExecutionCache,
  NodeWorkerPool,
  AdaptiveConcurrency,
  SandboxBrain,
  SandboxError,
} from "../src/index.js";

const LONG_TIMEOUT = { timeout: 60_000 };

describe("process runner", () => {
  test("runProcess captures stdout and exit code", async () => {
    const result = await runProcess(process.execPath, ["-e", "console.log('hi')"]);
    expect(result.exitCode).toBe(0);
    expect(result.stdout.trim()).toBe("hi");
    expect(result.stderr).toBe("");
    expect(result.durationMs).toBeGreaterThanOrEqual(0);
  }, LONG_TIMEOUT);

  test("runShell executes scripts", async () => {
    const result = await runShell("echo forgekit-shell");
    expect(result.exitCode).toBe(0);
    expect(result.stdout.trim()).toBe("forgekit-shell");
  }, LONG_TIMEOUT);

  test("runBash executes bash scripts", async () => {
    const result = await runBash("for i in 1 2 3; do echo -n $i; done");
    expect(result.exitCode).toBe(0);
    expect(result.stdout).toBe("123");
  }, LONG_TIMEOUT);

  test("runJavaScript executes source", async () => {
    const result = await runJavaScript("console.log(6 * 7);");
    expect(result.exitCode).toBe(0);
    expect(result.stdout.trim()).toBe("42");
  }, LONG_TIMEOUT);

  test("runPython executes source", async () => {
    const result = await runPython("print(sum(range(100)))");
    expect(result.exitCode).toBe(0);
    expect(result.stdout.trim()).toBe("4950");
  }, LONG_TIMEOUT);

  test("timeouts kill runaway processes", async () => {
    const started = Date.now();
    const result = await runShell("sleep 30", { timeoutMs: 400 });
    expect(result.timedOut).toBe(true);
    expect(result.exitCode).toBeNull();
    expect(Date.now() - started).toBeLessThan(5000);
  }, LONG_TIMEOUT);

  test("failed commands report non-zero exit codes", async () => {
    const result = await runShell("exit 3");
    expect(result.exitCode).toBe(3);
    expect(result.timedOut).toBe(false);
  }, LONG_TIMEOUT);

  test("stdin input is delivered", async () => {
    const result = await runProcess(process.execPath, ["-e", "process.stdin.on('data', d => console.log('got:' + d))"], {
      input: "ping",
    });
    expect(result.exitCode).toBe(0);
    expect(result.stdout).toContain("got:ping");
  }, LONG_TIMEOUT);

  test("runCmd is Windows-only", async () => {
    if (process.platform !== "win32") {
      await expect(runCmd("echo hi")).rejects.toBeInstanceOf(SandboxError);
    }
  });

  test("isAvailable finds installed binaries", async () => {
    expect(await isAvailable("sh")).toBe(true);
    expect(await isAvailable("definitely-not-a-real-binary-xyz")).toBe(false);
  }, LONG_TIMEOUT);
});

describe("micro kernels and pool", () => {
  test("MicroKernel dispatches by kind and tracks stats", async () => {
    const kernel = new MicroKernel("test");
    const good = await kernel.execute({ kind: "shell", payload: "echo ok" });
    expect(good.result.exitCode).toBe(0);
    expect(good.kernel).toBe("test");
    const bad = await kernel.execute({ kind: "shell", payload: "exit 1" });
    expect(bad.result.exitCode).toBe(1);
    const stats = kernel.getStats();
    expect(stats.runs).toBe(2);
    expect(stats.successes).toBe(1);
    expect(stats.failures).toBe(1);
  }, LONG_TIMEOUT);

  test("KernelPool queues beyond its concurrency", async () => {
    const pool = new KernelPool(2);
    const results = await Promise.all([
      pool.submit({ kind: "shell", payload: "sleep 0.1 && echo a" }),
      pool.submit({ kind: "shell", payload: "sleep 0.1 && echo b" }),
      pool.submit({ kind: "shell", payload: "sleep 0.1 && echo c" }),
    ]);
    expect(results.map((r) => r.result.stdout.trim()).sort()).toEqual(["a", "b", "c"]);
    const stats = pool.getStats();
    expect(stats.completed).toBe(3);
    expect(stats.failures).toBe(0);
  }, LONG_TIMEOUT);
});

describe("boosters", () => {
  test("ExecutionCache memoizes results", async () => {
    const cache = new ExecutionCache();
    const task = { kind: "shell", payload: "echo cached" };
    const result = await runShell("echo cached");
    expect(cache.get(task)).toBeNull();
    cache.put(task, result);
    const hit = cache.get(task);
    expect(hit).not.toBeNull();
    expect(hit!.stdout).toBe("cached\n");
    expect(cache.stats().hits).toBe(1);
    expect(cache.stats().misses).toBe(1);
  }, LONG_TIMEOUT);

  test("NodeWorkerPool runs modules in warm workers", async () => {
    const pool = new NodeWorkerPool({ size: 2 });
    const result = await pool.run("export default 6 * 7;");
    expect(result.ok).toBe(true);
    expect(result.result).toBe("42");
    const failed = await pool.run("throw new Error('boom');");
    expect(failed.ok).toBe(false);
    expect(failed.error).toContain("boom");
    await pool.dispose();
  }, LONG_TIMEOUT);

  test("AdaptiveConcurrency permits and reports", async () => {
    const ac = new AdaptiveConcurrency({ min: 1, max: 8, initial: 2 });
    expect(ac.target()).toBe(2);
    const release = await ac.acquire();
    expect(ac.stats().active).toBe(1);
    release();
    expect(ac.stats().active).toBe(0);
    for (let i = 0; i < 20; i++) ac.report(i % 2 === 0 ? 10 : 500);
  });
});

describe("Sandbox facade + brain", () => {
  test("Sandbox runs shell, javascript and python", async () => {
    const sandbox = new Sandbox({ concurrency: 2 });
    const shell = await sandbox.shell("echo facade");
    expect(shell.exitCode).toBe(0);
    const js = await sandbox.javascript("export default 1 + 1;");
    expect(js.exitCode).toBe(0);
    const py = await sandbox.python("print('facade-py')");
    expect(py.exitCode).toBe(0);
    expect(py.stdout.trim()).toBe("facade-py");
    await sandbox.dispose();
  }, LONG_TIMEOUT);

  test("Sandbox caches repeated runs", async () => {
    const sandbox = new Sandbox({ concurrency: 2, cache: true });
    await sandbox.shell("echo twice");
    await sandbox.shell("echo twice");
    expect(sandbox.stats().cache.hits).toBeGreaterThanOrEqual(1);
    await sandbox.dispose();
  }, LONG_TIMEOUT);

  test("SandboxBrain classifies errors", () => {
    const brain = new SandboxBrain();
    expect(brain.diagnose({ exitCode: 0, stdout: "", stderr: "", durationMs: 1, timedOut: false, outputLimitExceeded: false, signal: null, command: "x" }).kind).toBe("ok");
    expect(brain.diagnose({ exitCode: null, stdout: "", stderr: "", durationMs: 1000, timedOut: true, outputLimitExceeded: false, signal: "SIGKILL", command: "x" }).kind).toBe("timeout");
    expect(brain.diagnose({ exitCode: 127, stdout: "", stderr: "command not found: wat", durationMs: 1, timedOut: false, outputLimitExceeded: false, signal: null, command: "x" }).kind).toBe("not-found");
    expect(brain.diagnose({ exitCode: 1, stdout: "", stderr: "SyntaxError: Unexpected token", durationMs: 1, timedOut: false, outputLimitExceeded: false, signal: null, command: "x" }).kind).toBe("syntax");
    expect(brain.diagnose({ exitCode: 1, stdout: "", stderr: "EACCES: permission denied", durationMs: 1, timedOut: false, outputLimitExceeded: false, signal: null, command: "x" }).kind).toBe("permission");
    expect(brain.diagnose({ exitCode: 2, stdout: "", stderr: "something else", durationMs: 1, timedOut: false, outputLimitExceeded: false, signal: null, command: "x" }).kind).toBe("runtime");
  });

  test("agenticRun retries timeouts with an increased limit", async () => {
    const sandbox = new Sandbox({ concurrency: 1 });
    const report = await sandbox.agentic(
      { kind: "shell", payload: "sleep 5", options: { timeoutMs: 300 } },
      { maxAttempts: 2 },
    );
    expect(report.attempts.length).toBe(2);
    expect(report.attempts[0]!.diagnosis.kind).toBe("timeout");
    expect(report.attempts[0]!.fixes.some((f) => f.id === "increase-timeout")).toBe(true);
    expect(report.attempts[1]!.result.timedOut).toBe(true);
    expect(report.conclusion).toBe("failure");
    await sandbox.dispose();
  }, LONG_TIMEOUT);

  test("agenticRun succeeds on clean runs", async () => {
    const sandbox = new Sandbox({ concurrency: 1 });
    const report = await sandbox.agentic({ kind: "shell", payload: "echo clean" });
    expect(report.conclusion).toBe("success");
    expect(report.attempts).toHaveLength(1);
    await sandbox.dispose();
  }, LONG_TIMEOUT);

  test("Sandbox runInWorker uses the warm pool", async () => {
    const sandbox = new Sandbox({ warmWorkers: 1 });
    const result = await sandbox.runInWorker("export default [1,2,3].reduce((a,b) => a+b, 0);");
    expect(result.ok).toBe(true);
    expect(result.result).toBe("6");
    await sandbox.dispose();
  }, LONG_TIMEOUT);
});
