import { describe, expect, test } from "bun:test";
import { PassThrough } from "node:stream";
import { toCsv, parseCsv, parseCsvRows, formatCell, detectDelimiter, CsvWriter, streamCsv } from "../src/index.js";

describe("csv", () => {
  test("formatCell escapes delimiters, quotes and newlines", () => {
    expect(formatCell("plain", ",", false)).toBe("plain");
    expect(formatCell("a,b", ",", false)).toBe('"a,b"');
    expect(formatCell('say "hi"', ",", false)).toBe('"say ""hi"""');
    expect(formatCell("line1\nline2", ",", false)).toBe('"line1\nline2"');
    expect(formatCell(null, ",", false)).toBe("");
    expect(formatCell(42, ",", false)).toBe("42");
    expect(formatCell("x", ",", true)).toBe('"x"');
  });

  test("toCsv writes objects with a header", () => {
    const csv = toCsv([
      { name: "EUR/USD", pip: 0.0001, active: true },
      { name: "USD/JPY", pip: 0.01, active: false },
    ]);
    const lines = csv.trim().split("\n");
    expect(lines[0]).toBe("name,pip,active");
    expect(lines[1]).toBe("EUR/USD,0.0001,true");
    expect(lines[2]).toBe("USD/JPY,0.01,false");
  });

  test("round-trip with quotes, commas and newlines", () => {
    const rows: string[][] = [
      ["alpha", "with,comma", "with\"quote"],
      ["multi\nline", "plain", "trailing space "],
    ];
    const csv = toCsv(rows.map((r) => [...r]));
    expect(csv).toContain('"with""quote"');
    const parsed = parseCsv(csv, { header: false });
    expect(parsed).toEqual(rows);
  });

  test("parseCsv with header produces records", () => {
    const records = parseCsv("a,b\n1,2\n3,4") as Array<Record<string, string>>;
    expect(records).toEqual([
      { a: "1", b: "2" },
      { a: "3", b: "4" },
    ]);
  });

  test("parseCsvRows handles trailing newline", () => {
    expect(parseCsvRows("a,b\nc,d\n")).toEqual([
      ["a", "b"],
      ["c", "d"],
    ]);
  });

  test("detectDelimiter sniffs the separator", () => {
    expect(detectDelimiter("a;b;c\n1;2;3")).toBe(";");
    expect(detectDelimiter("a,b,c\n1,2,3")).toBe(",");
    expect(detectDelimiter("a\tb\tc\n1\t2\t3")).toBe("\t");
    expect(detectDelimiter('a,"b;c",d')).toBe(",");
  });

  test("CsvWriter accumulates rows", () => {
    const writer = new CsvWriter({ columns: ["x", "y"] });
    writer.addRow({ x: 1, y: 2 }).addRow([3, 4]);
    expect(writer.rowCount).toBe(2);
    const text = writer.toString();
    expect(text.startsWith("x,y\n")).toBe(true);
    expect(writer.toBuffer()).toBeInstanceOf(Buffer);
  });

  test("streamCsv writes with headers and backpressure", async () => {
    const sink = new PassThrough();
    const chunks: string[] = [];
    sink.on("data", (chunk: Buffer) => chunks.push(chunk.toString("utf8")));
    const done = streamCsv(
      [
        [{ name: "a" }, { name: "b" }],
        [{ name: "c" }],
      ],
      sink,
    );
    const summary = await done;
    expect(summary.rows).toBe(3);
    const output = chunks.join("");
    expect(output.split("\n")[0]).toBe("name");
    expect(output).toContain("a\n");
    expect(output).toContain("c");
  });
});
