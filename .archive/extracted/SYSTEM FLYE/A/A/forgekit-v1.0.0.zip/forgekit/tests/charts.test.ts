import { describe, expect, test } from "bun:test";
import {
  toLightweightCandles,
  normalizeTime,
  intervalToSeconds,
  resample,
  indicatorsToOverlays,
  tradeMarkers,
  buildChartPayload,
  timeframeLabel,
} from "../src/index.js";
import type { Ohlc } from "../src/index.js";

function bars(): Ohlc[] {
  return [
    { time: 60, open: 1, high: 2, low: 0.5, close: 1.5, volume: 10 },
    { time: 120, open: 1.5, high: 2.5, low: 1, close: 2, volume: 20 },
    { time: 180, open: 2, high: 3, low: 1.5, close: 2.5, volume: 30 },
    { time: 240, open: 2.5, high: 3.5, low: 2, close: 3, volume: 40 },
    { time: 300, open: 3, high: 4, low: 2.5, close: 3.5, volume: 50 },
  ];
}

describe("charts", () => {
  test("toLightweightCandles normalizes ms to seconds", () => {
    const candles = toLightweightCandles([{ time: 1_700_000_000_000, open: 1, high: 2, low: 0, close: 1.5 }]);
    expect(candles[0]!.time).toBe(1_700_000_000);
    expect(normalizeTime(60)).toBe(60);
  });

  test("intervalToSeconds and timeframeLabel", () => {
    expect(intervalToSeconds("1m")).toBe(60);
    expect(intervalToSeconds("4h")).toBe(14_400);
    expect(intervalToSeconds("1w")).toBe(604_800);
    expect(timeframeLabel(60)).toBe("1m");
    expect(timeframeLabel(3600)).toBe("1h");
    expect(timeframeLabel(86400)).toBe("1d");
  });

  test("resample aggregates OHLC and volume", () => {
    const out = resample(bars(), 300);
    expect(out).toHaveLength(2); // bars at 60-240 bucket to 0; the bar at 300 is its own bucket
    expect(out[0]!.time).toBe(0);
    expect(out[0]!.open).toBe(1);
    expect(out[0]!.high).toBe(3.5);
    expect(out[0]!.low).toBe(0.5);
    expect(out[0]!.close).toBe(3);
    expect(out[0]!.volume).toBe(100);
    expect(out[1]!.open).toBe(3);
    expect(out[1]!.close).toBe(3.5);
    expect(out[1]!.volume).toBe(50);
  });

  test("indicatorsToOverlays skips null warm-up values", () => {
    const overlays = indicatorsToOverlays(bars(), [
      { id: "sma", label: "SMA 3", values: [null, null, 2, 2.5, 3] },
    ]);
    expect(overlays).toHaveLength(1);
    expect(overlays[0]!.data).toHaveLength(3);
    expect(overlays[0]!.data[0]).toEqual({ time: 180, value: 2 });
  });

  test("tradeMarkers maps trades to markers", () => {
    const markers = tradeMarkers([
      { time: 120, side: "buy" },
      { time: 240, side: "sell" },
    ]);
    expect(markers[0]!.position).toBe("belowBar");
    expect(markers[0]!.shape).toBe("arrowUp");
    expect(markers[1]!.position).toBe("aboveBar");
    expect(markers[1]!.text).toBe("SELL");
  });

  test("buildChartPayload bundles candles and overlays", () => {
    const payload = buildChartPayload(bars(), []);
    expect(payload.candles).toHaveLength(5);
    expect(payload.overlays).toEqual([]);
  });
});
