import { describe, expect, test } from "bun:test";
import {
  clamp,
  round,
  sum,
  mean,
  stdDev,
  minOf,
  maxOf,
  hashString,
  tokenize,
  cosineSimilarity,
  mulberry32,
  percentile,
  shuffle,
  formatBytes,
  ok,
  err,
  TypedEmitter,
  Logger,
  ForgeKitError,
  SandboxError,
  toError,
} from "../src/index.js";

describe("core utils", () => {
  test("clamp and round", () => {
    expect(clamp(5, 0, 10)).toBe(5);
    expect(clamp(-3, 0, 10)).toBe(0);
    expect(clamp(15, 0, 10)).toBe(10);
    expect(round(1.005, 2)).toBe(1.01);
    expect(round(2.5)).toBe(2.5);
  });

  test("sum, mean, stdDev, minOf, maxOf", () => {
    expect(sum([1, 2, 3])).toBe(6);
    expect(mean([2, 4])).toBe(3);
    expect(stdDev([2, 4])).toBeCloseTo(1, 5);
    expect(minOf([3, 1, 2])).toBe(1);
    expect(maxOf([3, 1, 2])).toBe(3);
    expect(mean([])).toBeNaN();
  });

  test("hashString is deterministic and distinct", () => {
    expect(hashString("hello")).toBe(hashString("hello"));
    expect(hashString("hello")).not.toBe(hashString("world"));
    expect(hashString("a")).toMatch(/^[0-9a-f]{8}$/);
  });

  test("tokenize and cosineSimilarity", () => {
    expect(tokenize("Hello, WORLD! 123")).toEqual(["hello", "world", "123"]);
    expect(cosineSimilarity("arduino pwm pins", "arduino pwm")).toBeGreaterThan(0.5);
    expect(cosineSimilarity("arduino pwm pins", "csharp classes")).toBeLessThan(0.2);
    expect(cosineSimilarity("", "")).toBe(0);
  });

  test("mulberry32 is deterministic", () => {
    const a = mulberry32(42);
    const b = mulberry32(42);
    expect(a()).toBe(b());
    expect(a()).toBe(b());
  });

  test("percentile", () => {
    expect(percentile([1, 2, 3, 4], 50)).toBe(2.5);
    expect(percentile([1, 2, 3, 4], 0)).toBe(1);
    expect(percentile([1, 2, 3, 4], 100)).toBe(4);
  });

  test("shuffle is seeded and stable", () => {
    expect(shuffle([1, 2, 3, 4, 5], 7)).toEqual(shuffle([1, 2, 3, 4, 5], 7));
    expect(shuffle([1, 2, 3, 4, 5], 7)).not.toEqual([1, 2, 3, 4, 5]);
  });

  test("formatBytes", () => {
    expect(formatBytes(512)).toBe("512 B");
    expect(formatBytes(2048)).toBe("2.0 KB");
  });
});

describe("Result", () => {
  test("ok/err discriminate correctly", () => {
    const good = ok(42);
    const bad = err(new Error("boom"));
    expect(good.ok).toBe(true);
    if (good.ok) expect(good.value).toBe(42);
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.error.message).toBe("boom");
  });
});

describe("TypedEmitter", () => {
  test("on/emit/once/off", () => {
    const emitter = new TypedEmitter<{ ping: [number]; done: [] }>();
    const calls: number[] = [];
    const onPing = (n: number) => calls.push(n);
    emitter.on("ping", onPing);
    emitter.once("done", () => calls.push(99));
    emitter.emit("ping", 1);
    emitter.emit("ping", 2);
    emitter.emit("done");
    emitter.emit("done");
    expect(calls).toEqual([1, 2, 99]);
    expect(emitter.listenerCount("ping")).toBe(1);
    emitter.off("ping", onPing);
    expect(emitter.emit("ping", 3)).toBe(false);
    expect(calls).toEqual([1, 2, 99]);
  });

  test("emit returns false when no listeners", () => {
    const emitter = new TypedEmitter<{ x: [] }>();
    expect(emitter.emit("x")).toBe(false);
  });
});

describe("Logger", () => {
  test("silent level suppresses output", () => {
    const log = new Logger({ level: "silent", prefix: "test" });
    expect(() => log.info("hidden")).not.toThrow();
    expect(log.getLevel()).toBe("silent");
  });

  test("child prefixes", () => {
    const log = new Logger({ level: "silent", prefix: "root" });
    expect(log.child("sandbox").prefix).toBe("root:sandbox");
  });
});

describe("errors", () => {
  test("error hierarchy carries codes", () => {
    const error = new SandboxError("nope");
    expect(error).toBeInstanceOf(ForgeKitError);
    expect(error.code).toBe("SANDBOX_ERROR");
    expect(toError("string")).toBeInstanceOf(Error);
    expect(toError(new TypeError("x")).message).toBe("x");
    expect(toError(undefined)).toBeInstanceOf(Error);
  });
});
