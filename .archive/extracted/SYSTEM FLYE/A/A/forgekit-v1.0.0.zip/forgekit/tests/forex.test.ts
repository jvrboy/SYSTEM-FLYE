import { describe, expect, test } from "bun:test";
import {
  sma,
  ema,
  rsi,
  macd,
  bollinger,
  atr,
  stochastic,
  adx,
  ichimoku,
  donchian,
  pivotPoints,
  swingLevels,
  trueRange,
  detectCandlestickPatterns,
  isDoji,
  isHammer,
  isShootingStar,
  isBullishEngulfing,
  isBearishEngulfing,
  analyzeSignals,
  backtest,
  crossoverStrategy,
  generateBars,
  getFxPair,
  toPips,
  roundToPip,
  FX_PAIRS,
  type Ohlc,
} from "../src/index.js";

const last = (values: Array<number | null>): number => {
  for (let i = values.length - 1; i >= 0; i--) {
    if (values[i] !== null) return values[i]!;
  }
  throw new Error("no value");
};

describe("moving averages", () => {
  test("sma matches hand-computed values", () => {
    expect(sma([1, 2, 3, 4, 5], 3)).toEqual([null, null, 2, 3, 4]);
  });

  test("ema follows the recursive formula", () => {
    // multiplier for period 3 is 0.5; seed = sma(3) = 2
    expect(ema([1, 2, 3, 4, 5], 3)).toEqual([null, null, 2, 3, 4]);
  });

  test("macd decomposes into line, signal and histogram", () => {
    const closes = Array.from({ length: 80 }, (_, i) => 100 + i * 0.5 + Math.sin(i / 5) * 2);
    const { macd: macdLine, signal, histogram } = macd(closes);
    const lastIndex = closes.length - 1;
    expect(macdLine[lastIndex]).not.toBeNull();
    expect(signal[lastIndex]).not.toBeNull();
    expect(histogram[lastIndex]).toBeCloseTo(macdLine[lastIndex]! - signal[lastIndex]!, 6);
    // warm-up is null
    expect(macdLine[10]).toBeNull();
  });

  test("bollinger bands center on SMA with population stddev", () => {
    const { upper, middle, lower } = bollinger([1, 2, 3, 4, 5], { period: 5, stdDev: 2 });
    expect(middle[4]).toBe(3);
    expect(upper[4]).toBeCloseTo(3 + 2 * Math.sqrt(2), 6);
    expect(lower[4]).toBeCloseTo(3 - 2 * Math.sqrt(2), 6);
  });
});

describe("RSI", () => {
  test("matches Wilder's classic example (70.46)", () => {
    const closes = [
      44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.1, 45.42, 45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28,
      46.0, 46.03, 46.41, 46.22, 45.64,
    ];
    const series = rsi(closes, 14);
    expect(series[14]).toBeCloseTo(70.46, 1);
    expect(series[13]).toBeNull();
  });

  test("RSI is bounded 0..100", () => {
    const bars = generateBars({ count: 120, seed: 3 });
    const series = rsi(bars.map((b) => b.close), 14);
    for (const value of series) {
      if (value !== null) {
        expect(value).toBeGreaterThanOrEqual(0);
        expect(value).toBeLessThanOrEqual(100);
      }
    }
  });
});

describe("volatility and momentum", () => {
  test("atr smooths true range", () => {
    const candles: Ohlc[] = [
      { time: 1, open: 10, high: 12, low: 9, close: 11 },
      { time: 2, open: 11, high: 14, low: 10, close: 13 },
    ];
    expect(trueRange(candles[0]!)).toBe(3);
    const series = atr(candles, 1);
    expect(series[1]).toBeCloseTo(trueRange(candles[1]!, candles[0]!), 6);
  });

  test("stochastic ranges 0..100", () => {
    const bars = generateBars({ count: 100, seed: 9, startPrice: 1.2 });
    const { k, d } = stochastic(bars);
    const kLast = last(k);
    const dLast = last(d);
    expect(kLast).toBeGreaterThanOrEqual(0);
    expect(kLast).toBeLessThanOrEqual(100);
    expect(dLast).toBeGreaterThanOrEqual(0);
    expect(dLast).toBeLessThanOrEqual(100);
  });

  test("adx reflects a strong trend", () => {
    const bars = generateBars({ count: 120, seed: 4, startPrice: 1.0, drift: 0.002, volatility: 0.0004 });
    const { adx: adxLine, plusDi, minusDi } = adx(bars);
    expect(last(adxLine)).toBeGreaterThan(20);
    expect(last(plusDi)!).toBeGreaterThan(last(minusDi)!);
  });

  test("ichimoku tenkan is the 9-period midpoint", () => {
    const candles = Array.from({ length: 30 }, (_, i) => ({
      time: i,
      open: 10 + i,
      high: 12 + i,
      low: 9 + i,
      close: 11 + i,
    }));
    const { tenkan, kijun, senkouA, shift } = ichimoku(candles);
    expect(tenkan[8]).toBe(14.5); // (high 20 + low 9)/2 over 0..8
    expect(tenkan[7]).toBeNull();
    expect(shift).toBe(26);
    expect(senkouA[25]).not.toBeNull();
  });

  test("donchian channels track extremes", () => {
    const candles = Array.from({ length: 10 }, (_, i) => ({
      time: i,
      open: i,
      high: 10 + i,
      low: i,
      close: i + 0.5,
    }));
    const { upper, lower } = donchian(candles, 5);
    expect(upper[4]).toBe(14); // max high of 10..14
    expect(lower[4]).toBe(0); // min low of 0..4
  });
});

describe("pivots and swings", () => {
  test("classic pivot points", () => {
    const levels = pivotPoints(1.2, 1.1, 1.15, "classic");
    expect(levels.pivot).toBeCloseTo(1.15, 6);
    expect(levels.resistances[0]).toBeCloseTo(2 * 1.15 - 1.1, 6);
    expect(levels.supports[0]).toBeCloseTo(2 * 1.15 - 1.2, 6);
  });

  test("fibonacci and camarilla variants produce ordered levels", () => {
    const fib = pivotPoints(100, 90, 95, "fibonacci");
    expect(fib.resistances[0]).toBeLessThan(fib.resistances[2]!);
    expect(fib.supports[0]).toBeGreaterThan(fib.supports[2]!);
    const cam = pivotPoints(100, 90, 95, "camarilla");
    expect(cam.resistances).toHaveLength(4);
    expect(cam.resistances[0]).toBeLessThan(cam.resistances[3]!);
  });

  test("swingLevels clusters highs and lows", () => {
    const candles = Array.from({ length: 40 }, (_, i) => ({
      time: i,
      open: 10,
      high: i % 8 === 0 ? 20 + (i % 16) : 12,
      low: i % 8 === 4 ? 5 - (i % 16) * 0.1 : 9,
      close: 10.5,
    }));
    const { supports, resistances } = swingLevels(candles, { window: 2 });
    expect(resistances.length).toBeGreaterThan(0);
    expect(supports.length).toBeGreaterThan(0);
    expect(resistances[0]!.price).toBeGreaterThan(supports[0]!.price);
  });
});

describe("candlestick patterns", () => {
  test("single-candle shapes", () => {
    expect(isDoji({ time: 1, open: 10, high: 11, low: 9, close: 10 })).toBe(true);
    expect(isHammer({ time: 1, open: 10, high: 13, low: 5, close: 12 })).toBe(true);
    expect(isShootingStar({ time: 1, open: 10, high: 15, low: 9.5, close: 11 })).toBe(true);
  });

  test("engulfing requires an opposite prior candle", () => {
    const candles: Ohlc[] = [
      { time: 1, open: 11, high: 11.5, low: 9.5, close: 10 }, // bearish
      { time: 2, open: 9.8, high: 12, low: 9.6, close: 11.8 }, // bullish engulfs
    ];
    expect(isBullishEngulfing(candles, 1)).toBe(true);
    expect(isBearishEngulfing(candles, 1)).toBe(false);
  });

  test("detectCandlestickPatterns finds patterns across a series", () => {
    const bars = generateBars({ count: 200, seed: 11 });
    const signals = detectCandlestickPatterns(bars);
    expect(signals.length).toBeGreaterThan(0);
    for (const signal of signals) {
      expect(signal.index).toBeGreaterThanOrEqual(0);
      expect(signal.strength).toBeGreaterThan(0);
    }
  });
});

describe("signals", () => {
  test("a strong uptrend produces a buy bias", () => {
    const bars = generateBars({ count: 120, seed: 6, drift: 0.003, volatility: 0.0005, startPrice: 1.0 });
    const analysis = analyzeSignals(bars);
    expect(["buy", "neutral"]).toContain(analysis.signal);
    expect(analysis.score).toBeGreaterThan(0);
    expect(analysis.reasons.length).toBeGreaterThan(0);
    expect(analysis.indicators.emaFast).not.toBeNull();
    expect(analysis.indicators.rsi).not.toBeNull();
  });

  test("a strong downtrend is identified as bearish", () => {
    const bars = generateBars({ count: 120, seed: 6, drift: -0.003, volatility: 0.0005, startPrice: 2.0 });
    const analysis = analyzeSignals(bars);
    // Trend-following components must point down (RSI is contrarian and may
    // pull the score up when oversold, which is by design).
    expect(analysis.indicators.emaFast!).toBeLessThan(analysis.indicators.emaSlow!);
    expect(analysis.indicators.macdHistogram).not.toBeNull();
    expect(["down", "ranging"]).toContain(analysis.trend);
    expect(analysis.reasons.length).toBeGreaterThan(0);
  });
});

describe("backtesting", () => {
  test("crossover strategy trades a trend and reports sane stats", () => {
    const bars = generateBars({ count: 300, seed: 21, drift: 0.001, volatility: 0.001, startPrice: 1.0 });
    const result = backtest(bars, crossoverStrategy({ fast: 10, slow: 30 }), { initialBalance: 10_000 });
    expect(result.trades.length).toBeGreaterThan(0);
    expect(result.stats.numTrades).toBe(result.trades.length);
    expect(result.stats.winRate).toBeGreaterThanOrEqual(0);
    expect(result.stats.winRate).toBeLessThanOrEqual(1);
    expect(result.stats.maxDrawdownPct).toBeGreaterThanOrEqual(0);
    expect(result.stats.finalBalance).toBeGreaterThan(0);
    expect(result.equityCurve.length).toBe(bars.length - 1);
    for (const trade of result.trades) {
      expect(trade.entryTime).toBeLessThan(trade.exitTime);
    }
  });

  test("commission reduces returns", () => {
    const bars = generateBars({ count: 200, seed: 31, drift: 0.002, volatility: 0.0008 });
    const free = backtest(bars, crossoverStrategy(), { commissionPct: 0 });
    const taxed = backtest(bars, crossoverStrategy(), { commissionPct: 0.005 });
    expect(taxed.stats.finalBalance).toBeLessThanOrEqual(free.stats.finalBalance + 1e-6);
  });
});

describe("fx data", () => {
  test("generateBars is deterministic per seed", () => {
    expect(generateBars({ count: 50, seed: 5 })).toEqual(generateBars({ count: 50, seed: 5 }));
    expect(generateBars({ count: 50, seed: 5 })).not.toEqual(generateBars({ count: 50, seed: 6 }));
  });

  test("generated bars are monotonic in time with valid OHLC", () => {
    const bars = generateBars({ count: 100, seed: 2, intervalSeconds: 60 });
    for (let i = 1; i < bars.length; i++) {
      expect(bars[i]!.time).toBe(bars[i - 1]!.time + 60);
      expect(bars[i]!.high).toBeGreaterThanOrEqual(Math.max(bars[i]!.open, bars[i]!.close));
      expect(bars[i]!.low).toBeLessThanOrEqual(Math.min(bars[i]!.open, bars[i]!.close));
    }
  });

  test("pips and rounding", () => {
    expect(toPips(0.001, "EURUSD")).toBe(10);
    expect(toPips(0.1, "USDJPY")).toBe(10);
    expect(roundToPip(1.23456, "EURUSD")).toBe(1.2346);
    expect(getFxPair("eurusd").pip).toBe(0.0001);
    expect(FX_PAIRS.length).toBeGreaterThan(10);
  });
});
