import { describe, expect, test } from "bun:test";
import {
  NeuralBrain,
  KnowledgeBase,
  GLOBAL_ERROR_LIBRARY,
  Debugger,
  BaseCodingAgent,
  defaultStaticChecks,
  JavaScriptCodingAgent,
  PythonCodingAgent,
  ArduinoCodingAgent,
  RaspberryPiCodingAgent,
  CSharpCodingAgent,
  YamlCodingAgent,
  AgentsCouncil,
  createCodingAgent,
} from "../src/index.js";

const LONG_TIMEOUT = { timeout: 120_000 };

describe("NeuralBrain", () => {
  test("learns XOR with backpropagation", () => {
    const brain = new NeuralBrain({ sizes: [2, 4, 1], seed: 7 });
    const samples = [
      { input: [0, 0], output: [0] },
      { input: [0, 1], output: [1] },
      { input: [1, 0], output: [1] },
      { input: [1, 1], output: [0] },
    ];
    const loss = brain.train(samples, { epochs: 4000, learningRate: 0.6 });
    expect(loss).toBeLessThan(0.05);
    const check = (a: number, b: number) => brain.predict([a, b])[0]!;
    expect(check(0, 1)).toBeGreaterThan(0.5);
    expect(check(1, 0)).toBeGreaterThan(0.5);
    expect(check(0, 0)).toBeLessThan(0.5);
    expect(check(1, 1)).toBeLessThan(0.5);
  }, { timeout: 60_000 });

  test("predictClass returns argmax", () => {
    const brain = new NeuralBrain({ sizes: [2, 2, 3], seed: 3 });
    const cls = brain.predictClass([1, 1]);
    expect(cls).toBeGreaterThanOrEqual(0);
    expect(cls).toBeLessThan(3);
  });

  test("online skill learning clamps to [-1, 1]", () => {
    const brain = new NeuralBrain({ sizes: [2, 1], seed: 1 });
    brain.learn("lang:python", 0.5);
    expect(brain.getSkill("lang:python")).toBe(0.5);
    brain.learn("lang:python", 0.9);
    expect(brain.getSkill("lang:python")).toBe(1);
    brain.learn("lang:python", -2);
    expect(brain.getSkill("lang:python")).toBe(-1);
  });

  test("clone produces an independent seeded brain", () => {
    const brain = new NeuralBrain({ sizes: [2, 3, 2], seed: 99 });
    const clone = brain.clone(99);
    expect(clone.predict([0.2, 0.8])).toEqual(brain.predict([0.2, 0.8]));
    clone.learn("x", 1);
    expect(brain.getSkill("x")).toBe(0);
  });
});

describe("KnowledgeBase", () => {
  const kb = new KnowledgeBase({
    entries: [
      {
        id: "pwm",
        topic: "PWM on Arduino",
        content: "analogWrite produces a PWM square wave on pins 3, 5, 6, 9, 10, 11.",
        tags: ["arduino", "pwm", "analogwrite"],
        errors: [{ id: "pwm-pin", pattern: /not a pwm pin/i.source, explanation: "Pin cannot do PWM.", hint: "Use a PWM-capable pin." }],
      },
      {
        id: "csharp",
        topic: "C# classes",
        content: "Classes define objects; properties use get/set accessors.",
        tags: ["csharp", "class", "property"],
      },
    ],
  });

  test("search ranks relevant entries first", () => {
    const results = kb.search("arduino pwm analogwrite");
    expect(results.length).toBeGreaterThan(0);
    expect(results[0]!.id).toBe("pwm");
  });

  test("findErrorPatterns matches global + entry patterns", () => {
    const matches = kb.findErrorPatterns("Traceback (most recent call last):\nNameError: name 'x' is not defined");
    const ids = matches.map((m) => m.pattern.id);
    expect(ids).toContain("python-name-error");
    expect(ids).toContain("python-traceback");
    expect(ids).toContain("generic-error");
  });

  test("GLOBAL_ERROR_LIBRARY has unique ids", () => {
    const ids = GLOBAL_ERROR_LIBRARY.map((p) => p.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});

describe("Debugger", () => {
  test("analyzes runtime failures into diagnostics + fixes", () => {
    const debuggerTool = new Debugger(new KnowledgeBase());
    const analysis = debuggerTool.analyze(
      "x = 1",
      { stdout: "", stderr: "NameError: name 'x' is not defined", exitCode: 1 },
      [],
    );
    expect(analysis.diagnostics.some((d) => d.source === "runtime" && d.pattern === "python-name-error")).toBe(true);
    expect(analysis.fixes.some((f) => f.id === "fix-python-name-error" && f.hint.includes("Define"))).toBe(true);
  });

  test("analyzes static issues", () => {
    const debuggerTool = new Debugger(new KnowledgeBase());
    const analysis = debuggerTool.analyze("function f( {", null, ["Unbalanced braces: 1 more opening than closing."]);
    expect(analysis.diagnostics.some((d) => d.source === "static")).toBe(true);
  });

  test("applyPatches applies exact-string patches only", () => {
    const debuggerTool = new Debugger(new KnowledgeBase());
    const patched = debuggerTool.applyPatches("let a = 1;", [{ id: "p", title: "t", hint: "h", patch: { from: "let", to: "const" } }]);
    expect(patched).toBe("const a = 1;");
  });
});

describe("static checks", () => {
  test("defaultStaticChecks detects unbalanced braces", () => {
    expect(defaultStaticChecks("function f() { return 1; }")).toHaveLength(0);
    const issues = defaultStaticChecks("function f() { return 1; ");
    expect(issues.some((i) => i.includes("braces"))).toBe(true);
    expect(defaultStaticChecks("  ").some((i) => i.includes("empty"))).toBe(true);
  });
});

describe("coding agents", () => {
  test("JavaScript agent generates, runs and passes fibonacci", async () => {
    const agent = new JavaScriptCodingAgent({ maxIterations: 3 });
    const result = await agent.code("write a function that computes the fibonacci sequence");
    expect(result.status).toBe("pass");
    expect(result.code).toContain("fibonacci");
    expect(result.run?.exitCode).toBe(0);
    expect(result.diagnostics).toHaveLength(0);
    expect(agent.getBrain().getSkill("lang:javascript")).toBeGreaterThan(0);
  }, LONG_TIMEOUT);

  test("Python agent generates, runs and passes fibonacci", async () => {
    const agent = new PythonCodingAgent({ maxIterations: 3 });
    const result = await agent.code("write a function that computes the fibonacci sequence");
    expect(result.status).toBe("pass");
    expect(result.code).toContain("fibonacci");
    expect(result.run?.ok).toBe(true);
  }, LONG_TIMEOUT);

  test("Arduino agent produces a valid sketch (unverified without toolchain)", async () => {
    const agent = new ArduinoCodingAgent({ maxIterations: 3 });
    const result = await agent.code("make an led blink");
    expect(result.status).toBe("unverified");
    expect(result.code).toContain("void setup()");
    expect(result.code).toContain("void loop()");
    expect(result.diagnostics).toHaveLength(0);
  }, LONG_TIMEOUT);

  test("Raspberry Pi agent produces python GPIO code", async () => {
    const agent = new RaspberryPiCodingAgent({ maxIterations: 3 });
    const result = await agent.code("blink an led with gpio");
    expect(["unverified", "pass"]).toContain(result.status);
    expect(result.code).toContain("gpio");
  }, LONG_TIMEOUT);

  test("YAML agent produces structurally valid YAML", async () => {
    const agent = new YamlCodingAgent({ maxIterations: 3 });
    const result = await agent.code("create a web server configuration");
    expect(result.status).toBe("unverified");
    expect(result.code).toContain("server:");
    expect(result.diagnostics).toHaveLength(0);
  }, LONG_TIMEOUT);

  test("C# agent produces a program with Main", async () => {
    const agent = new CSharpCodingAgent({ maxIterations: 3 });
    const result = await agent.code("write a hello world console program");
    expect(["unverified", "pass"]).toContain(result.status);
    expect(result.code).toContain("Main");
  }, LONG_TIMEOUT);

  test("the debug loop reworks broken output until clean", async () => {
    class FlakyAgent extends BaseCodingAgent {
      private calls = 0;
      constructor() {
        super({ name: "flaky-test", language: "test", knowledge: new KnowledgeBase() });
      }
      protected override generate(task: string, hints: string[]): string {
        void task;
        void hints;
        this.calls += 1;
        return this.calls === 1 ? "function broken() { return 1; " : "function fixed() { return 1; }";
      }
    }
    const agent = new FlakyAgent();
    const result = await agent.code("fix me");
    expect(result.iterations).toBe(2);
    expect(result.status).toBe("unverified");
    expect(result.diagnostics.length).toBeGreaterThan(0);
    expect(result.code).toContain("fixed");
  }, LONG_TIMEOUT);

  test("createCodingAgent factory builds every kind", () => {
    expect(createCodingAgent("arduino").name).toBe("arduino-agent");
    expect(createCodingAgent("javascript").language).toBe("javascript");
    expect(createCodingAgent("python").language).toBe("python");
    expect(createCodingAgent("yaml").name).toBe("yaml-agent");
    expect(createCodingAgent("csharp").name).toBe("csharp-agent");
    expect(createCodingAgent("raspberry-pi").name).toBe("raspberry-pi-agent");
  });
});

describe("AgentsCouncil", () => {
  test("swarm deliberates and elects the best result", async () => {
    const base = new JavaScriptCodingAgent({ maxIterations: 3 });
    const council = AgentsCouncil.swarm(base, { count: 6, seed: 5 });
    expect(council.size).toBe(6);
    const verdict = await council.deliberate("write a function that computes the fibonacci sequence");
    expect(verdict.votes).toHaveLength(6);
    expect(verdict.decision.status).toBe("pass");
    expect(verdict.decision.confidence).toBeGreaterThan(0.5);
    expect(verdict.best.code).toContain("fibonacci");
  }, LONG_TIMEOUT);

  test("swarm of 700 members is cheap to create", () => {
    const base = new YamlCodingAgent();
    const council = AgentsCouncil.swarm(base, { count: 700, seed: 1 });
    expect(council.size).toBe(700);
  });
});
