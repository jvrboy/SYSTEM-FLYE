export * from "./brain.js";
export * from "./knowledge.js";
export * from "./debugger.js";
export * from "./base.js";
export * from "./council.js";
export * from "./domains/arduino.js";
export * from "./domains/raspberrypi.js";
export * from "./domains/csharp.js";
export * from "./domains/yaml.js";
export * from "./domains/javascript.js";
export * from "./domains/python.js";

import { BaseCodingAgent } from "./base.js";
import { ArduinoCodingAgent } from "./domains/arduino.js";
import { RaspberryPiCodingAgent } from "./domains/raspberrypi.js";
import { CSharpCodingAgent } from "./domains/csharp.js";
import { YamlCodingAgent } from "./domains/yaml.js";
import { JavaScriptCodingAgent } from "./domains/javascript.js";
import { PythonCodingAgent } from "./domains/python.js";

export type CodingAgentKind =
  | "arduino"
  | "raspberry-pi"
  | "csharp"
  | "yaml"
  | "javascript"
  | "python";

const AGENT_FACTORIES: Record<CodingAgentKind, () => BaseCodingAgent> = {
  arduino: () => new ArduinoCodingAgent(),
  "raspberry-pi": () => new RaspberryPiCodingAgent(),
  csharp: () => new CSharpCodingAgent(),
  yaml: () => new YamlCodingAgent(),
  javascript: () => new JavaScriptCodingAgent(),
  python: () => new PythonCodingAgent(),
};

/** Create one of the built-in coding agents by kind. */
export function createCodingAgent(kind: CodingAgentKind): BaseCodingAgent {
  const factory = AGENT_FACTORIES[kind];
  if (!factory) throw new Error(`Unknown coding agent kind: ${String(kind)}`);
  return factory();
}

export { AGENT_FACTORIES };
