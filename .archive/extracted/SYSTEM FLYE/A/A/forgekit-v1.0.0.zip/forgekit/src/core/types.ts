/**
 * Core shared types for ForgeKit.
 */

/** A single OHLC bar / candlestick. `time` is unix seconds by convention. */
export interface Ohlc {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

/** A discriminated result: either an `ok` value or an `error`. */
export type Result<T, E = Error> =
  | { ok: true; value: T }
  | { ok: false; error: E };

export function ok<T>(value: T): Result<T, never> {
  return { ok: true, value };
}

export function err<E = Error>(error: E): Result<never, E> {
  return { ok: false, error };
}

/** Result of executing an external process. */
export interface ProcessResult {
  /** Process exit code, or `null` when it was killed by a timeout/signal. */
  exitCode: number | null;
  stdout: string;
  stderr: string;
  durationMs: number;
  /** True when the run was terminated because it exceeded `timeoutMs`. */
  timedOut: boolean;
  /** True when stdout+stderr exceeded the configured `maxBuffer`. */
  outputLimitExceeded: boolean;
  signal: NodeJS.Signals | null;
  /** The command that was executed (for diagnostics). */
  command: string;
}

/** Options accepted by every process-running helper in the sandbox. */
export interface RunOptions {
  cwd?: string;
  /** Extra environment variables merged over the current process env. */
  env?: Record<string, string>;
  /** Kill the process after this many milliseconds (default 30_000). */
  timeoutMs?: number;
  /** Maximum combined stdout+stderr bytes (default 8 MiB). */
  maxBuffer?: number;
  /** Data written to the process stdin before it starts. */
  input?: string;
}

export type NonEmptyArray<T> = [T, ...T[]];
