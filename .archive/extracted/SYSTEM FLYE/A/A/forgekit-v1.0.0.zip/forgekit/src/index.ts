/**
 * ForgeKit — a production-ready TypeScript backend toolkit.
 *
 * ```ts
 * import { Sandbox, JavaScriptCodingAgent, AgentsCouncil } from "forgekit";
 * ```
 *
 * Modules:
 * - `sandbox` — agentic process sandbox (shell, bash, cmd, JS, Python) with
 *   micro-kernels, caching, warm workers and adaptive concurrency.
 * - `agents` — coding agents with neural brains, knowledge bases, debuggers
 *   and an agents council.
 * - `charts` — TradingView lightweight-charts data builders.
 * - `csv` — CSV creator tools.
 * - `pdf` — dependency-free PDF creator.
 * - `forex` — advanced forex technical analysis (indicators, patterns,
 *   signals, backtesting).
 * - `coding` — advanced coding tools (diff, templates, analysis, snippets).
 * - `core` — shared types, errors, events, logger and utilities.
 */

export * as core from "./core/index.js";
export * as sandbox from "./sandbox/index.js";
export * as agents from "./agents/index.js";
export * as charts from "./charts/index.js";
export * as csv from "./csv/index.js";
export * as pdf from "./pdf/index.js";
export * as forex from "./forex/index.js";
export * as coding from "./coding/index.js";

export * from "./core/index.js";
export * from "./sandbox/index.js";
export * from "./agents/index.js";
export * from "./charts/index.js";
export * from "./csv/index.js";
export * from "./pdf/index.js";
export * from "./forex/index.js";
export * from "./coding/index.js";

export const VERSION = "1.0.0";
export const LIBRARY_NAME = "forgekit";
