/**
 * Low-level process execution for the sandbox: spawns external processes with
 * hard timeouts, output caps, stdin injection and per-language runners.
 *
 * Everything here is dependency-free and works on POSIX and Windows hosts.
 */

import { spawn, spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { SandboxError } from "../core/errors.js";
import type { ProcessResult, RunOptions } from "../core/types.js";

const IS_WIN = process.platform === "win32";
const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MAX_BUFFER = 8 * 1024 * 1024;

function buildEnv(extra?: Record<string, string>): Record<string, string> {
  return { ...(process.env as Record<string, string>), ...extra };
}

export function isWindows(): boolean {
  return IS_WIN;
}

/** Spawn a process with argv and collect its output. */
export function runProcess(
  command: string,
  args: string[],
  options: RunOptions = {},
): Promise<ProcessResult> {
  return new Promise<ProcessResult>((resolve) => {
    const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const maxBuffer = options.maxBuffer ?? DEFAULT_MAX_BUFFER;
    const started = Date.now();
    const commandLine = [command, ...args].join(" ");

    let stdout = "";
    let stderr = "";
    let settled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let child: ReturnType<typeof spawn> | undefined;

    const finish = (result: ProcessResult) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      if (child && child.exitCode === null && child.signalCode === null) {
        try {
          child.kill("SIGKILL");
        } catch {
          /* already gone */
        }
      }
      resolve(result);
    };

    try {
      child = spawn(command, args, {
        cwd: options.cwd,
        env: options.env ? buildEnv(options.env) : undefined,
        shell: false,
        windowsHide: true,
        stdio: options.input !== undefined ? ["pipe", "pipe", "pipe"] : ["ignore", "pipe", "pipe"],
      });
    } catch (error) {
      resolve({
        exitCode: -1,
        stdout: "",
        stderr: error instanceof Error ? error.message : String(error),
        durationMs: 0,
        timedOut: false,
        outputLimitExceeded: false,
        signal: null,
        command: commandLine,
      });
      return;
    }

    timer = setTimeout(() => {
      finish({
        exitCode: null,
        stdout,
        stderr,
        durationMs: Date.now() - started,
        timedOut: true,
        outputLimitExceeded: false,
        signal: "SIGKILL",
        command: commandLine,
      });
    }, timeoutMs);

    const append = (target: "stdout" | "stderr", chunk: Buffer) => {
      if (settled) return;
      if (target === "stdout") stdout += chunk.toString("utf8");
      else stderr += chunk.toString("utf8");
      const totalBytes = Buffer.byteLength(stdout) + Buffer.byteLength(stderr);
      if (totalBytes > maxBuffer) {
        finish({
          exitCode: null,
          stdout,
          stderr,
          durationMs: Date.now() - started,
          timedOut: false,
          outputLimitExceeded: true,
          signal: "SIGKILL",
          command: commandLine,
        });
      }
    };

    child.stdout?.on("data", (chunk: Buffer) => append("stdout", chunk));
    child.stderr?.on("data", (chunk: Buffer) => append("stderr", chunk));

    child.on("error", (error: NodeJS.ErrnoException) => {
      finish({
        exitCode: -1,
        stdout,
        stderr: error.message,
        durationMs: Date.now() - started,
        timedOut: false,
        outputLimitExceeded: false,
        signal: null,
        command: commandLine,
      });
    });

    child.on("close", (code, signal) => {
      finish({
        exitCode: code,
        stdout,
        stderr,
        durationMs: Date.now() - started,
        timedOut: false,
        outputLimitExceeded: false,
        signal,
        command: commandLine,
      });
    });

    if (options.input !== undefined && child.stdin) {
      child.stdin.end(options.input);
    }
  });
}

/** Run a script through the host shell (`sh -c` on POSIX, `cmd /c` on Windows). */
export function runShell(script: string, options: RunOptions = {}): Promise<ProcessResult> {
  const args = IS_WIN ? ["/d", "/s", "/c", script] : ["-c", script];
  return runProcess(IS_WIN ? "cmd.exe" : "sh", args, options);
}

/** Windows CMD runner. Throws a descriptive error on POSIX hosts. */
export function runCmd(script: string, options: RunOptions = {}): Promise<ProcessResult> {
  if (!IS_WIN) {
    return Promise.reject(
      new SandboxError("The CMD runner requires a Windows host; on POSIX use runShell/runBash instead.", {
        platform: process.platform,
      }),
    );
  }
  return runProcess("cmd.exe", ["/d", "/s", "/c", script], options);
}

/** Run a script with bash (falls back to `sh` when bash is unavailable). */
export async function runBash(script: string, options: RunOptions = {}): Promise<ProcessResult> {
  const bash = await which("bash");
  if (bash) return runProcess(bash, ["-c", script], options);
  return runShell(script, options);
}

async function withTempFile(
  filename: string,
  content: string,
  fn: (path: string) => Promise<ProcessResult>,
): Promise<ProcessResult> {
  const dir = await mkdtemp(join(tmpdir(), "forgekit-"));
  const file = join(dir, filename);
  try {
    await writeFile(file, content, "utf8");
    return await fn(file);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/** Execute JavaScript source with the host Node.js runtime. */
export function runJavaScript(code: string, options: RunOptions = {}): Promise<ProcessResult> {
  return withTempFile(`task-${randomUUID()}.mjs`, code, (file) => runProcess(process.execPath, [file], options));
}

/** Execute Python source with the best available interpreter. */
export async function runPython(code: string, options: RunOptions = {}): Promise<ProcessResult> {
  const bin = await pythonBin();
  return withTempFile(`task-${randomUUID()}.py`, code, (file) => runProcess(bin, [file], options));
}

/** Resolve the python interpreter path (`python3` preferred, then `python`). */
export async function pythonBin(): Promise<string> {
  for (const candidate of ["python3", "python"]) {
    const resolved = await which(candidate);
    if (resolved) return resolved;
  }
  throw new SandboxError("No Python interpreter found on this host (tried python3, python).");
}

/** Locate an executable on PATH, or return null. */
export function which(command: string): Promise<string | null> {
  return new Promise((resolve) => {
    try {
      const probe = IS_WIN ? `where ${command}` : `command -v ${command}`;
      const result = spawnSync(IS_WIN ? "cmd.exe" : "sh", IS_WIN ? ["/d", "/s", "/c", probe] : ["-c", probe], {
        encoding: "utf8",
        windowsHide: true,
      });
      const line = (result.stdout ?? "").trim().split("\n")[0];
      resolve(line && line.length > 0 ? line : null);
    } catch {
      resolve(null);
    }
  });
}

/** Convenience: is a command available on PATH? */
export async function isAvailable(command: string): Promise<boolean> {
  return (await which(command)) !== null;
}
