/**
 * JavaScript coding agent: embedded JS/Node knowledge, generators and a real
 * runtime debug loop — generated code is executed with the host Node.js and
 * failures are diagnosed from the actual stderr.
 */

import { BaseCodingAgent, defaultStaticChecks, type DynamicValidation } from "../base.js";
import { KnowledgeBase, type KnowledgeEntry } from "../knowledge.js";
import { NeuralBrain } from "../brain.js";
import type { Sandbox } from "../../sandbox/index.js";
import { matchSnippet, JS_SNIPPETS } from "../../coding/snippets.js";
import { commentHeader } from "../../coding/generate.js";

const JS_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "js-basics",
    topic: "Variables and declarations",
    content:
      "const for values that never rebind, let for rebindable variables, var is legacy and function-scoped. Prefer const. Declarations are block-scoped with const/let. Avoid implicit globals — always declare before use.",
    tags: ["const", "let", "var", "declaration", "scope"],
    errors: [
      {
        id: "js-const-assign",
        pattern: /Assignment to constant variable/i.source,
        explanation: "A const was reassigned.",
        hint: "Use let when the variable is reassigned, or restructure to avoid the reassignment.",
      },
    ],
  },
  {
    id: "js-functions",
    topic: "Functions and arrows",
    content:
      "function name(...) { }, const name = (...) => ..., and methods shorthand. Arrow functions do not bind their own 'this'. Use default parameters (function f(x = 1)). Rest params (...args) collect trailing arguments.",
    tags: ["function", "arrow", "this", "default", "rest", "params"],
  },
  {
    id: "js-types",
    topic: "Data types",
    content:
      "Primitives: string, number, boolean, null, undefined, symbol, bigint. Objects and arrays are references. typeof null === 'object' (historical). Use Number.isNaN, not global isNaN, to test NaN.",
    tags: ["string", "number", "boolean", "null", "undefined", "nan"],
  },
  {
    id: "js-objects-arrays",
    topic: "Objects and arrays",
    content:
      "Objects: { key: value }, access with . or []; delete removes keys; spread {...obj} copies shallowly. Arrays: [...arr], .map/.filter/.reduce/.forEach, .push/.pop, destructuring const [a, b] = arr; const { x } = obj.",
    tags: ["object", "array", "spread", "destructure", "map", "reduce"],
  },
  {
    id: "js-control-flow",
    topic: "Control flow",
    content:
      "if/else, for, for...of (values), for...in (keys — avoid on arrays), while, switch, ternary. Equality: === / !== are strict; == does coercion — prefer strict.",
    tags: ["if", "for", "while", "switch", "ternary", "==="],
  },
  {
    id: "js-async",
    topic: "Promises and async/await",
    content:
      "async functions return Promises; await suspends inside async functions. Promise.all([...]) runs in parallel, Promise.allSettled tolerates failures. try/catch/finally handles rejection. Never forget await inside async code — forgetting it is the #1 async bug.",
    tags: ["promise", "async", "await", "then", "catch", "promise.all"],
  },
  {
    id: "js-errors",
    topic: "Error handling",
    content:
      "throw new Error('message'); catch (err) { } — the caught value can be anything. Check err.message before assuming structure. new Error() gets a stack trace; plain throw 'text' does not.",
    tags: ["throw", "try", "catch", "finally", "error", "stack"],
  },
  {
    id: "js-node",
    topic: "Node.js modules",
    content:
      "ESM: import x from './mod.js'; export default/export const. CJS: require('./mod') / module.exports. In ESM, import paths need the extension (./lib.js). package.json 'type': 'module' flips the default.",
    tags: ["node", "esm", "cjs", "import", "require", "export"],
  },
  {
    id: "js-common-errors",
    topic: "Common runtime errors",
    content:
      "ReferenceError: X is not defined (undeclared). TypeError: Cannot read properties of undefined/null (x.member on undefined). SyntaxError: parse failure. RangeError: invalid length/arguments. Stack overflow: runaway recursion.",
    tags: ["referenceerror", "typeerror", "syntaxerror", "rangeerror", "stack"],
  },
  {
    id: "js-strict-mode",
    topic: "Strict mode",
    content:
      "ES modules are strict by default: assignment to undeclared variables throws, this is undefined in plain functions, and silent errors become loud ones. Writing clear code is easier in strict mode.",
    tags: ["strict", "use strict", "esm"],
  },
];

const FALLBACK_MODULE = `export function solve() {
  // TASK: ${"${task}"}
  return "forgekit javascript agent: task accepted";
}

// Self-check: the module must load and solve() must exist.
if (typeof solve !== "function") throw new Error("solve() missing");
`;

export class JavaScriptCodingAgent extends BaseCodingAgent {
  constructor(options: { sandbox?: Sandbox; brain?: NeuralBrain; maxIterations?: number } = {}) {
    super({
      name: "javascript-agent",
      language: "javascript",
      knowledge: new KnowledgeBase({ entries: JS_KNOWLEDGE }),
      sandbox: options.sandbox,
      brain: options.brain,
      maxIterations: options.maxIterations,
    });
  }

  protected override generate(task: string, hints: string[]): string {
    const snippet = matchSnippet(task, JS_SNIPPETS);
    const header = commentHeader("js", this.name, task);
    const hintBlock = hints.length > 0 ? `// Debug notes: ${hints.join("; ")}\n` : "";
    if (snippet) return `${header}${hintBlock}${snippet.code}`;
    return `${header}${hintBlock}${FALLBACK_MODULE.replace("${task}", task)}`;
  }

  protected override staticValidate(code: string): string[] {
    return defaultStaticChecks(code);
  }

  protected override async dynamicValidate(code: string, test: string | undefined): Promise<DynamicValidation | null> {
    const source = test ? `${code}\n\n// ---- test harness ----\n${test}\n` : code;
    return this.runViaSandbox("javascript", source);
  }
}

export function buildJavaScriptKnowledge(): KnowledgeBase {
  return new KnowledgeBase({ entries: JS_KNOWLEDGE });
}
