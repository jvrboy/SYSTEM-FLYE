/**
 * Backtesting engine: run a strategy over candles, produce trades, an equity
 * curve and a full statistics report (return, win rate, profit factor, max
 * drawdown, Sharpe approximation).
 */

import type { Ohlc } from "../core/types.js";
import { ema } from "./indicators.js";
import { minOf, maxOf, mean, stdDev } from "../core/utils.js";

export type TradeDirection = "long" | "short";

export interface Trade {
  entryTime: number;
  exitTime: number;
  entryPrice: number;
  exitPrice: number;
  direction: TradeDirection;
  pnl: number;
  pnlPct: number;
  reason: string;
}

export interface StrategyContext {
  index: number;
  candles: Ohlc[];
  indicators: Record<string, Array<number | null>>;
}

export type Strategy = (ctx: StrategyContext) => "buy" | "sell" | "hold";

export interface BacktestOptions {
  initialBalance?: number;
  /** Commission as a fraction of trade value (e.g. 0.001 = 0.1%). */
  commissionPct?: number;
}

export interface BacktestStats {
  totalReturnPct: number;
  winRate: number;
  profitFactor: number;
  maxDrawdownPct: number;
  sharpe: number;
  numTrades: number;
  avgWinPct: number;
  avgLossPct: number;
  finalBalance: number;
}

export interface BacktestResult {
  trades: Trade[];
  equityCurve: Array<{ time: number; balance: number }>;
  stats: BacktestStats;
}

/** Classic EMA cross strategy factory. */
export function crossoverStrategy(options: { fast?: number; slow?: number } = {}): Strategy {
  const fast = options.fast ?? 10;
  const slow = options.slow ?? 30;
  return (ctx) => {
    const fastLine = ctx.indicators[`ema:${fast}`] ?? [];
    const slowLine = ctx.indicators[`ema:${slow}`] ?? [];
    const i = ctx.index;
    const f0 = fastLine[i] ?? null;
    const f1 = i > 0 ? (fastLine[i - 1] ?? null) : null;
    const s0 = slowLine[i] ?? null;
    const s1 = i > 0 ? (slowLine[i - 1] ?? null) : null;
    if (f0 === null || s0 === null || f1 === null || s1 === null) return "hold" as const;
    if (f1 <= s1 && f0 > s0) return "buy" as const;
    if (f1 >= s1 && f0 < s0) return "sell" as const;
    return f0 > s0 ? ("buy" as const) : ("sell" as const);
  };
}

export function backtest(
  candles: Ohlc[],
  strategy: Strategy,
  options: BacktestOptions = {},
): BacktestResult {
  if (candles.length < 2) throw new Error("backtest needs at least 2 candles");
  const initialBalance = options.initialBalance ?? 10_000;
  const commissionPct = options.commissionPct ?? 0;

  const fast = 10;
  const slow = 30;
  const closes = candles.map((c) => c.close);
  const indicators: Record<string, Array<number | null>> = {
    [`ema:${fast}`]: ema(closes, fast),
    [`ema:${slow}`]: ema(closes, slow),
  };

  let balance = initialBalance;
  let position: {
    direction: TradeDirection;
    entryPrice: number;
    entryTime: number;
    units: number;
  } | null = null;
  const trades: Trade[] = [];
  const equityCurve: Array<{ time: number; balance: number }> = [];

  const closePosition = (index: number, reason: string): void => {
    if (!position) return;
    const exitPrice = candles[index]!.close;
    const units = position.units;
    const gross = position.direction === "long"
      ? (exitPrice - position.entryPrice) * units
      : (position.entryPrice - exitPrice) * units;
    const commission = balance * commissionPct;
    const pnl = gross - commission;
    const pnlPct = (pnl / balance) * 100;
    balance += pnl;
    trades.push({
      entryTime: position.entryTime,
      exitTime: candles[index]!.time,
      entryPrice: position.entryPrice,
      exitPrice,
      direction: position.direction,
      pnl,
      pnlPct,
      reason,
    });
    position = null;
  };

  for (let i = 1; i < candles.length; i++) {
    const signal = strategy({ index: i, candles, indicators });
    if (position) {
      const opposite: "sell" | "buy" = position.direction === "long" ? "sell" : "buy";
      if (signal === opposite) {
        closePosition(i, `${signal} signal (${position.direction} exit)`);
      }
    }
    if (!position && signal !== "hold") {
      const direction: TradeDirection = signal === "buy" ? "long" : "short";
      position = {
        direction,
        entryPrice: candles[i]!.close,
        entryTime: candles[i]!.time,
        units: balance / candles[i]!.close,
      };
    }
    equityCurve.push({ time: candles[i]!.time, balance });
  }

  // Close any open position at the last close.
  if (position) closePosition(candles.length - 1, "end of data");

  const stats = computeStats(trades, equityCurve, initialBalance);
  return { trades, equityCurve, stats };
}

function computeStats(
  trades: Trade[],
  equityCurve: Array<{ time: number; balance: number }>,
  initialBalance: number,
): BacktestStats {
  const finalBalance = equityCurve.length > 0 ? equityCurve[equityCurve.length - 1]!.balance : initialBalance;
  const totalReturnPct = ((finalBalance - initialBalance) / initialBalance) * 100;

  const wins = trades.filter((t) => t.pnl > 0);
  const losses = trades.filter((t) => t.pnl < 0);
  const winRate = trades.length > 0 ? wins.length / trades.length : 0;
  const grossProfit = wins.reduce((sum, t) => sum + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((sum, t) => sum + t.pnl, 0));
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Number.POSITIVE_INFINITY : 0;

  // Max drawdown from the equity curve.
  let peak = -Infinity;
  let maxDrawdown = 0;
  for (const point of equityCurve) {
    if (point.balance > peak) peak = point.balance;
    const drawdown = peak > 0 ? ((peak - point.balance) / peak) * 100 : 0;
    if (drawdown > maxDrawdown) maxDrawdown = drawdown;
  }

  // Sharpe (approximate, per-bar returns).
  const returns: number[] = [];
  for (let i = 1; i < equityCurve.length; i++) {
    const prev = equityCurve[i - 1]!.balance;
    if (prev > 0) returns.push((equityCurve[i]!.balance - prev) / prev);
  }
  const sd = stdDev(returns);
  const sharpe = sd > 0 ? (mean(returns) / sd) * Math.sqrt(252) : 0;

  const avgWinPct = wins.length > 0 ? mean(wins.map((t) => t.pnlPct)) : 0;
  const avgLossPct = losses.length > 0 ? mean(losses.map((t) => t.pnlPct)) : 0;

  return {
    totalReturnPct,
    winRate,
    profitFactor,
    maxDrawdownPct: maxDrawdown,
    sharpe,
    numTrades: trades.length,
    avgWinPct,
    avgLossPct,
    finalBalance,
  };
}

export { minOf, maxOf };
