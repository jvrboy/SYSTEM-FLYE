/**
 * CSV creator tools: robust CSV writing (escaping, custom delimiters,
 * streaming to any writable) and a spec-compliant parser (quoted fields,
 * embedded newlines, escaped quotes).
 */

import type { Writable } from "node:stream";
import { CsvError } from "../core/errors.js";

export interface CsvOptions {
  /** Field delimiter (default ","). */
  delimiter?: string;
  /** Whether the first row is a header row (default true). */
  header?: boolean;
  /** Column names used when writing objects. */
  columns?: string[];
  /** Quote every field (default false — only quotes when needed). */
  quoteAll?: boolean;
  /** Newline sequence (default "\n"). */
  newline?: string;
}

export interface ParseOptions {
  delimiter?: string;
  header?: boolean;
}

function normalizeDelimiter(delimiter: string | undefined): string {
  const value = delimiter ?? ",";
  if (value.length !== 1) throw new CsvError(`Delimiter must be exactly one character, got "${value}"`);
  return value;
}

export function formatCell(value: unknown, delimiter: string, quoteAll: boolean): string {
  if (value === null || value === undefined) return "";
  const text = typeof value === "string" ? value : String(value);
  const needsQuoting =
    quoteAll ||
    text.includes(delimiter) ||
    text.includes('"') ||
    text.includes("\n") ||
    text.includes("\r");
  if (!needsQuoting) return text;
  return `"${text.replace(/"/g, '""')}"`;
}

/** Serialize rows (objects or arrays) into a CSV string. */
export function toCsv(rows: Array<Record<string, unknown> | unknown[]>, options: CsvOptions = {}): string {
  const delimiter = normalizeDelimiter(options.delimiter);
  const newline = options.newline ?? "\n";
  const quoteAll = options.quoteAll ?? false;
  const columns = options.columns;

  const lines: string[] = [];

  if (options.header !== false) {
    if (columns) {
      lines.push(columns.map((col) => formatCell(col, delimiter, quoteAll)).join(delimiter));
    } else if (rows.length > 0 && isObjectRow(rows[0])) {
      lines.push(Object.keys(rows[0] as Record<string, unknown>).map((key) => formatCell(key, delimiter, quoteAll)).join(delimiter));
    }
  }

  for (const row of rows) {
    if (Array.isArray(row)) {
      lines.push(row.map((cell) => formatCell(cell, delimiter, quoteAll)).join(delimiter));
    } else {
      const record = row as Record<string, unknown>;
      const keys = columns ?? Object.keys(record);
      lines.push(keys.map((key) => formatCell(record[key], delimiter, quoteAll)).join(delimiter));
    }
  }

  return lines.join(newline) + (lines.length > 0 ? newline : "");
}

function isObjectRow(row: unknown): row is Record<string, unknown> {
  return typeof row === "object" && row !== null && !Array.isArray(row);
}

/** Parse CSV text into rows of strings. Handles quoted fields, escaped
 * quotes and embedded newlines. */
export function parseCsvRows(text: string, delimiter = ","): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  let i = 0;

  while (i < text.length) {
    const char = text[i]!;
    if (inQuotes) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 2;
        } else {
          inQuotes = false;
          i += 1;
        }
      } else {
        field += char;
        i += 1;
      }
    } else if (char === '"' && field.length === 0) {
      inQuotes = true;
      i += 1;
    } else if (char === delimiter) {
      row.push(field);
      field = "";
      i += 1;
    } else if (char === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
      i += 1;
    } else if (char === "\r") {
      // Skip CR; treat CRLF as a single newline.
      i += 1;
    } else {
      field += char;
      i += 1;
    }
  }

  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }

  return rows;
}

/** Parse CSV text; with `header: true` returns records keyed by the first row. */
export function parseCsv(text: string, options: ParseOptions = {}): string[][] | Array<Record<string, string>> {
  const delimiter = normalizeDelimiter(options.delimiter);
  const rows = parseCsvRows(text, delimiter);
  if (options.header === false) return rows;
  if (rows.length === 0) return [];
  const header = rows[0]!;
  return rows.slice(1).map((cells) => {
    const record: Record<string, string> = {};
    header.forEach((key, index) => {
      record[key] = cells[index] ?? "";
    });
    return record;
  });
}

/** Heuristic delimiter detection from a CSV sample. */
export function detectDelimiter(sample: string): string {
  const candidates = [",", ";", "\t", "|"];
  let best = ",";
  let bestCount = -1;
  for (const candidate of candidates) {
    let count = 0;
    let inQuotes = false;
    for (let i = 0; i < sample.length; i++) {
      const char = sample[i]!;
      if (char === '"') inQuotes = !inQuotes;
      else if (char === candidate && !inQuotes) count += 1;
    }
    if (count > bestCount) {
      bestCount = count;
      best = candidate;
    }
  }
  return best;
}

export class CsvWriter {
  private rows: Array<Record<string, unknown> | unknown[]> = [];
  private readonly options: CsvOptions;

  constructor(options: CsvOptions = {}) {
    this.options = options;
  }

  addRow(row: Record<string, unknown> | unknown[]): this {
    this.rows.push(row);
    return this;
  }

  addRows(rows: Array<Record<string, unknown> | unknown[]>): this {
    for (const row of rows) this.addRow(row);
    return this;
  }

  get rowCount(): number {
    return this.rows.length;
  }

  toString(): string {
    return toCsv(this.rows, this.options);
  }

  toBuffer(): Buffer {
    return Buffer.from(this.toString(), "utf8");
  }
}

/** Stream rows to any Node writable with backpressure handling. */
export async function streamCsv(
  rows: Iterable<Array<Record<string, unknown> | unknown[]>> | AsyncIterable<Array<Record<string, unknown> | unknown[]>>,
  writable: Writable,
  options: CsvOptions = {},
): Promise<{ rows: number; bytes: number }> {
  const delimiter = normalizeDelimiter(options.delimiter);
  const newline = options.newline ?? "\n";
  const quoteAll = options.quoteAll ?? false;
  const columns = options.columns;

  let count = 0;
  let bytes = 0;
  let headerWritten = false;

  const write = async (chunk: string): Promise<void> => {
    const buf = Buffer.from(chunk, "utf8");
    bytes += buf.length;
    if (!writable.write(buf)) {
      await new Promise<void>((resolve) => writable.once("drain", resolve));
    }
  };

  const writeRow = async (row: unknown[]): Promise<void> => {
    await write(row.map((cell) => formatCell(cell, delimiter, quoteAll)).join(delimiter) + newline);
    count += 1;
  };

  for await (const batch of rows) {
    for (const row of batch) {
      if (!headerWritten) {
        headerWritten = true;
        if (options.header !== false) {
          if (columns) {
            await write(columns.map((col) => formatCell(col, delimiter, quoteAll)).join(delimiter) + newline);
          } else if (isObjectRow(row)) {
            await write(Object.keys(row).map((key) => formatCell(key, delimiter, quoteAll)).join(delimiter) + newline);
          }
        }
      }
      if (Array.isArray(row)) {
        await writeRow(row);
      } else {
        const record = row as Record<string, unknown>;
        const keys = columns ?? Object.keys(record);
        await writeRow(keys.map((key) => record[key]));
      }
    }
  }

  return { rows: count, bytes };
}
