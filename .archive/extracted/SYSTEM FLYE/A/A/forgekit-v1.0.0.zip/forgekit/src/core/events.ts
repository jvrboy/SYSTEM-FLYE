/**
 * A tiny, dependency-free typed event emitter.
 */

export type EventMap = Record<string, unknown[]>;

type Listener<Args extends unknown[]> = (...args: Args) => void;

export class TypedEmitter<E extends EventMap> {
  private listeners = new Map<keyof E, Set<Listener<unknown[]>>>();

  on<K extends keyof E>(event: K, fn: Listener<E[K]>): this {
    let set = this.listeners.get(event);
    if (!set) {
      set = new Set();
      this.listeners.set(event, set);
    }
    set.add(fn as Listener<unknown[]>);
    return this;
  }

  once<K extends keyof E>(event: K, fn: Listener<E[K]>): this {
    const wrapped: Listener<E[K]> = (...args) => {
      this.off(event, wrapped);
      fn(...args);
    };
    return this.on(event, wrapped);
  }

  off<K extends keyof E>(event: K, fn: Listener<E[K]>): this {
    this.listeners.get(event)?.delete(fn as Listener<unknown[]>);
    return this;
  }

  emit<K extends keyof E>(event: K, ...args: E[K]): boolean {
    const set = this.listeners.get(event);
    if (!set || set.size === 0) return false;
    for (const fn of [...set]) {
      try {
        (fn as (...a: E[K]) => void)(...args);
      } catch (error) {
        // Emitting must never crash the emitter; surface via nextTick so
        // synchronous callers can observe it in unhandled-rejection handlers.
        queueMicrotask(() => {
          throw error;
        });
      }
    }
    return true;
  }

  listenerCount(event: keyof E): number {
    return this.listeners.get(event)?.size ?? 0;
  }

  removeAllListeners(): this {
    this.listeners.clear();
    return this;
  }
}
