/**
 * Arduino coding agent: embedded Arduino/C++ knowledge, sketch generators,
 * static checks (setup/loop present, balanced braces) and best-effort compile
 * validation when an AVR toolchain is available.
 */

import { BaseCodingAgent, defaultStaticChecks } from "../base.js";
import { KnowledgeBase, type KnowledgeEntry } from "../knowledge.js";
import { NeuralBrain } from "../brain.js";
import type { Sandbox } from "../../sandbox/index.js";
import { which } from "../../sandbox/runner.js";
import { matchSnippet, ARDUINO_SNIPPETS } from "../../coding/snippets.js";
import { commentHeader } from "../../coding/generate.js";
import type { DynamicValidation } from "../base.js";

const ARDUINO_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "arduino-structure",
    topic: "Sketch structure: setup and loop",
    content:
      "Every Arduino sketch has exactly two required functions. setup() runs once at power-up and initializes pins, serial and libraries. loop() runs forever afterwards. Never call setup() or loop() yourself; the Arduino runtime does. There is no main() in sketches.",
    tags: ["sketch", "setup", "loop", "structure", "main"],
  },
  {
    id: "arduino-pins",
    topic: "Digital pins, pin modes and pull-ups",
    content:
      "Uno has digital pins 0-13 and analog pins A0-A5 (usable as digital 14-19). Configure direction with pinMode(pin, INPUT | OUTPUT | INPUT_PULLUP). INPUT_PULLUP enables the built-in ~20k ohm pull-up resistor so a button can be read with one wire to ground.",
    tags: ["pins", "pinmode", "digital", "pullup", "input", "output"],
    errors: [
      {
        id: "arduino-pin-not-declared",
        pattern: /'(\w+)' was not declared in this scope/i.source,
        explanation: "A pin name or variable is not defined in this scope.",
        hint: "Declare the pin constant (e.g. const int LED_PIN = 13;) before setup(), and check spelling.",
      },
    ],
  },
  {
    id: "arduino-digital-io",
    topic: "digitalWrite and digitalRead",
    content:
      "digitalWrite(pin, HIGH|LOW) sets an output pin. digitalRead(pin) returns HIGH or LOW. Only use digitalWrite on pins configured OUTPUT. Reading an unconfigured pin is undefined.",
    tags: ["digitalwrite", "digitalread", "high", "low", "output"],
  },
  {
    id: "arduino-analog-io",
    topic: "analogRead and analogWrite (PWM)",
    content:
      "analogRead(pin) returns 0-1023 on A0-A5 (10-bit ADC). analogWrite(pin, 0-255) outputs a PWM square wave; on the Uno it only works on pins 3, 5, 6, 9, 10, 11. PWM duty cycle: 0 = always low, 255 = always high.",
    tags: ["analogread", "analogwrite", "pwm", "adc", "duty"],
  },
  {
    id: "arduino-serial",
    topic: "Serial communication",
    content:
      "Serial.begin(baud) starts UART (default 9600) in setup(). Serial.print(x) and Serial.println(x) send text. Serial.available() reports bytes waiting; Serial.read() reads one byte (-1 if none). Always check available() > 0 before reading.",
    tags: ["serial", "uart", "print", "println", "baud"],
  },
  {
    id: "arduino-timing",
    topic: "Timing: delay, millis, micros",
    content:
      "delay(ms) blocks for ms milliseconds. millis() returns the milliseconds since boot (rolls over after ~49 days). For non-blocking timing use millis() comparisons instead of delay(). micros() is the microsecond counter (rollover ~71 minutes).",
    tags: ["delay", "millis", "micros", "timing", "non-blocking"],
  },
  {
    id: "arduino-constants",
    topic: "Constants: HIGH/LOW, INPUT/OUTPUT, true/false",
    content:
      "HIGH = 1, LOW = 0, INPUT = 0, OUTPUT = 1, INPUT_PULLUP = 2. true = 1, false = 0. Comparisons like digitalRead(pin) == HIGH are idiomatic.",
    tags: ["constants", "high", "low", "true", "false"],
  },
  {
    id: "arduino-i2c",
    topic: "I2C with the Wire library",
    content:
      "#include <Wire.h> then Wire.begin() in setup. To talk to a slave: Wire.beginTransmission(address); Wire.write(byte); Wire.endTransmission(). To receive: Wire.requestFrom(address, count) then Wire.available()/Wire.read().",
    tags: ["i2c", "wire", "iic", "twowire", "sensor"],
  },
  {
    id: "arduino-spi",
    topic: "SPI with the SPI library",
    content:
      "#include <SPI.h>; SPI.begin() in setup. SPI.beginTransaction(SPISettings(speed, MSBFIRST, SPI_MODE0)); select chip (digitalWrite(CS, LOW)); SPI.transfer(byte); SPI.endTransaction(); deselect.",
    tags: ["spi", "shift", "transfer", "chipselect"],
  },
  {
    id: "arduino-libraries",
    topic: "Using libraries (Servo, LiquidCrystal, ...)",
    content:
      "Libraries are included with #include <Library.h> and objects are often declared globally, e.g. Servo myServo; then initialized in setup(): myServo.attach(pin). Missing #include or a misspelled library name is a very common compile failure.",
    tags: ["libraries", "include", "servo", "liquidcrystal", "attach"],
    errors: [
      {
        id: "arduino-missing-library",
        pattern: /fatal error: (\w+)\.h: No such file or directory/i.source,
        explanation: "A library header could not be found.",
        hint: "Install the library via the Library Manager (Sketch → Include Library) and keep the exact #include name.",
      },
    ],
  },
  {
    id: "arduino-pwm-pins",
    topic: "PWM-capable pins on the Uno",
    content:
      "Only pins 3, 5, 6, 9, 10 and 11 support analogWrite() on the Arduino Uno. Using analogWrite on another pin silently does nothing on some boards or behaves like digitalWrite on others.",
    tags: ["pwm", "pins", "uno", "analogwrite", "~"],
  },
  {
    id: "arduino-memory",
    topic: "SRAM, flash and common pitfalls",
    content:
      "Uno has 2 KB SRAM, 32 KB flash, 1 KB EEPROM. Avoid large local arrays on the stack; prefer static or PROGMEM for constant data. String concatenation in loops fragments heap memory.",
    tags: ["memory", "sram", "flash", "eeprom", "progmem", "heap"],
  },
  {
    id: "arduino-data-types",
    topic: "Data types and overflow",
    content:
      "int is 16-bit on AVR (-32768..32767); unsigned long is 32-bit and holds millis(). Beware int overflow with time arithmetic — cast to unsigned long first, e.g. (unsigned long)(now - last).",
    tags: ["types", "int", "long", "overflow", "unsigned", "16-bit"],
  },
  {
    id: "arduino-compile-errors",
    topic: "Reading compiler errors",
    content:
      "Compile failures report 'exit status 1' followed by the actual error above it. Common ones: 'X was not declared in this scope', 'multiple definition of X', 'stray '\\r' in program' (CRLF line endings), and 'expected ';' before ...'.",
    tags: ["errors", "compile", "exit status", "debug"],
    errors: [
      {
        id: "arduino-exit-status",
        pattern: /exit status 1/i.source,
        explanation: "The sketch failed to compile.",
        hint: "Read the compiler errors above the 'exit status 1' line: missing include, undeclared pin, or type mismatch.",
      },
    ],
  },
];

const FALLBACK_SKETCH = `// Generic starter sketch: blink the onboard LED and log to serial.
const int LED_PIN = 13;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("led on");
  delay(500);
  digitalWrite(LED_PIN, LOW);
  Serial.println("led off");
  delay(500);
}
`;

export class ArduinoCodingAgent extends BaseCodingAgent {
  constructor(options: { sandbox?: Sandbox; brain?: NeuralBrain; maxIterations?: number } = {}) {
    super({
      name: "arduino-agent",
      language: "cpp",
      knowledge: new KnowledgeBase({ entries: ARDUINO_KNOWLEDGE }),
      sandbox: options.sandbox,
      brain: options.brain,
      maxIterations: options.maxIterations,
    });
  }

  protected override generate(task: string, hints: string[]): string {
    const snippet = matchSnippet(task, ARDUINO_SNIPPETS);
    const header = commentHeader("cpp", this.name, task);
    const hintBlock = hints.length > 0 ? `// Debug notes: ${hints.join("; ")}\n` : "";
    const body = snippet ? snippet.code : FALLBACK_SKETCH;
    return `${header}${hintBlock}${body}`;
  }

  protected override staticValidate(code: string): string[] {
    const issues = defaultStaticChecks(code);
    if (!/\bsetup\s*\(/.test(code)) issues.push("Arduino sketches must define setup().");
    if (!/\bloop\s*\(/.test(code)) issues.push("Arduino sketches must define loop().");
    if (!/\bpinMode\s*\(/.test(code)) issues.push("No pinMode() call found — pins must be configured in setup().");
    return issues;
  }

  protected override async dynamicValidate(code: string): Promise<DynamicValidation | null> {
    // Real compile when an AVR toolchain is present; otherwise unverified.
    const avrGcc = await which("avr-gcc");
    if (!avrGcc) return null;
    const result = await this.sandbox.run(
      avrGcc,
      ["-mmcu=atmega328p", "-w", "-x", "c++", "-fsyntax-only", "-"],
      { input: code, timeoutMs: 60_000 },
    );
    return {
      ok: result.exitCode === 0,
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
    };
  }
}

export function buildArduinoKnowledge(): KnowledgeBase {
  return new KnowledgeBase({ entries: ARDUINO_KNOWLEDGE });
}
