/**
 * TradingView lightweight-charts data builders.
 *
 * This module is deliberately dependency-free: it produces the exact data
 * shapes the `lightweight-charts` package consumes, so you can feed backend
 * indicators straight into a chart:
 *
 * ```ts
 * import { createChart, CandlestickSeries } from "lightweight-charts";
 * const { candles, overlays } = buildChartPayload(bars, [...]);
 * chart.addSeries(CandlestickSeries, { data: candles });
 * ```
 */

import type { Ohlc } from "../core/types.js";

export interface LightweightCandle {
  /** Unix time in SECONDS (lightweight-charts uses UTCTimestamp seconds). */
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface LineDatum {
  time: number;
  value: number;
}

export interface HistogramDatum {
  time: number;
  value: number;
  color?: string;
}

export type OverlayType = "line" | "area" | "histogram";

export interface ChartOverlay {
  id: string;
  label: string;
  type: OverlayType;
  data: LineDatum[] | HistogramDatum[];
  options?: Record<string, unknown>;
}

export interface ChartPayload {
  candles: LightweightCandle[];
  overlays: ChartOverlay[];
}

/** lightweight-charts requires seconds; accept ms and normalize. */
export function normalizeTime(time: number): number {
  return time > 1e12 ? Math.floor(time / 1000) : Math.floor(time);
}

export function toLightweightCandles(bars: Ohlc[]): LightweightCandle[] {
  return bars.map((bar) => ({
    time: normalizeTime(bar.time),
    open: bar.open,
    high: bar.high,
    low: bar.low,
    close: bar.close,
  }));
}

export function toLineSeries(entries: Array<{ time: number; value: number }>): LineDatum[] {
  return entries.map((entry) => ({ time: normalizeTime(entry.time), value: entry.value }));
}

export function toHistogram(entries: Array<{ time: number; value: number; color?: string }>): HistogramDatum[] {
  return entries.map((entry) => ({
    time: normalizeTime(entry.time),
    value: entry.value,
    ...(entry.color ? { color: entry.color } : {}),
  }));
}

export type Interval =
  | "1s"
  | "1m"
  | "5m"
  | "15m"
  | "30m"
  | "1h"
  | "4h"
  | "1d"
  | "1w";

const INTERVAL_SECONDS: Record<Interval, number> = {
  "1s": 1,
  "1m": 60,
  "5m": 5 * 60,
  "15m": 15 * 60,
  "30m": 30 * 60,
  "1h": 60 * 60,
  "4h": 4 * 60 * 60,
  "1d": 24 * 60 * 60,
  "1w": 7 * 24 * 60 * 60,
};

export function intervalToSeconds(interval: Interval): number {
  return INTERVAL_SECONDS[interval];
}

export function timeframeLabel(seconds: number): string {
  if (seconds >= 7 * 24 * 3600) return `${seconds / (7 * 24 * 3600)}w`;
  if (seconds >= 24 * 3600) return `${seconds / (24 * 3600)}d`;
  if (seconds >= 3600) return `${seconds / 3600}h`;
  if (seconds >= 60) return `${seconds / 60}m`;
  return `${seconds}s`;
}

/** Aggregate a 1-minute stream into larger candles (OHLC resampling). */
export function resample(bars: Ohlc[], targetSeconds: number): Ohlc[] {
  if (targetSeconds <= 0) throw new Error("targetSeconds must be > 0");
  const out: Ohlc[] = [];
  for (const bar of bars) {
    const bucket = Math.floor(bar.time / targetSeconds) * targetSeconds;
    const last = out[out.length - 1];
    if (last && last.time === bucket) {
      last.high = Math.max(last.high, bar.high);
      last.low = Math.min(last.low, bar.low);
      last.close = bar.close;
      if (bar.volume !== undefined) last.volume = (last.volume ?? 0) + bar.volume;
    } else {
      out.push({
        time: bucket,
        open: bar.open,
        high: bar.high,
        low: bar.low,
        close: bar.close,
        ...(bar.volume !== undefined ? { volume: bar.volume } : {}),
      });
    }
  }
  return out;
}

/** Convert indicator outputs (aligned `number | null` arrays) into overlays. */
export function indicatorsToOverlays(
  bars: Ohlc[],
  indicators: Array<{
    id: string;
    label: string;
    values: Array<number | null>;
    type?: OverlayType;
    color?: string;
    options?: Record<string, unknown>;
  }>,
): ChartOverlay[] {
  const overlays: ChartOverlay[] = [];
  for (const indicator of indicators) {
    const data: LineDatum[] = [];
    for (let i = 0; i < Math.min(bars.length, indicator.values.length); i++) {
      const value = indicator.values[i];
      const time = bars[i]?.time;
      if (value !== null && value !== undefined && time !== undefined) {
        data.push({ time: normalizeTime(time), value });
      }
    }
    overlays.push({
      id: indicator.id,
      label: indicator.label,
      type: indicator.type ?? "line",
      data,
      options: {
        color: indicator.color ?? "rgba(34, 139, 230, 1)",
        lineWidth: 2,
        ...indicator.options,
      },
    });
  }
  return overlays;
}

export interface TradeMarker {
  time: number;
  position: "aboveBar" | "belowBar";
  color: string;
  shape: "arrowUp" | "arrowDown" | "circle";
  text: string;
}

/** Backtest trades → lightweight-charts markers. */
export function tradeMarkers(
  trades: Array<{ time: number; side: "buy" | "sell"; price?: number }>,
): TradeMarker[] {
  return trades.map((trade) => ({
    time: normalizeTime(trade.time),
    position: trade.side === "buy" ? "belowBar" : "aboveBar",
    color: trade.side === "buy" ? "#1a7f37" : "#c62828",
    shape: trade.side === "buy" ? "arrowUp" : "arrowDown",
    text: trade.side === "buy" ? "BUY" : "SELL",
  }));
}

export function buildChartPayload(bars: Ohlc[], overlays: ChartOverlay[] = []): ChartPayload {
  return { candles: toLightweightCandles(bars), overlays };
}
