/**
 * Performance boosters for the sandbox:
 *
 * - `ExecutionCache`      — memoizes process results (keyed by command + env).
 * - `NodeWorkerPool`      — a warm pool of long-lived Node processes that run
 *                           JavaScript without per-task process spawn cost.
 * - `AdaptiveConcurrency` — adjusts parallelism from measured latency.
 */

import { spawn, type ChildProcess } from "node:child_process";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { hashString } from "../core/utils.js";
import type { KernelTask } from "./kernel.js";
import type { ProcessResult, RunOptions } from "../core/types.js";

// ---------------------------------------------------------------------------
// ExecutionCache
// ---------------------------------------------------------------------------

export interface ExecutionCacheOptions {
  /** Results expire after this many milliseconds (default 60s). */
  ttlMs?: number;
  /** Maximum number of cached results (default 500). */
  maxEntries?: number;
}

interface CacheEntry {
  result: ProcessResult;
  expiresAt: number;
}

export class ExecutionCache {
  private entries = new Map<string, CacheEntry>();
  private hits = 0;
  private misses = 0;
  private readonly ttlMs: number;
  private readonly maxEntries: number;

  constructor(options: ExecutionCacheOptions = {}) {
    this.ttlMs = options.ttlMs ?? 60_000;
    this.maxEntries = options.maxEntries ?? 500;
  }

  /** Stable cache key for a task + options. */
  key(task: KernelTask): string {
    const options: RunOptions = task.options ?? {};
    const envKey = options.env ? JSON.stringify(Object.entries(options.env).sort()) : "";
    const optionsKey = [
      options.cwd ?? "",
      envKey,
      String(options.timeoutMs ?? 30_000),
      String(options.maxBuffer ?? 8 * 1024 * 1024),
    ].join("|");
    const source = `${task.kind}|${task.payload}|${JSON.stringify(task.args ?? [])}|${optionsKey}`;
    return hashString(source);
  }

  get(task: KernelTask): ProcessResult | null {
    const key = this.key(task);
    const entry = this.entries.get(key);
    if (!entry) {
      this.misses += 1;
      return null;
    }
    if (entry.expiresAt < Date.now()) {
      this.entries.delete(key);
      this.misses += 1;
      return null;
    }
    this.hits += 1;
    return entry.result;
  }

  put(task: KernelTask, result: ProcessResult): void {
    const key = this.key(task);
    if (this.entries.size >= this.maxEntries) {
      // Evict oldest (Map preserves insertion order).
      const oldest = this.entries.keys().next().value;
      if (oldest !== undefined) this.entries.delete(oldest);
    }
    this.entries.set(key, { result, expiresAt: Date.now() + this.ttlMs });
  }

  clear(): void {
    this.entries.clear();
  }

  stats(): { hits: number; misses: number; size: number } {
    return { hits: this.hits, misses: this.misses, size: this.entries.size };
  }
}

// ---------------------------------------------------------------------------
// NodeWorkerPool
// ---------------------------------------------------------------------------

const WORKER_SOURCE = `
const readline = require("node:readline");
const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
const runTask = async (task) => {
  const t0 = Date.now();
  try {
    const mod = await import("data:text/javascript;base64," + Buffer.from(task.code, "utf8").toString("base64"));
    let result = null;
    try { result = JSON.stringify(mod.default === undefined ? null : mod.default); } catch { result = null; }
    process.stdout.write(JSON.stringify({ id: task.id, ok: true, result, durationMs: Date.now() - t0 }) + "\\n");
  } catch (e) {
    process.stdout.write(JSON.stringify({ id: task.id, ok: false, error: String((e && e.stack) || e), durationMs: Date.now() - t0 }) + "\\n");
  }
};
rl.on("line", (line) => {
  if (!line.trim()) return;
  let task;
  try { task = JSON.parse(line); } catch { return; }
  runTask(task);
});
`;

export interface WorkerTaskResult {
  ok: boolean;
  /** JSON string of the module default export (when serializable). */
  result: string | null;
  error?: string;
  durationMs: number;
}

export interface NodeWorkerPoolOptions {
  size?: number;
  timeoutMs?: number;
  nodePath?: string;
}

interface PoolWorker {
  proc: ChildProcess;
  busy: boolean;
  buffer: string;
  pending: Map<string, { resolve: (r: WorkerTaskResult) => void; timer: ReturnType<typeof setTimeout> }>;
}

export class NodeWorkerPool {
  private readonly size: number;
  private readonly timeoutMs: number;
  private readonly nodePath: string;
  private workers: PoolWorker[] = [];
  private spawnQueue: Array<{ resolve: () => void }> = [];
  private taskCounter = 0;
  private completed = 0;
  private failures = 0;
  private workerFile: string | null = null;

  constructor(options: NodeWorkerPoolOptions = {}) {
    this.size = options.size ?? 2;
    this.timeoutMs = options.timeoutMs ?? 30_000;
    this.nodePath = options.nodePath ?? process.execPath;
  }

  /** Run a JS module in a warm worker. The module's default export (if any)
   * is JSON-serialized back to the caller. */
  async run(code: string): Promise<WorkerTaskResult> {
    await this.ensureWorkers();
    const id = `t-${++this.taskCounter}`;
    return new Promise<WorkerTaskResult>((resolve) => {
      const runOnWorker = () => {
        const worker = this.idleWorker();
        if (!worker) {
          this.spawnQueue.push({ resolve: runOnWorker });
          return;
        }
        worker.busy = true;
        const timer = setTimeout(() => {
          worker.pending.get(id)?.resolve({
            ok: false,
            result: null,
            error: `Worker task timed out after ${this.timeoutMs}ms`,
            durationMs: this.timeoutMs,
          });
          worker.pending.delete(id);
          this.respawn(worker);
        }, this.timeoutMs);
        worker.pending.set(id, { resolve: (r) => resolve(r), timer });
        worker.proc.stdin?.write(JSON.stringify({ id, code }) + "\n");
      };
      runOnWorker();
    });
  }

  private async ensureWorkers(): Promise<void> {
    if (this.workers.length > 0) return;
    if (!this.workerFile) {
      const dir = await mkdtemp(join(tmpdir(), "forgekit-worker-"));
      this.workerFile = join(dir, "worker.cjs");
      await writeFile(this.workerFile, WORKER_SOURCE, "utf8");
    }
    for (let i = 0; i < this.size; i++) this.spawnWorker();
  }

  private spawnWorker(): void {
    if (!this.workerFile) return;
    const proc = spawn(this.nodePath, [this.workerFile], {
      stdio: ["pipe", "pipe", "pipe"],
      windowsHide: true,
    });
    const worker: PoolWorker = {
      proc,
      busy: false,
      buffer: "",
      pending: new Map(),
    };
    proc.stdout?.on("data", (chunk: Buffer) => {
      worker.buffer += chunk.toString("utf8");
      let idx: number;
      while ((idx = worker.buffer.indexOf("\n")) >= 0) {
        const line = worker.buffer.slice(0, idx);
        worker.buffer = worker.buffer.slice(idx + 1);
        if (!line.trim()) continue;
        let msg: { id?: string; ok?: boolean; result?: string | null; error?: string; durationMs?: number };
        try {
          msg = JSON.parse(line);
        } catch {
          continue;
        }
        const taskId = msg.id;
        if (!taskId) continue;
        const pending = worker.pending.get(taskId);
        if (!pending) continue;
        worker.pending.delete(taskId);
        clearTimeout(pending.timer);
        worker.busy = false;
        this.completed += 1;
        if (msg.ok) {
          pending.resolve({ ok: true, result: msg.result ?? null, durationMs: msg.durationMs ?? 0 });
        } else {
          this.failures += 1;
          pending.resolve({
            ok: false,
            result: null,
            error: msg.error ?? "Unknown worker error",
            durationMs: msg.durationMs ?? 0,
          });
        }
        this.pumpSpawnQueue();
      }
    });
    proc.on("error", () => {
      this.reap(worker);
    });
    proc.on("exit", () => {
      this.reap(worker);
    });
    this.workers.push(worker);
  }

  private idleWorker(): PoolWorker | undefined {
    return this.workers.find((w) => !w.busy && w.proc.exitCode === null);
  }

  private pumpSpawnQueue(): void {
    while (this.spawnQueue.length > 0) {
      const worker = this.idleWorker();
      if (!worker) return;
      const next = this.spawnQueue.shift();
      if (next) next.resolve();
    }
  }

  private respawn(worker: PoolWorker): void {
    const idx = this.workers.indexOf(worker);
    this.reap(worker);
    if (idx >= 0) {
      this.spawnWorker();
      // Re-run queued work on the fresh worker.
      this.pumpSpawnQueue();
    }
  }

  private reap(worker: PoolWorker): void {
    const idx = this.workers.indexOf(worker);
    if (idx < 0) return;
    this.workers.splice(idx, 1);
    for (const [, pending] of worker.pending) {
      clearTimeout(pending.timer);
      pending.resolve({ ok: false, result: null, error: "Worker process exited unexpectedly", durationMs: 0 });
    }
    worker.pending.clear();
    try {
      worker.proc.kill("SIGKILL");
    } catch {
      /* already dead */
    }
  }

  async dispose(): Promise<void> {
    for (const worker of [...this.workers]) {
      this.reap(worker);
    }
    this.workers = [];
    if (this.workerFile) {
      await rm(this.workerFile, { force: true }).catch(() => undefined);
      this.workerFile = null;
    }
  }

  stats(): { workers: number; completed: number; failures: number } {
    return { workers: this.workers.length, completed: this.completed, failures: this.failures };
  }
}

// ---------------------------------------------------------------------------
// AdaptiveConcurrency
// ---------------------------------------------------------------------------

export interface AdaptiveConcurrencyOptions {
  min?: number;
  max?: number;
  initial?: number;
  /** Latency target: if runs are faster than this, parallelism may grow. */
  targetLatencyMs?: number;
  windowSize?: number;
}

export class AdaptiveConcurrency {
  private readonly min: number;
  private readonly max: number;
  private limit: number;
  private readonly targetLatencyMs: number;
  private readonly windowSize: number;
  private latencies: number[] = [];
  private active = 0;
  private waiters: Array<() => void> = [];

  constructor(options: AdaptiveConcurrencyOptions = {}) {
    this.min = options.min ?? 1;
    this.max = options.max ?? 16;
    this.limit = options.initial ?? Math.max(this.min, Math.min(4, this.max));
    this.targetLatencyMs = options.targetLatencyMs ?? 250;
    this.windowSize = options.windowSize ?? 20;
  }

  /** Current parallelism target. */
  target(): number {
    return this.limit;
  }

  /** Report the duration of a completed run; may adjust the target. */
  report(durationMs: number): void {
    this.latencies.push(durationMs);
    if (this.latencies.length > this.windowSize) this.latencies.shift();
    if (this.latencies.length < 4) return;
    const avg = this.latencies.reduce((a, b) => a + b, 0) / this.latencies.length;
    if (avg > this.targetLatencyMs * 1.5) {
      this.limit = Math.max(this.min, this.limit - 1);
    } else if (avg < this.targetLatencyMs * 0.5) {
      this.limit = Math.min(this.max, this.limit + 1);
    }
  }

  /** Acquire a permit; returns a release function when admitted. */
  acquire(): Promise<() => void> {
    if (this.active < this.limit) {
      this.active += 1;
      return Promise.resolve(() => this.release());
    }
    return new Promise((resolve) => {
      this.waiters.push(() => {
        this.active += 1;
        resolve(() => this.release());
      });
    });
  }

  private release(): void {
    this.active -= 1;
    const next = this.waiters.shift();
    if (next) next();
  }

  stats(): { active: number; limit: number; waiting: number } {
    return { active: this.active, limit: this.limit, waiting: this.waiters.length };
  }
}
