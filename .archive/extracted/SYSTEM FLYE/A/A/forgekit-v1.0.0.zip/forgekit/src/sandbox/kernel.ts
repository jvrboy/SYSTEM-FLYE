/**
 * Micro-kernels: isolated, trackable execution units.
 *
 * A `MicroKernel` knows how to dispatch one task (shell, bash, cmd, JavaScript,
 * Python or a raw command) and records performance/success stats. A
 * `KernelPool` manages a fixed set of kernels with bounded concurrency and a
 * fair queue, so the sandbox can saturate a host without overloading it.
 */

import { runBash, runCmd, runJavaScript, runProcess, runPython, runShell } from "./runner.js";
import type { ProcessResult, RunOptions } from "../core/types.js";

export type KernelTaskKind = "command" | "shell" | "bash" | "cmd" | "javascript" | "python";

export interface KernelTask {
  /** Unique id (auto-assigned when omitted). */
  id?: string;
  kind: KernelTaskKind;
  /** Command line / script / source code to execute. */
  payload: string;
  /** Arguments for `kind: "command"`. */
  args?: string[];
  options?: RunOptions;
}

export interface KernelResult {
  task: KernelTask;
  result: ProcessResult;
  kernel: string;
}

export interface KernelStats {
  runs: number;
  successes: number;
  failures: number;
  totalMs: number;
}

export class MicroKernel {
  readonly name: string;
  readonly defaultOptions: RunOptions;
  private stats: KernelStats = { runs: 0, successes: 0, failures: 0, totalMs: 0 };

  constructor(name: string, defaultOptions: RunOptions = {}) {
    this.name = name;
    this.defaultOptions = defaultOptions;
  }

  async execute(task: KernelTask): Promise<KernelResult> {
    const options: RunOptions = { ...this.defaultOptions, ...task.options };
    const result = await dispatch(task, options);
    this.stats.runs += 1;
    this.stats.totalMs += result.durationMs;
    if (result.exitCode === 0 && !result.timedOut && !result.outputLimitExceeded) {
      this.stats.successes += 1;
    } else {
      this.stats.failures += 1;
    }
    return { task, result, kernel: this.name };
  }

  getStats(): KernelStats {
    return { ...this.stats };
  }
}

async function dispatch(task: KernelTask, options: RunOptions): Promise<ProcessResult> {
  switch (task.kind) {
    case "command":
      return runProcess(task.payload, task.args ?? [], options);
    case "shell":
      return runShell(task.payload, options);
    case "bash":
      return runBash(task.payload, options);
    case "cmd":
      return runCmd(task.payload, options);
    case "javascript":
      return runJavaScript(task.payload, options);
    case "python":
      return runPython(task.payload, options);
    default: {
      const exhaustive: never = task.kind;
      throw new Error(`Unsupported task kind: ${String(exhaustive)}`);
    }
  }
}

export interface PoolStats {
  queued: number;
  running: number;
  completed: number;
  failures: number;
  totalMs: number;
  kernels: KernelStats[];
}

/**
 * A bounded pool of micro-kernels with a FIFO queue. Submissions never reject
 * because the pool is busy; they simply wait for a free slot.
 */
export class KernelPool {
  private kernels: MicroKernel[];
  private queue: Array<{ task: KernelTask; resolve: (r: KernelResult) => void }> = [];
  private inFlight = 0;
  private completed = 0;
  private failures = 0;
  private totalMs = 0;

  constructor(size = 4, options: { defaultKernelOptions?: RunOptions } = {}) {
    if (size < 1) throw new Error("KernelPool size must be >= 1");
    this.kernels = Array.from(
      { length: size },
      (_, i) => new MicroKernel(`kernel-${i + 1}`, options.defaultKernelOptions),
    );
  }

  get concurrency(): number {
    return this.kernels.length;
  }

  /** Access an individual kernel (e.g. for agentic runs). */
  kernelAt(index: number): MicroKernel {
    const kernel = this.kernels[index];
    if (!kernel) throw new Error(`KernelPool has no kernel at index ${index}`);
    return kernel;
  }

  submit(task: KernelTask): Promise<KernelResult> {
    return new Promise<KernelResult>((resolve) => {
      this.queue.push({ task, resolve });
      this.pump();
    });
  }

  private pump(): void {
    while (this.inFlight < this.kernels.length && this.queue.length > 0) {
      const next = this.queue.shift();
      if (!next) break;
      this.inFlight += 1;
      const kernel = this.kernels[this.inFlight - 1] ?? this.kernels[0]!;
      kernel
        .execute(next.task)
        .then((result) => {
          this.completed += 1;
          this.totalMs += result.result.durationMs;
          if (result.result.exitCode !== 0 || result.result.timedOut) this.failures += 1;
          next.resolve(result);
        })
        .finally(() => {
          this.inFlight -= 1;
          this.pump();
        });
    }
  }

  getStats(): PoolStats {
    return {
      queued: this.queue.length,
      running: this.inFlight,
      completed: this.completed,
      failures: this.failures,
      totalMs: this.totalMs,
      kernels: this.kernels.map((k) => k.getStats()),
    };
  }

  /** Wait for the queue to drain (useful before shutdown). */
  async drain(): Promise<void> {
    while (this.queue.length > 0 || this.inFlight > 0) {
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
  }
}
