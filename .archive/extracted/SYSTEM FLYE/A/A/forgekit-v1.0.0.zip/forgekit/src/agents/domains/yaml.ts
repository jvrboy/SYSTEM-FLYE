/**
 * YAML coding agent: embedded YAML knowledge, config generators and a
 * structural validator (indentation, key/value shape, quote balance) that
 * runs as the agent's static check.
 */

import { BaseCodingAgent, defaultStaticChecks, type DynamicValidation } from "../base.js";
import { KnowledgeBase, type KnowledgeEntry } from "../knowledge.js";
import { NeuralBrain } from "../brain.js";
import type { Sandbox } from "../../sandbox/index.js";
import { which } from "../../sandbox/runner.js";
import { matchSnippet, YAML_SNIPPETS } from "../../coding/snippets.js";
import { commentHeader } from "../../coding/generate.js";
import { countChar } from "../base.js";

const YAML_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "yaml-structure",
    topic: "Mappings, sequences and scalars",
    content:
      "YAML is built from three node types: mappings (key: value), sequences (- item) and scalars (strings, numbers, booleans). A mapping key ends with a colon followed by a space or newline. Sequences use '- ' with a space after the dash.",
    tags: ["mapping", "sequence", "scalar", "key", "list", "value"],
    errors: [
      {
        id: "yaml-mapping-values",
        pattern: /mapping values are not allowed in this context/i.source,
        explanation: "YAML found a colon where it did not expect one — often a missing space or a quoted value issue.",
        hint: "Ensure 'key: value' has a space after the colon, and quote values containing ':'.",
      },
      {
        id: "yaml-block-end",
        pattern: /expected <block end>, but found/i.source,
        explanation: "Indentation is inconsistent — a block ended where YAML expected it to continue.",
        hint: "Use consistent indentation (2 spaces is conventional) at every nesting level.",
      },
      {
        id: "yaml-bad-token",
        pattern: /found character[^\n]*that cannot start any token/i.source,
        explanation: "A character (often a tab or a control character) is not allowed there.",
        hint: "Replace tabs with spaces; check for stray special characters.",
      },
      {
        id: "yaml-tabs",
        pattern: /tabs are not allowed/i.source,
        explanation: "Tabs are forbidden in YAML indentation.",
        hint: "Convert tabs to spaces.",
      },
    ],
  },
  {
    id: "yaml-indentation",
    topic: "Indentation rules",
    content:
      "Indentation must be spaces, never tabs, and must be consistent within a block. Two spaces per level is the most common convention. Children of a key are indented deeper than the key itself.",
    tags: ["indentation", "spaces", "tabs", "nesting", "block"],
  },
  {
    id: "yaml-scalars",
    topic: "Scalar values",
    content:
      "Strings can be plain (no quotes) unless they contain special characters ('#', ':', leading/trailing spaces) — then quote them. true/false/null/yes/no are booleans/null. Numbers may include decimals and exponents.",
    tags: ["scalar", "string", "number", "boolean", "null", "quote"],
  },
  {
    id: "yaml-quotes",
    topic: "Quoting strings",
    content:
      "Single quotes '...' keep text literal. Double quotes \"...\" interpret escapes like \\n and \\t. Quote values that contain ':', '#', '[' or leading whitespace so they are not parsed as structure.",
    tags: ["quote", "single", "double", "escape", "literal"],
  },
  {
    id: "yaml-multiline",
    topic: "Multi-line strings",
    content:
      "Block scalars: '|' keeps newlines (literal), '>' folds them into spaces. Both can be followed by a chomping indicator ('-', '+'). Example: description: |\\n  line one\\n  line two",
    tags: ["multiline", "block scalar", "literal", "folded", "chomping"],
  },
  {
    id: "yaml-anchors",
    topic: "Anchors, aliases and merge keys",
    content:
      "&name defines an anchor; *name reuses it (shared structure). Merge keys <<: *base merge a mapping into another. Common for DRY configs: defaults: &defaults ...  service: <<: *defaults.",
    tags: ["anchor", "alias", "merge", "&", "*", "<<", "dry"],
  },
  {
    id: "yaml-comments",
    topic: "Comments",
    content:
      "Comments start with '#' (after a space) and run to the end of the line. '#' inside a quoted string is literal text, not a comment.",
    tags: ["comment", "hash", "#"],
  },
  {
    id: "yaml-documents",
    topic: "Multiple documents",
    content:
      "A file can hold several YAML documents separated by '---' (start) and optionally '...' (end). Parsers like k8s read one document per '---' separator.",
    tags: ["document", "---", "...", "separator", "multi-doc"],
  },
  {
    id: "yaml-types",
    topic: "Type hints and tags",
    content:
      "Explicit tags change parsing: !!str 5 keeps 5 as a string, !!int '5' parses it as an integer. Rarely needed — rely on plain scalars.",
    tags: ["tag", "!!str", "!!int", "type", "explicit"],
  },
  {
    id: "yaml-common-errors",
    topic: "Common YAML errors",
    content:
      "The big three: tabs in indentation, missing space after ':' (turns the value into a key like 'http://x'), and inconsistent nesting. Tools: yamllint, python -c 'import yaml,sys; yaml.safe_load(sys.stdin)'.",
    tags: ["errors", "yamllint", "validate", "lint", "troubleshoot"],
  },
];

const FALLBACK_CONFIG = `# Generic service configuration
service:
  name: forgekit-service
  version: 1.0.0
  environment: development
http:
  host: 0.0.0.0
  port: 8080
  read_timeout_seconds: 30
logging:
  level: info
  format: json
features:
  - auth
  - metrics
  - health
`;

export class YamlCodingAgent extends BaseCodingAgent {
  constructor(options: { sandbox?: Sandbox; brain?: NeuralBrain; maxIterations?: number } = {}) {
    super({
      name: "yaml-agent",
      language: "yaml",
      knowledge: new KnowledgeBase({ entries: YAML_KNOWLEDGE }),
      sandbox: options.sandbox,
      brain: options.brain,
      maxIterations: options.maxIterations,
    });
  }

  protected override generate(task: string, hints: string[]): string {
    const snippet = matchSnippet(task, YAML_SNIPPETS);
    const header = commentHeader("yaml", this.name, task);
    const hintBlock = hints.length > 0 ? `# Debug notes: ${hints.join("; ")}\n` : "";
    const body = snippet ? snippet.code : FALLBACK_CONFIG;
    return `${header}${hintBlock}${body}`;
  }

  protected override staticValidate(code: string): string[] {
    const issues = defaultStaticChecks(code);
    const lines = code.split("\n");
    for (const [index, line] of lines.entries()) {
      const lineNo = index + 1;
      if (line.includes("\t")) issues.push(`Line ${lineNo}: tabs are not allowed in YAML; use spaces.`);
      const trimmed = line.trim();
      if (trimmed.length === 0 || trimmed.startsWith("#") || trimmed.startsWith("---") || trimmed.startsWith("...")) {
        continue;
      }
      const content = trimmed.startsWith("- ") ? trimmed.slice(2) : trimmed;
      if (content.length === 0) continue;
      const isMap = /^["']?[\w.\-]+["']?\s*:\s/.test(content) || /^["']?[\w.\-]+["']?\s*:\s*$/.test(content);
      const isScalar =
        /^["'][^"']*["']$/.test(content) ||
        /^[-+]?\d+(\.\d+)?$/.test(content) ||
        /^(true|false|null|~|yes|no)$/i.test(content);
      const isAnchor = /^&[\w-]+/.test(content) || /^\*[\w-]+/.test(content) || /^<<:/.test(content);
      if (!isMap && !isScalar && !isAnchor) {
        issues.push(`Line ${lineNo}: "${trimmed.slice(0, 48)}" is not valid YAML — expected "key: value", "- item" or a scalar.`);
      }
    }
    for (const quote of ['"', "'"]) {
      if (countChar(code, quote) % 2 !== 0) issues.push(`Unbalanced ${quote} quote in YAML.`);
    }
    return issues;
  }

  protected override async dynamicValidate(code: string): Promise<DynamicValidation | null> {
    const yamllint = await which("yamllint");
    if (!yamllint) return null;
    const result = await this.sandbox.run(yamllint, ["-"], { input: code, timeoutMs: 30_000 });
    return {
      ok: result.exitCode === 0,
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
    };
  }
}

export function buildYamlKnowledge(): KnowledgeBase {
  return new KnowledgeBase({ entries: YAML_KNOWLEDGE });
}
