/**
 * Diff utilities: LCS-based line and character diffs plus a summary, useful
 * for reviewing what a coding agent changed between iterations.
 */

export interface DiffPart {
  type: "equal" | "add" | "remove";
  value: string;
}

export interface DiffSummary {
  additions: number;
  deletions: number;
  hunks: number;
}

/** Classic LCS on arrays; returns pairs of indices into a and b. */
export function lcsMatches<T>(a: T[], b: T[], equals: (x: T, y: T) => boolean): Array<[number, number]> {
  const n = a.length;
  const m = b.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array<number>(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i]![j] = equals(a[i]!, b[j]!)
        ? dp[i + 1]![j + 1]! + 1
        : Math.max(dp[i + 1]![j]!, dp[i]![j + 1]!);
    }
  }
  const matches: Array<[number, number]> = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (equals(a[i]!, b[j]!)) {
      matches.push([i, j]);
      i += 1;
      j += 1;
    } else if (dp[i + 1]![j]! >= dp[i]![j + 1]!) {
      i += 1;
    } else {
      j += 1;
    }
  }
  return matches;
}

function equalsString(a: string, b: string): boolean {
  return a === b;
}

/** Line-level diff of two texts. */
export function diffLines(a: string, b: string): DiffPart[] {
  const aLines = a.split("\n");
  const bLines = b.split("\n");
  const matches = lcsMatches(aLines, bLines, equalsString);
  return buildDiff(aLines, bLines, matches, "\n");
}

/** Character-level diff of two texts. */
export function diffText(a: string, b: string): DiffPart[] {
  const aChars = [...a];
  const bChars = [...b];
  const matches = lcsMatches(aChars, bChars, equalsString);
  return buildDiff(aChars, bChars, matches, "");
}

function buildDiff(a: string[], b: string[], matches: Array<[number, number]>, join: string): DiffPart[] {
  const parts: DiffPart[] = [];
  let aIndex = 0;
  let bIndex = 0;

  const flush = (type: DiffPart["type"], values: string[]): void => {
    if (values.length === 0) return;
    parts.push({ type, value: values.join(join) });
  };

  for (const [ai, bi] of matches) {
    flush("remove", a.slice(aIndex, ai));
    flush("add", b.slice(bIndex, bi));
    flush("equal", [a[ai]!]);
    aIndex = ai + 1;
    bIndex = bi + 1;
  }
  flush("remove", a.slice(aIndex));
  flush("add", b.slice(bIndex));
  return parts;
}

/** Reconstruct the base text after applying `add`/`remove` parts. */
export function applyDiff(base: string, parts: DiffPart[]): string {
  let out = base;
  for (const part of parts) {
    if (part.type === "remove") {
      out = out.replace(part.value, "");
    }
  }
  for (const part of parts) {
    if (part.type === "add") {
      out += part.value;
    }
  }
  return out;
}

export function diffSummary(parts: DiffPart[]): DiffSummary {
  let additions = 0;
  let deletions = 0;
  let hunks = 0;
  let previousWasChange = false;
  for (const part of parts) {
    if (part.type === "add") {
      additions += part.value.split("\n").length;
      if (!previousWasChange) hunks += 1;
      previousWasChange = true;
    } else if (part.type === "remove") {
      deletions += part.value.split("\n").length;
      if (!previousWasChange) hunks += 1;
      previousWasChange = true;
    } else {
      previousWasChange = false;
    }
  }
  return { additions, deletions, hunks };
}

/** Render a diff as unified-style text (with + / - / space prefixes). */
export function formatDiff(parts: DiffPart[]): string {
  const lines: string[] = [];
  for (const part of parts) {
    const prefix = part.type === "add" ? "+" : part.type === "remove" ? "-" : " ";
    for (const line of part.value.split("\n")) {
      lines.push(`${prefix}${line}`);
    }
  }
  return lines.join("\n");
}
