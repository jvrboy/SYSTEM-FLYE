/**
 * A tiny but real neural network (feed-forward MLP with backpropagation) that
 * gives each agent a "brain" with learning capabilities: train it on labeled
 * feature vectors, or use online skill learning where each outcome nudges a
 * named skill weight between -1 and 1.
 *
 * Deterministic: a given seed always produces the same initialization, so
 * agent swarms are reproducible.
 */

import { mulberry32 } from "../core/utils.js";

export interface TrainSample {
  input: number[];
  output: number[];
}

export interface NeuralBrainOptions {
  sizes: number[];
  seed?: number;
}

function sigmoid(z: number): number {
  if (z >= 700) return 1;
  if (z <= -700) return 0;
  return 1 / (1 + Math.exp(-z));
}

export class NeuralBrain {
  readonly sizes: number[];
  private weights: Float64Array[];
  private biases: Float64Array[];
  private activations: Float64Array[] = [];
  private skills = new Map<string, number>();
  private rand: () => number;

  constructor(options: NeuralBrainOptions) {
    if (options.sizes.length < 2) throw new Error("NeuralBrain needs at least an input and output layer");
    this.sizes = [...options.sizes];
    this.rand = mulberry32(options.seed ?? 1337);
    this.weights = [];
    this.biases = [];
    for (let l = 0; l < this.sizes.length - 1; l++) {
      const inSize = this.sizes[l]!;
      const outSize = this.sizes[l + 1]!;
      const w = new Float64Array(inSize * outSize);
      const scale = Math.sqrt(2 / inSize);
      for (let i = 0; i < w.length; i++) w[i] = (this.rand() * 2 - 1) * scale;
      this.weights.push(w);
      const b = new Float64Array(outSize);
      for (let i = 0; i < b.length; i++) b[i] = (this.rand() * 2 - 1) * 0.1;
      this.biases.push(b);
    }
  }

  /** Forward pass; returns the output layer activations (0..1 each). */
  forward(input: number[]): number[] {
    if (input.length !== this.sizes[0]) {
      throw new Error(`Expected ${this.sizes[0]} inputs, got ${input.length}`);
    }
    this.activations = [Float64Array.from(input)];
    for (let l = 0; l < this.weights.length; l++) {
      const w = this.weights[l]!;
      const b = this.biases[l]!;
      const inSize = this.sizes[l]!;
      const outSize = this.sizes[l + 1]!;
      const prev = this.activations[l]!;
      const next = new Float64Array(outSize);
      for (let j = 0; j < outSize; j++) {
        let z = b[j]!;
        for (let i = 0; i < inSize; i++) z += w[j * inSize + i]! * prev[i]!;
        next[j] = sigmoid(z);
      }
      this.activations.push(next);
    }
    return [...this.activations[this.activations.length - 1]!];
  }

  predict(input: number[]): number[] {
    return this.forward(input);
  }

  /** Argmax class index of a prediction. */
  predictClass(input: number[]): number {
    const out = this.forward(input);
    let best = 0;
    let bestValue = -Infinity;
    for (let i = 0; i < out.length; i++) {
      if (out[i]! > bestValue) {
        bestValue = out[i]!;
        best = i;
      }
    }
    return best;
  }

  /** Train with backpropagation (stochastic gradient descent). Returns final MSE. */
  train(samples: TrainSample[], options: { epochs?: number; learningRate?: number } = {}): number {
    const epochs = options.epochs ?? 100;
    const lr = options.learningRate ?? 0.5;
    let loss = Number.POSITIVE_INFINITY;
    for (let epoch = 0; epoch < epochs; epoch++) {
      let epochLoss = 0;
      for (const sample of samples) {
        this.forward(sample.input);
        epochLoss += this.backprop(sample.output, lr);
      }
      loss = epochLoss / samples.length;
    }
    return loss;
  }

  private backprop(target: number[], lr: number): number {
    const L = this.sizes.length - 1;
    const out = this.activations[L]!;
    let loss = 0;
    let delta = new Float64Array(this.sizes[L]!);
    for (let j = 0; j < this.sizes[L]!; j++) {
      const error = out[j]! - target[j]!;
      loss += error * error;
      delta[j] = error * out[j]! * (1 - out[j]!);
    }
    // Backpropagate from the last layer to the first.
    for (let l = L - 1; l >= 0; l--) {
      const w = this.weights[l]!;
      const b = this.biases[l]!;
      const prev = this.activations[l]!;
      const inSize = this.sizes[l]!;
      const outSize = this.sizes[l + 1]!;
      const nextDelta = l > 0 ? new Float64Array(inSize) : null;
      for (let j = 0; j < outSize; j++) {
        for (let i = 0; i < inSize; i++) {
          if (nextDelta) nextDelta[i]! += delta[j]! * w[j * inSize + i]!;
          w[j * inSize + i]! -= lr * delta[j]! * prev[i]!;
        }
        b[j]! -= lr * delta[j]!;
      }
      if (nextDelta) {
        for (let i = 0; i < inSize; i++) {
          nextDelta[i] = nextDelta[i]! * prev[i]! * (1 - prev[i]!);
        }
        delta = nextDelta;
      }
    }
    return loss;
  }

  /** Online skill learning: nudge a named skill weight in [-1, 1]. */
  learn(skill: string, delta: number): void {
    const current = this.skills.get(skill) ?? 0;
    this.skills.set(skill, Math.max(-1, Math.min(1, current + delta)));
  }

  getSkill(skill: string): number {
    return this.skills.get(skill) ?? 0;
  }

  setSkill(skill: string, value: number): void {
    this.skills.set(skill, Math.max(-1, Math.min(1, value)));
  }

  skillsSnapshot(): Record<string, number> {
    return Object.fromEntries(this.skills);
  }

  /** Fresh brain with the same architecture, re-seeded (deterministic). */
  clone(seed?: number): NeuralBrain {
    const clone = new NeuralBrain({ sizes: this.sizes, seed: seed ?? 1337 });
    for (const [skill, value] of this.skills) clone.setSkill(skill, value);
    return clone;
  }

  describe(): string {
    return `NeuralBrain(${this.sizes.join(" → ")})`;
  }
}
