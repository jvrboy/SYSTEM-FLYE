/**
 * Error hierarchy for ForgeKit. Every error carries a stable machine-readable
 * `code` so callers can switch on it instead of string-matching messages.
 */

export class ForgeKitError extends Error {
  readonly code: string;
  readonly details?: Record<string, unknown>;

  constructor(code: string, message: string, details?: Record<string, unknown>) {
    super(message);
    this.name = new.target.name;
    this.code = code;
    this.details = details;
  }
}

export class SandboxError extends ForgeKitError {
  constructor(message: string, details?: Record<string, unknown>) {
    super("SANDBOX_ERROR", message, details);
  }
}

export class AgentError extends ForgeKitError {
  constructor(message: string, details?: Record<string, unknown>) {
    super("AGENT_ERROR", message, details);
  }
}

export class CsvError extends ForgeKitError {
  constructor(message: string, details?: Record<string, unknown>) {
    super("CSV_ERROR", message, details);
  }
}

export class PdfError extends ForgeKitError {
  constructor(message: string, details?: Record<string, unknown>) {
    super("PDF_ERROR", message, details);
  }
}

export class ForexError extends ForgeKitError {
  constructor(message: string, details?: Record<string, unknown>) {
    super("FOREX_ERROR", message, details);
  }
}

export class TemplateError extends ForgeKitError {
  constructor(message: string, details?: Record<string, unknown>) {
    super("TEMPLATE_ERROR", message, details);
  }
}

/** Coerce anything throwable into an Error instance. */
export function toError(value: unknown): Error {
  if (value instanceof Error) return value;
  if (typeof value === "string") return new Error(value);
  try {
    return new Error(JSON.stringify(value));
  } catch {
    return new Error(String(value));
  }
}
