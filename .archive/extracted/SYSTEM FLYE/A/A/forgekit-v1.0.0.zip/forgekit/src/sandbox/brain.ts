/**
 * The sandbox brain: looks at a failed run and *reports errors* — classifying
 * what went wrong (timeout, missing command, syntax, permission, runtime) with
 * evidence and confidence, then suggests concrete fixes. The `agenticRun`
 * method loops: run → diagnose → apply the best fix → re-run.
 */

import type { MicroKernel, KernelTask } from "./kernel.js";
import type { ProcessResult, RunOptions } from "../core/types.js";

export type ErrorKind =
  | "ok"
  | "timeout"
  | "output-limit"
  | "not-found"
  | "permission"
  | "syntax"
  | "runtime"
  | "unknown";

export interface BrainDiagnosis {
  kind: ErrorKind;
  message: string;
  confidence: number;
  evidence: string[];
}

export interface FixSuggestion {
  id: string;
  title: string;
  description: string;
  /** When present, re-running with these options is the fix. */
  retry?: { options: RunOptions };
}

export interface AgenticAttempt {
  attempt: number;
  result: ProcessResult;
  diagnosis: BrainDiagnosis;
  fixes: FixSuggestion[];
}

export interface AgenticRunReport {
  task: KernelTask;
  attempts: AgenticAttempt[];
  conclusion: "success" | "failure";
  finalDiagnosis: BrainDiagnosis;
}

const NOT_FOUND =
  /command not found|ENOENT|No such file or directory|is not recognized as an internal or external command|\.\w+: not found|not found in PATH/i;
const PERMISSION = /permission denied|EACCES|EPERM|operation not permitted/i;
const SYNTAX = /syntaxerror|syntax error|parseerror|unexpected token|invalid or unexpected token|invalid syntax|expected[^\n]*;|unexpected identifier/i;

export class SandboxBrain {
  diagnose(result: ProcessResult): BrainDiagnosis {
    const evidence: string[] = [];
    const haystack = `${result.stderr}\n${result.stdout}`;

    if (result.timedOut) {
      evidence.push(`Timed out after ${result.durationMs}ms`);
      return {
        kind: "timeout",
        message: `The command exceeded the time limit (${result.durationMs}ms).`,
        confidence: 0.98,
        evidence,
      };
    }
    if (result.outputLimitExceeded) {
      evidence.push("Output exceeded maxBuffer");
      return {
        kind: "output-limit",
        message: "The command produced too much output and was terminated.",
        confidence: 0.98,
        evidence,
      };
    }
    if (result.exitCode === 0) {
      return { kind: "ok", message: "Command completed successfully.", confidence: 1, evidence: [] };
    }
    if (NOT_FOUND.test(haystack)) {
      evidence.push(haystack.trim().split("\n")[0] ?? "command not found");
      return {
        kind: "not-found",
        message: "A required command or file was not found.",
        confidence: 0.9,
        evidence,
      };
    }
    if (PERMISSION.test(haystack)) {
      evidence.push(haystack.trim().split("\n")[0] ?? "permission denied");
      return {
        kind: "permission",
        message: "The command was denied permission to do what it attempted.",
        confidence: 0.9,
        evidence,
      };
    }
    if (SYNTAX.test(haystack)) {
      evidence.push(haystack.trim().split("\n")[0] ?? "syntax error");
      return {
        kind: "syntax",
        message: "The input could not be parsed (syntax error).",
        confidence: 0.85,
        evidence,
      };
    }
    if (result.exitCode !== null && result.exitCode > 0) {
      evidence.push(`exit code ${result.exitCode}`);
      return {
        kind: "runtime",
        message: "The command ran but failed at runtime.",
        confidence: 0.7,
        evidence,
      };
    }
    return { kind: "unknown", message: "The failure could not be classified.", confidence: 0.3, evidence };
  }

  suggestFixes(diagnosis: BrainDiagnosis, task: KernelTask): FixSuggestion[] {
    const baseTimeout = task.options?.timeoutMs ?? 30_000;
    const baseBuffer = task.options?.maxBuffer ?? 8 * 1024 * 1024;
    switch (diagnosis.kind) {
      case "timeout":
        return [
          {
            id: "increase-timeout",
            title: "Increase the time limit",
            description: `The run needs more than ${baseTimeout}ms. Retrying with ${baseTimeout * 4}ms.`,
            retry: { options: { timeoutMs: baseTimeout * 4 } },
          },
          {
            id: "reduce-work",
            title: "Reduce the workload",
            description: "If it still times out, the task itself may be too heavy (infinite loop, huge input).",
          },
        ];
      case "output-limit":
        return [
          {
            id: "increase-buffer",
            title: "Allow more output",
            description: `Retrying with a larger output buffer (${baseBuffer * 4} bytes).`,
            retry: { options: { maxBuffer: baseBuffer * 4 } },
          },
          {
            id: "redirect-output",
            title: "Redirect or trim output",
            description: "Pipe output through head/tail or write it to a file instead of stdout.",
          },
        ];
      case "not-found":
        return [
          {
            id: "check-path",
            title: "Check PATH / installation",
            description:
              "The executable is missing. Verify it is installed, or pass an absolute path via options.cwd/env.",
          },
        ];
      case "permission":
        return [
          {
            id: "fix-permissions",
            title: "Fix permissions",
            description: "Grant execute permission (chmod +x) or run with the right user. Also check options.cwd exists.",
          },
        ];
      case "syntax":
        return [
          {
            id: "fix-syntax",
            title: "Fix syntax / quoting",
            description: "Inspect the first error line and correct quoting, escaping or structure before retrying.",
          },
        ];
      case "runtime":
        return [
          {
            id: "inspect-runtime",
            title: "Inspect the runtime error",
            description: `Read the traceback/error message: ${diagnosis.evidence[0] ?? "see stderr"}.`,
          },
        ];
      default:
        return [
          {
            id: "inspect-output",
            title: "Inspect the full output",
            description: "The failure was not classified; read stdout/stderr for clues.",
          },
        ];
    }
  }

  /** Run a task, diagnose failures, apply the best retryable fix and repeat. */
  async agenticRun(
    kernel: MicroKernel,
    task: KernelTask,
    options: { maxAttempts?: number } = {},
  ): Promise<AgenticRunReport> {
    const maxAttempts = options.maxAttempts ?? 3;
    const attempts: AgenticAttempt[] = [];
    let currentTask: KernelTask = task;
    let finalDiagnosis: BrainDiagnosis | null = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const { result } = await kernel.execute(currentTask);
      const diagnosis = this.diagnose(result);
      const fixes = this.suggestFixes(diagnosis, currentTask);
      attempts.push({ attempt, result, diagnosis, fixes });
      finalDiagnosis = diagnosis;
      if (diagnosis.kind === "ok") {
        return { task, attempts, conclusion: "success", finalDiagnosis: diagnosis };
      }
      const retryFix = fixes.find((fix) => fix.retry);
      if (!retryFix?.retry) break;
      currentTask = {
        ...currentTask,
        options: { ...(currentTask.options ?? {}), ...retryFix.retry.options },
      };
    }

    return {
      task,
      attempts,
      conclusion: "failure",
      finalDiagnosis: finalDiagnosis ?? {
        kind: "unknown",
        message: "No diagnosis produced.",
        confidence: 0,
        evidence: [],
      },
    };
  }
}
