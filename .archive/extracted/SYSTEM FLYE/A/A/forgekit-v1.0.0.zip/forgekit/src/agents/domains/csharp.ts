/**
 * C# coding agent: embedded C#/.NET knowledge, generators, static checks and
 * best-effort compilation when the .NET SDK (`dotnet`) is installed.
 */

import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { BaseCodingAgent, defaultStaticChecks, type DynamicValidation } from "../base.js";
import { KnowledgeBase, type KnowledgeEntry } from "../knowledge.js";
import { NeuralBrain } from "../brain.js";
import type { Sandbox } from "../../sandbox/index.js";
import { isAvailable } from "../../sandbox/runner.js";
import { matchSnippet, CSHARP_SNIPPETS } from "../../coding/snippets.js";
import { commentHeader } from "../../coding/generate.js";

const CSHARP_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "csharp-structure",
    topic: "Program structure and Main",
    content:
      "A console program needs a static void Main(string[] args) entry point. Modern .NET also supports top-level statements (statements without a class). Every class member ends with ';'. Program.cs with 'using System;' at the top is the standard scaffold.",
    tags: ["program", "main", "entry", "top-level", "console"],
    errors: [
      {
        id: "csharp-using-missing",
        pattern: /CS0246: The type or namespace name ['"]?(\w+)['"]? could not be found/i.source,
        explanation: "A type or namespace is missing — usually a missing using directive or reference.",
        hint: "Add the required 'using X;' directive or a NuGet reference, and check spelling.",
      },
      {
        id: "csharp-semicolon",
        pattern: /CS1002: ; expected/i.source,
        explanation: "A statement is missing its terminating semicolon.",
        hint: "End the statement on the reported line with ';'.",
      },
      {
        id: "csharp-name",
        pattern: /CS0103: The name ['"]?(\w+)['"]? does not exist in the current context/i.source,
        explanation: "An identifier is undefined in this scope.",
        hint: "Declare the variable/method or fix the spelling; check scope braces.",
      },
      {
        id: "csharp-brace",
        pattern: /CS1513: } expected/i.source,
        explanation: "A closing brace is missing.",
        hint: "Count your braces — a class or method block is unclosed.",
      },
    ],
  },
  {
    id: "csharp-types",
    topic: "Value types",
    content:
      "int (32-bit), long (64-bit), double, float, decimal, bool, char. int division truncates — use double for fractions (e.g. (double)a / b). var infers the type at compile time.",
    tags: ["types", "int", "double", "var", "bool", "decimal"],
  },
  {
    id: "csharp-classes",
    topic: "Classes, objects and properties",
    content:
      "class Name { ... } defines a type; new Name() creates an instance. Properties use { get; set; } accessors. Fields are private by convention; methods are PascalCase. Use records for immutable data carriers: record Point(int X, int Y);",
    tags: ["class", "object", "new", "property", "record", "method"],
  },
  {
    id: "csharp-control-flow",
    topic: "Control flow",
    content:
      "if/else, for, foreach (foreach (var item in collection)), while, do/while and switch statements. switch can use pattern matching: case int n when n > 0:.",
    tags: ["if", "for", "foreach", "while", "switch", "loop"],
  },
  {
    id: "csharp-collections",
    topic: "Collections",
    content:
      "Arrays: int[] xs = new int[3]; Lists: List<int> xs = new() { 1, 2, 3 }; Dictionary<string, int> map = new(); foreach and LINQ work over all of them.",
    tags: ["array", "list", "dictionary", "collection", "ienumerable"],
  },
  {
    id: "csharp-linq",
    topic: "LINQ",
    content:
      "Requires 'using System.Linq;'. Key operators: Where, Select, OrderBy/OrderByDescending, First/FirstOrDefault, Any, All, Sum, Count, GroupBy. LINQ is lazy — materialize with ToList()/ToArray() when needed.",
    tags: ["linq", "where", "select", "orderby", "firstordefault", "groupby"],
  },
  {
    id: "csharp-async",
    topic: "Async/await and Task",
    content:
      "async methods return Task or Task<T>; Main can be 'static async Task Main(...)'. await suspends without blocking the thread. Never block on async (no .Result/.Wait() in async code). Use Task.WhenAll for parallel awaits.",
    tags: ["async", "await", "task", "whenall", "thread"],
  },
  {
    id: "csharp-strings",
    topic: "Strings and interpolation",
    content:
      "Strings are immutable. Interpolate with $\"...{variable}\" (requires the $ prefix). Multi-line raw strings: string s = \"\"\" ... \"\"\";. StringBuilder for heavy concatenation.",
    tags: ["string", "interpolation", "stringbuilder", "format"],
  },
  {
    id: "csharp-nullability",
    topic: "Nullability",
    content:
      "Reference types are nullable by default in old projects; nullable reference types (NRT) add '?' markers. Guard with x is null / x?.Member and the null-coalescing operator ??.",
    tags: ["null", "nullable", "null-coalescing", "nrt", "guard"],
  },
  {
    id: "csharp-errors",
    topic: "Reading compiler errors",
    content:
      "C# errors start with a CSxxxx code. CS1002 = missing ';', CS0103 = unknown name, CS0246 = missing type/using, CS1513 = missing '}', CS0161 = not all code paths return a value.",
    tags: ["errors", "cs1002", "cs0103", "cs0246", "cs1513", "compiler"],
  },
];

const FALLBACK_PROGRAM = `using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("forgekit csharp agent: hello");
    }
}
`;

export class CSharpCodingAgent extends BaseCodingAgent {
  constructor(options: { sandbox?: Sandbox; brain?: NeuralBrain; maxIterations?: number } = {}) {
    super({
      name: "csharp-agent",
      language: "csharp",
      knowledge: new KnowledgeBase({ entries: CSHARP_KNOWLEDGE }),
      sandbox: options.sandbox,
      brain: options.brain,
      maxIterations: options.maxIterations,
    });
  }

  protected override generate(task: string, hints: string[]): string {
    const snippet = matchSnippet(task, CSHARP_SNIPPETS);
    const header = commentHeader("csharp", this.name, task);
    const hintBlock = hints.length > 0 ? `// Debug notes: ${hints.join("; ")}\n` : "";
    const body = snippet ? snippet.code : FALLBACK_PROGRAM;
    return `${header}${hintBlock}${body}`;
  }

  protected override staticValidate(code: string): string[] {
    const issues = defaultStaticChecks(code);
    if (!/\bMain\s*\(/.test(code)) issues.push("C# console programs need a Main entry point.");
    if (!/\busing\s+\w+/.test(code)) issues.push("C# files should start with using directives.");
    if (/\bclass\s+\w+/.test(code) === false) issues.push("No class declaration found.");
    return issues;
  }

  protected override async dynamicValidate(code: string): Promise<DynamicValidation | null> {
    const dotnet = await isAvailable("dotnet");
    if (!dotnet) return null;
    const dir = await mkdtemp(join(tmpdir(), "forgekit-cs-"));
    try {
      await writeFile(join(dir, "Program.cs"), code, "utf8");
      await writeFile(
        join(dir, "forgekit.csproj"),
        `<Project Sdk="Microsoft.NET.Sdk">\n  <PropertyGroup>\n    <OutputType>Exe</OutputType>\n    <TargetFramework>net8.0</TargetFramework>\n    <Nullable>disable</Nullable>\n    <ImplicitUsings>disable</ImplicitUsings>\n  </PropertyGroup>\n</Project>\n`,
        "utf8",
      );
      const result = await this.sandbox.run("dotnet", ["build", "--nologo", "-v", "q"], {
        cwd: dir,
        timeoutMs: 120_000,
        maxBuffer: 2 * 1024 * 1024,
      });
      return {
        ok: result.exitCode === 0,
        stdout: result.stdout,
        stderr: result.stderr,
        exitCode: result.exitCode,
      };
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }
}

export function buildCSharpKnowledge(): KnowledgeBase {
  return new KnowledgeBase({ entries: CSHARP_KNOWLEDGE });
}
