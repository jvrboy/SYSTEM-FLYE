/**
 * Forex data helpers: a currency-pair catalogue with pip definitions,
 * deterministic candle generation for demos/tests, and pip math.
 */

import type { Ohlc } from "../core/types.js";
import { mulberry32 } from "../core/utils.js";

export interface FxPair {
  symbol: string;
  base: string;
  quote: string;
  /** Price change equal to one pip. */
  pip: number;
  /** Decimal places used when quoting the pair. */
  pipDecimal: number;
  label: string;
}

export const FX_PAIRS: FxPair[] = [
  { symbol: "EURUSD", base: "EUR", quote: "USD", pip: 0.0001, pipDecimal: 5, label: "Euro / US Dollar" },
  { symbol: "GBPUSD", base: "GBP", quote: "USD", pip: 0.0001, pipDecimal: 5, label: "British Pound / US Dollar" },
  { symbol: "USDJPY", base: "USD", quote: "JPY", pip: 0.01, pipDecimal: 3, label: "US Dollar / Japanese Yen" },
  { symbol: "AUDUSD", base: "AUD", quote: "USD", pip: 0.0001, pipDecimal: 5, label: "Australian Dollar / US Dollar" },
  { symbol: "NZDUSD", base: "NZD", quote: "USD", pip: 0.0001, pipDecimal: 5, label: "New Zealand Dollar / US Dollar" },
  { symbol: "USDCHF", base: "USD", quote: "CHF", pip: 0.0001, pipDecimal: 5, label: "US Dollar / Swiss Franc" },
  { symbol: "USDCAD", base: "USD", quote: "CAD", pip: 0.0001, pipDecimal: 5, label: "US Dollar / Canadian Dollar" },
  { symbol: "EURGBP", base: "EUR", quote: "GBP", pip: 0.0001, pipDecimal: 5, label: "Euro / British Pound" },
  { symbol: "EURJPY", base: "EUR", quote: "JPY", pip: 0.01, pipDecimal: 3, label: "Euro / Japanese Yen" },
  { symbol: "GBPJPY", base: "GBP", quote: "JPY", pip: 0.01, pipDecimal: 3, label: "British Pound / Japanese Yen" },
  { symbol: "XAUUSD", base: "XAU", quote: "USD", pip: 0.1, pipDecimal: 2, label: "Gold / US Dollar" },
  { symbol: "XAGUSD", base: "XAG", quote: "USD", pip: 0.01, pipDecimal: 3, label: "Silver / US Dollar" },
];

const PAIR_INDEX = new Map(FX_PAIRS.map((pair) => [pair.symbol, pair]));

export function getFxPair(symbol: string): FxPair {
  const pair = PAIR_INDEX.get(symbol.toUpperCase());
  if (!pair) throw new Error(`Unknown FX pair: ${symbol}`);
  return pair;
}

export function toPips(priceDiff: number, symbol: string): number {
  return priceDiff / getFxPair(symbol).pip;
}

export function roundToPip(price: number, symbol: string): number {
  const pair = getFxPair(symbol);
  const factor = 1 / pair.pip;
  return Math.round(price * factor) / factor;
}

export interface GenerateBarsOptions {
  count?: number;
  start?: number;
  intervalSeconds?: number;
  seed?: number;
  startPrice?: number;
  /** Drift per bar as a fraction (e.g. 0.0001). */
  drift?: number;
  /** Volatility per bar as a fraction. */
  volatility?: number;
  volumeBase?: number;
}

/** Deterministic synthetic candles (seeded random walk). */
export function generateBars(options: GenerateBarsOptions = {}): Ohlc[] {
  const count = options.count ?? 250;
  const intervalSeconds = options.intervalSeconds ?? 60;
  const start = options.start ?? Math.floor(Date.now() / 1000) - count * intervalSeconds;
  const rand = mulberry32(options.seed ?? 42);
  const drift = options.drift ?? 0.0001;
  const volatility = options.volatility ?? 0.0012;
  const volumeBase = options.volumeBase ?? 100;

  const bars: Ohlc[] = [];
  let price = options.startPrice ?? 1.1;
  let time = Math.floor(start / intervalSeconds) * intervalSeconds;

  for (let i = 0; i < count; i++) {
    const open = price;
    const shock = (rand() - 0.5) * 2;
    const move = price * (drift + shock * volatility);
    const close = Math.max(0.0001, open + move);
    const wick = Math.abs(open - close) * (0.2 + rand() * 0.8) + price * volatility * 0.2;
    const high = Math.max(open, close) + wick * rand();
    const low = Math.min(open, close) - wick * rand();
    bars.push({
      time,
      open,
      high,
      low,
      close,
      volume: Math.round(volumeBase * (0.5 + rand())),
    });
    price = close;
    time += intervalSeconds;
  }
  return bars;
}

/** Convert an interval like "1m", "4h", "1d" to seconds. */
export function intervalSeconds(interval: string): number {
  const match = /^(\d+)(s|m|h|d|w)$/.exec(interval.trim().toLowerCase());
  if (!match) throw new Error(`Invalid interval: "${interval}"`);
  const value = Number(match[1]);
  const unit = match[2];
  const seconds = unit === "s" ? 1 : unit === "m" ? 60 : unit === "h" ? 3600 : unit === "d" ? 86400 : 604800;
  return value * seconds;
}
