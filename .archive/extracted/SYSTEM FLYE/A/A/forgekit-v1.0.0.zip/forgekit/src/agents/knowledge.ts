/**
 * Domain knowledge for coding agents.
 *
 * A `KnowledgeBase` stores structured entries (topic, content, tags) and a
 * library of error patterns. Agents retrieve knowledge by semantic similarity
 * and match error text against patterns to produce diagnostics + fixes.
 */

import { cosineSimilarity } from "../core/utils.js";

export interface ErrorPattern {
  id: string;
  /** Regex source, matched case-insensitively against error output. */
  pattern: string;
  /** Plain-language explanation of the error. */
  explanation: string;
  /** Concrete advice injected into the debug loop. */
  hint: string;
  /** Optional exact-string patch applied to the code (from → to). */
  patch?: { from: string; to: string };
}

export interface KnowledgeEntry {
  id: string;
  topic: string;
  content: string;
  tags: string[];
  errors?: ErrorPattern[];
}

export interface ErrorMatch {
  entry: KnowledgeEntry | null;
  pattern: ErrorPattern;
  match: string;
}

/**
 * Error patterns shared by every agent: language-agnostic failure modes.
 * Domain agents add their own on top of these.
 */
export const GLOBAL_ERROR_LIBRARY: ErrorPattern[] = [
  {
    id: "js-reference-error",
    pattern: /ReferenceError: (\w+) is not defined/i.source,
    explanation: "A variable/function was used before it was declared.",
    hint: "Ensure the identifier is declared and in scope before use; check spelling.",
  },
  {
    id: "js-syntax-error",
    pattern: /SyntaxError: ([^\n]*)/i.source,
    explanation: "The code cannot be parsed.",
    hint: "Fix the syntax: look for missing brackets, commas, quotes or semicolons near the reported position.",
  },
  {
    id: "js-type-error",
    pattern: /TypeError: ([^\n]*)/i.source,
    explanation: "A value was used with the wrong type or method.",
    hint: "Check the offending value: null/undefined handling, wrong argument order, or a missing method.",
  },
  {
    id: "python-name-error",
    pattern: /NameError: name ['"]?(\w+)['"]? is not defined/i.source,
    explanation: "A Python name was used before it was defined.",
    hint: "Define the variable/function before use, and check spelling and scope.",
  },
  {
    id: "python-indentation-error",
    pattern: /IndentationError: ([^\n]*)/i.source,
    explanation: "Python is whitespace-sensitive and the indentation is inconsistent.",
    hint: "Use consistent indentation (spaces, never tabs) for every block.",
  },
  {
    id: "python-syntax-error",
    pattern: /SyntaxError: ([^\n]*)/i.source,
    explanation: "The Python code cannot be parsed.",
    hint: "Check for missing colons, parentheses, quotes or commas at the reported line.",
  },
  {
    id: "python-traceback",
    pattern: /Traceback \(most recent call last\)/i.source,
    explanation: "The Python program raised an unhandled exception.",
    hint: "Read the last line of the traceback and fix the exception at its source.",
  },
  {
    id: "csharp-compiler-error",
    pattern: /CS\d{4}: ([^\n]*)/i.source,
    explanation: "The C# compiler reported an error code.",
    hint: "Look up the CSxxxx code and fix the reported line (missing ';', undeclared name, missing using, etc.).",
  },
  {
    id: "arduino-compile-fail",
    pattern: /exit status 1/i.source,
    explanation: "The Arduino sketch failed to compile.",
    hint: "Read the compiler errors above: missing library include, undeclared pin/function, or type mismatch.",
  },
  {
    id: "yaml-structure-error",
    pattern: /mapping values are not allowed|expected <block end>|found character[^\n]*cannot start any token|tabs are not allowed/i.source,
    explanation: "The YAML structure is invalid.",
    hint: "Fix indentation (spaces, no tabs), check that keys end with ':' and list items start with '- '.",
  },
  {
    id: "generic-error",
    pattern: /(^|\n)[^\n]*[Ee]rror[^\n]*/i.source,
    explanation: "An error was reported by the runtime or compiler.",
    hint: "Read the error line for the exact cause before retrying.",
  },
];

export interface KnowledgeBaseOptions {
  entries?: KnowledgeEntry[];
  /** Include the shared error library (default true). */
  includeGlobalErrors?: boolean;
}

export class KnowledgeBase {
  private entries: KnowledgeEntry[];
  private globalErrors: ErrorPattern[];

  constructor(options: KnowledgeBaseOptions = {}) {
    this.entries = [...(options.entries ?? [])];
    this.globalErrors = options.includeGlobalErrors === false ? [] : [...GLOBAL_ERROR_LIBRARY];
  }

  add(entry: KnowledgeEntry): this {
    this.entries.push(entry);
    return this;
  }

  addAll(entries: KnowledgeEntry[]): this {
    for (const entry of entries) this.add(entry);
    return this;
  }

  get size(): number {
    return this.entries.length;
  }

  get entriesList(): readonly KnowledgeEntry[] {
    return this.entries;
  }

  get errorPatternCount(): number {
    return this.globalErrors.length + this.entries.reduce((n, e) => n + (e.errors?.length ?? 0), 0);
  }

  /** Retrieve the most relevant entries for a query. */
  search(query: string, options: { limit?: number; minScore?: number } = {}): KnowledgeEntry[] {
    const limit = options.limit ?? 5;
    const minScore = options.minScore ?? 0.02;
    const scored = this.entries
      .map((entry) => {
        const haystack = `${entry.topic} ${entry.tags.join(" ")} ${entry.content}`;
        return { entry, score: cosineSimilarity(query, haystack) };
      })
      .filter((s) => s.score >= minScore)
      .sort((a, b) => b.score - a.score);
    return scored.slice(0, limit).map((s) => s.entry);
  }

  /** Match error text against every known error pattern (global + entry-level). */
  findErrorPatterns(text: string): ErrorMatch[] {
    const matches: ErrorMatch[] = [];
    const seen = new Set<string>();
    for (const pattern of this.globalErrors) {
      const re = new RegExp(pattern.pattern, "i");
      const found = re.exec(text);
      if (found && !seen.has(pattern.id)) {
        seen.add(pattern.id);
        matches.push({ entry: null, pattern, match: found[0] });
      }
    }
    for (const entry of this.entries) {
      for (const pattern of entry.errors ?? []) {
        if (seen.has(pattern.id)) continue;
        const re = new RegExp(pattern.pattern, "i");
        const found = re.exec(text);
        if (found) {
          seen.add(pattern.id);
          matches.push({ entry, pattern, match: found[0] });
        }
      }
    }
    return matches;
  }
}
