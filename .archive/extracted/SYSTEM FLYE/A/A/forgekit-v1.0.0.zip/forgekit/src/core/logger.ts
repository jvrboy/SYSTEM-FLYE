/**
 * Minimal leveled logger with namespaced children.
 */

export type LogLevel = "debug" | "info" | "warn" | "error" | "silent";

const LEVEL_ORDER: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  silent: 99,
};

export interface LoggerOptions {
  level?: LogLevel;
  prefix?: string;
}

export class Logger {
  readonly prefix: string;
  private level: LogLevel;

  constructor(options: LoggerOptions = {}) {
    this.level = options.level ?? (process.env.FORGEKIT_LOG_LEVEL as LogLevel | undefined) ?? "info";
    this.prefix = options.prefix ?? "forgekit";
  }

  setLevel(level: LogLevel): void {
    this.level = level;
  }

  getLevel(): LogLevel {
    return this.level;
  }

  child(prefix: string): Logger {
    return new Logger({ level: this.level, prefix: `${this.prefix}:${prefix}` });
  }

  debug(message: string, meta?: unknown): void {
    this.write("debug", message, meta);
  }

  info(message: string, meta?: unknown): void {
    this.write("info", message, meta);
  }

  warn(message: string, meta?: unknown): void {
    this.write("warn", message, meta);
  }

  error(message: string, meta?: unknown): void {
    this.write("error", message, meta);
  }

  private write(level: LogLevel, message: string, meta?: unknown): void {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[this.level]) return;
    const stamp = new Date().toISOString();
    const line = `[${stamp}] ${level.toUpperCase().padEnd(5)} ${this.prefix}: ${message}`;
    if (level === "error") {
      console.error(meta === undefined ? line : `${line} ${safeStringify(meta)}`);
    } else {
      console.log(meta === undefined ? line : `${line} ${safeStringify(meta)}`);
    }
  }
}

function safeStringify(value: unknown): string {
  try {
    const out = JSON.stringify(value);
    return out === undefined ? String(value) : out;
  } catch {
    return String(value);
  }
}

export const logger = new Logger();
