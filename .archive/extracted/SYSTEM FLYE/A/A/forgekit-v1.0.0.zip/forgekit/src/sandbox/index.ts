/**
 * The ForgeKit Sandbox: run CMD, bash, shell, JavaScript and Python from your
 * TypeScript backend — with micro-kernels, a performance cache, a warm Node
 * worker pool, adaptive concurrency and an agentic brain that reports errors
 * and retries with fixes.
 *
 * ```ts
 * const sandbox = new Sandbox({ concurrency: 4 });
 * const out = await sandbox.python("print(sum(range(100)))"); // "4950"
 * const report = await sandbox.agentic({ kind: "shell", payload: "sleep 999" });
 * ```
 */

import { Logger } from "../core/logger.js";
import { KernelPool, type KernelTask, type KernelTaskKind, type PoolStats } from "./kernel.js";
import { SandboxBrain, type AgenticRunReport } from "./brain.js";
import {
  AdaptiveConcurrency,
  ExecutionCache,
  NodeWorkerPool,
  type WorkerTaskResult,
} from "./boosters.js";
import type { ProcessResult, RunOptions } from "../core/types.js";

export * from "./runner.js";
export * from "./kernel.js";
export * from "./brain.js";
export * from "./boosters.js";

export interface SandboxOptions {
  /** Number of parallel kernels (default 4). */
  concurrency?: number;
  /** Enable the execution cache (default true). */
  cache?: boolean | ExecutionCache;
  /** Number of warm Node worker processes (default 0 = disabled). */
  warmWorkers?: number;
  /** Adaptive concurrency limiter. */
  adaptive?: AdaptiveConcurrency;
  logger?: Logger;
}

export interface SandboxStats {
  pool: PoolStats;
  cache: { hits: number; misses: number; size: number };
  workers: { workers: number; completed: number; failures: number };
  adaptive: { active: number; limit: number; waiting: number };
}

export class Sandbox {
  readonly pool: KernelPool;
  readonly brain: SandboxBrain;
  readonly cache: ExecutionCache | null;
  readonly workers: NodeWorkerPool | null;
  readonly adaptive: AdaptiveConcurrency | null;
  private readonly logger: Logger;

  constructor(options: SandboxOptions = {}) {
    this.logger = options.logger ?? new Logger({ prefix: "sandbox" });
    this.pool = new KernelPool(options.concurrency ?? 4);
    this.brain = new SandboxBrain();
    this.cache = options.cache === false ? null : options.cache instanceof ExecutionCache ? options.cache : new ExecutionCache();
    this.workers = options.warmWorkers && options.warmWorkers > 0 ? new NodeWorkerPool({ size: options.warmWorkers }) : null;
    this.adaptive = options.adaptive ?? null;
  }

  private async runViaPool(task: KernelTask): Promise<ProcessResult> {
    const permit = this.adaptive ? await this.adaptive.acquire() : null;
    try {
      if (this.cache) {
        const cached = this.cache.get(task);
        if (cached) return cached;
      }
      const { result } = await this.pool.submit(task);
      if (this.cache) this.cache.put(task, result);
      return result;
    } finally {
      if (permit) permit();
    }
  }

  /** Run a raw command with argv. */
  run(command: string, args: string[] = [], options: RunOptions = {}): Promise<ProcessResult> {
    return this.runViaPool({ kind: "command", payload: command, args, options });
  }

  /** Run a script through the host shell. */
  shell(script: string, options: RunOptions = {}): Promise<ProcessResult> {
    return this.runViaPool({ kind: "shell", payload: script, options });
  }

  /** Run a script with bash. */
  bash(script: string, options: RunOptions = {}): Promise<ProcessResult> {
    return this.runViaPool({ kind: "bash", payload: script, options });
  }

  /** Run a script through Windows CMD (Windows hosts only). */
  cmd(script: string, options: RunOptions = {}): Promise<ProcessResult> {
    return this.runViaPool({ kind: "cmd", payload: script, options });
  }

  /** Run JavaScript source with the host Node.js runtime. */
  javascript(code: string, options: RunOptions = {}): Promise<ProcessResult> {
    return this.runViaPool({ kind: "javascript", payload: code, options });
  }

  /** Run Python source with the best available interpreter. */
  python(code: string, options: RunOptions = {}): Promise<ProcessResult> {
    return this.runViaPool({ kind: "python", payload: code, options });
  }

  /** Agentic run: diagnose failures and retry with fixes. */
  agentic(task: KernelTask, options: { maxAttempts?: number } = {}): Promise<AgenticRunReport> {
    return this.brain.agenticRun(this.pool.kernelAt(0), task, options);
  }

  /** Run a JS module in a warm worker process (no per-task spawn cost). */
  async runInWorker(code: string): Promise<WorkerTaskResult> {
    if (!this.workers) {
      throw new Error("Sandbox was created without warmWorkers; construct with { warmWorkers: n }.");
    }
    return this.workers.run(code);
  }

  stats(): SandboxStats {
    return {
      pool: this.pool.getStats(),
      cache: this.cache ? this.cache.stats() : { hits: 0, misses: 0, size: 0 },
      workers: this.workers ? this.workers.stats() : { workers: 0, completed: 0, failures: 0 },
      adaptive: this.adaptive ? this.adaptive.stats() : { active: 0, limit: 0, waiting: 0 },
    };
  }

  async dispose(): Promise<void> {
    await this.pool.drain();
    if (this.workers) await this.workers.dispose();
    this.cache?.clear();
  }
}

export type { KernelTaskKind };
