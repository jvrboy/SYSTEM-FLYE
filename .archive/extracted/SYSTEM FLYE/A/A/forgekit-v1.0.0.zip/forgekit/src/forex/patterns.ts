/**
 * Candlestick pattern detection: doji, hammer, shooting star, engulfing,
 * morning/evening star and more. Patterns are shape-based (no indicator
 * context needed) and return a direction + strength for signal engines.
 */

import type { Ohlc } from "../core/types.js";

export interface PatternSignal {
  index: number;
  name: string;
  direction: "bullish" | "bearish" | "neutral";
  strength: number;
}

export interface CandleShape {
  body: number;
  upperWick: number;
  lowerWick: number;
  range: number;
  isBullish: boolean;
}

export function candleShape(candle: Ohlc): CandleShape {
  const body = Math.abs(candle.close - candle.open);
  const range = candle.high - candle.low;
  return {
    body,
    upperWick: candle.high - Math.max(candle.open, candle.close),
    lowerWick: Math.min(candle.open, candle.close) - candle.low,
    range: range > 0 ? range : Number.EPSILON,
    isBullish: candle.close >= candle.open,
  };
}

export function isDoji(candle: Ohlc): boolean {
  const shape = candleShape(candle);
  return shape.body <= shape.range * 0.1;
}

export function isHammer(candle: Ohlc): boolean {
  const shape = candleShape(candle);
  return (
    shape.lowerWick >= shape.body * 2 &&
    shape.upperWick <= shape.body * 0.5 &&
    shape.body > 0
  );
}

export function isShootingStar(candle: Ohlc): boolean {
  const shape = candleShape(candle);
  return (
    shape.upperWick >= shape.body * 2 &&
    shape.lowerWick <= shape.body * 0.5 &&
    shape.body > 0
  );
}

export function isSpinningTop(candle: Ohlc): boolean {
  const shape = candleShape(candle);
  return shape.body <= shape.range * 0.3 && shape.upperWick > shape.body && shape.lowerWick > shape.body;
}

export function isBullishEngulfing(candles: Ohlc[], index: number): boolean {
  if (index < 1) return false;
  const prev = candles[index - 1]!;
  const cur = candles[index]!;
  return (
    prev.close < prev.open &&
    cur.close > cur.open &&
    cur.open <= prev.close &&
    cur.close >= prev.open &&
    cur.close > prev.open
  );
}

export function isBearishEngulfing(candles: Ohlc[], index: number): boolean {
  if (index < 1) return false;
  const prev = candles[index - 1]!;
  const cur = candles[index]!;
  return (
    prev.close > prev.open &&
    cur.close < cur.open &&
    cur.open >= prev.close &&
    cur.close <= prev.open &&
    cur.close < prev.open
  );
}

/** Detect all known patterns across the series. */
export function detectCandlestickPatterns(candles: Ohlc[]): PatternSignal[] {
  const signals: PatternSignal[] = [];
  for (let i = 0; i < candles.length; i++) {
    const candle = candles[i]!;

    if (isDoji(candle)) {
      signals.push({ index: i, name: "doji", direction: "neutral", strength: 0.3 });
    }
    if (isHammer(candle)) {
      signals.push({ index: i, name: "hammer", direction: "bullish", strength: 0.6 });
    }
    if (isShootingStar(candle)) {
      signals.push({ index: i, name: "shooting-star", direction: "bearish", strength: 0.6 });
    }
    if (isSpinningTop(candle)) {
      signals.push({ index: i, name: "spinning-top", direction: "neutral", strength: 0.2 });
    }
    if (isBullishEngulfing(candles, i)) {
      signals.push({ index: i, name: "bullish-engulfing", direction: "bullish", strength: 0.75 });
    }
    if (isBearishEngulfing(candles, i)) {
      signals.push({ index: i, name: "bearish-engulfing", direction: "bearish", strength: 0.75 });
    }

    // Morning / evening star (3-bar).
    if (i >= 2) {
      const first = candles[i - 2]!;
      const middle = candles[i - 1]!;
      const third = candle;
      const firstShape = candleShape(first);
      const middleShape = candleShape(middle);
      const thirdShape = candleShape(third);
      const firstRange = first.high - first.low;

      if (
        first.close < first.open &&
        middleShape.body <= firstRange * 0.4 &&
        middleShape.isBullish === false &&
        third.close > third.open &&
        third.close > (first.open + first.close) / 2
      ) {
        signals.push({ index: i, name: "morning-star", direction: "bullish", strength: 0.85 });
      }
      if (
        first.close > first.open &&
        middleShape.body <= firstRange * 0.4 &&
        middleShape.isBullish &&
        third.close < third.open &&
        third.close < (first.open + first.close) / 2
      ) {
        signals.push({ index: i, name: "evening-star", direction: "bearish", strength: 0.85 });
      }
    }
  }
  return signals;
}
