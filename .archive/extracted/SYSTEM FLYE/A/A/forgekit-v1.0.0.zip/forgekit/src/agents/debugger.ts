/**
 * The agent debugger: turns static checks and runtime output into diagnostics,
 * then produces concrete fixes. Fixes carry a `hint` (fed back into the
 * generator) and, where the fix is unambiguous, an exact-string `patch` that
 * can be applied directly to the code.
 */

import type { KnowledgeBase } from "./knowledge.js";

export interface Diagnostic {
  message: string;
  confidence: number;
  source: "static" | "runtime";
  pattern?: string;
}

export interface Fix {
  id: string;
  title: string;
  hint: string;
  patch?: { from: string; to: string };
}

export interface RunOutput {
  stdout: string;
  stderr: string;
  exitCode: number | null;
}

export interface Analysis {
  diagnostics: Diagnostic[];
  fixes: Fix[];
}

export class Debugger {
  constructor(private readonly knowledge: KnowledgeBase) {}

  analyze(code: string, run: RunOutput | null, staticIssues: string[] = []): Analysis {
    const diagnostics: Diagnostic[] = [];
    const fixes: Fix[] = [];

    for (const issue of staticIssues) {
      diagnostics.push({ message: issue, confidence: 0.6, source: "static" });
    }

    if (run && run.exitCode !== 0) {
      const text = `${run.stderr}\n${run.stdout}`;
      const matches = this.knowledge.findErrorPatterns(text);
      for (const match of matches) {
        diagnostics.push({
          message: `${match.pattern.explanation} (matched: ${match.match.trim().slice(0, 120)})`,
          confidence: 0.85,
          source: "runtime",
          pattern: match.pattern.id,
        });
        fixes.push({
          id: `fix-${match.pattern.id}`,
          title: match.pattern.explanation,
          hint: match.pattern.hint,
          patch: match.pattern.patch,
        });
      }
    }

    return { diagnostics, fixes };
  }

  /** Apply all unambiguous exact-string patches. Returns the patched code. */
  applyPatches(code: string, fixes: Fix[]): string {
    let out = code;
    for (const fix of fixes) {
      const patch = fix.patch;
      if (!patch || patch.from.length === 0) continue;
      if (out.includes(patch.from)) {
        out = out.replace(patch.from, patch.to);
      }
    }
    return out;
  }
}
