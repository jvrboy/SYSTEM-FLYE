/**
 * Boilerplate snippet libraries per language, plus a keyword matcher that
 * coding agents use to pick a relevant starting point for a task.
 *
 * Snippets are written as valid, self-testing code: the generated module
 * throws when a core invariant is violated, so the agent's debug loop has
 * something real to validate against.
 */

import { tokenize } from "../core/utils.js";

export interface Snippet {
  name: string;
  keywords: string[];
  code: string;
}

/** Score a task against a snippet's keywords; return the best match or null. */
export function matchSnippet(task: string, snippets: Snippet[]): Snippet | null {
  const text = task.toLowerCase();
  const tokens = new Set(tokenize(task));
  let best: Snippet | null = null;
  let bestScore = 0;
  for (const snippet of snippets) {
    let score = 0;
    for (const keyword of snippet.keywords) {
      if (tokens.has(keyword)) score += 2;
      else if (text.includes(keyword)) score += 1;
    }
    if (score > bestScore) {
      bestScore = score;
      best = snippet;
    }
  }
  // Require at least one strong (whole-token) keyword match so that
  // coincidental substrings (e.g. "totally" ~ "total") don't win.
  return bestScore >= 2 ? best : null;
}

// ---------------------------------------------------------------------------
// JavaScript
// ---------------------------------------------------------------------------

export const JS_SNIPPETS: Snippet[] = [
  {
    name: "hello",
    keywords: ["hello", "greet", "greeting", "welcome", "introduce"],
    code: `export function greet(name = "world") {
  return \`Hello, \${name}!\`;
}

// Self-check
if (greet("ForgeKit") !== "Hello, ForgeKit!") throw new Error("greet() failed");
if (greet() !== "Hello, world!") throw new Error("greet() default failed");
`,
  },
  {
    name: "fibonacci",
    keywords: ["fibonacci", "fib", "sequence", "fibs"],
    code: `export function fibonacci(n) {
  if (n < 0) throw new Error("n must be >= 0");
  const seq = [];
  let a = 0;
  let b = 1;
  for (let i = 0; i < n; i++) {
    seq.push(a);
    const next = a + b;
    a = b;
    b = next;
  }
  return seq;
}

// Self-check
const fib10 = fibonacci(10);
if (fib10.length !== 10) throw new Error("fibonacci(10) length");
if (fib10[9] !== 34) throw new Error("fibonacci(10)[9] should be 34");
`,
  },
  {
    name: "sum",
    keywords: ["sum", "add", "addition", "total"],
    code: `export function sum(numbers) {
  if (!Array.isArray(numbers)) throw new Error("expected an array");
  return numbers.reduce((acc, n) => acc + n, 0);
}

// Self-check
if (sum([1, 2, 3, 4]) !== 10) throw new Error("sum([1,2,3,4]) should be 10");
if (sum([]) !== 0) throw new Error("sum([]) should be 0");
`,
  },
  {
    name: "sort",
    keywords: ["sort", "order", "arrange", "sorted"],
    code: `export function sortAscending(arr) {
  return [...arr].sort((a, b) => a - b);
}

// Self-check
const sorted = sortAscending([3, 1, 4, 1, 5]);
if (JSON.stringify(sorted) !== JSON.stringify([1, 1, 3, 4, 5])) {
  throw new Error("sortAscending failed");
}
`,
  },
  {
    name: "fizzbuzz",
    keywords: ["fizzbuzz", "fizz", "buzz"],
    code: `export function fizzbuzz(limit) {
  const out = [];
  for (let i = 1; i <= limit; i++) {
    if (i % 15 === 0) out.push("FizzBuzz");
    else if (i % 3 === 0) out.push("Fizz");
    else if (i % 5 === 0) out.push("Buzz");
    else out.push(String(i));
  }
  return out;
}

// Self-check
const fb = fizzbuzz(15);
if (fb[2] !== "Fizz" || fb[4] !== "Buzz" || fb[14] !== "FizzBuzz") {
  throw new Error("fizzbuzz failed");
}
`,
  },
  {
    name: "palindrome",
    keywords: ["palindrome", "palindromic"],
    code: `export function isPalindrome(value) {
  const text = String(value).toLowerCase().replace(/[^a-z0-9]/g, "");
  return text === [...text].reverse().join("");
}

// Self-check
if (!isPalindrome("A man, a plan, a canal: Panama")) throw new Error("palindrome positive");
if (isPalindrome("forgekit")) throw new Error("palindrome negative");
`,
  },
  {
    name: "factorial",
    keywords: ["factorial", "fact"],
    code: `export function factorial(n) {
  if (n < 0) throw new Error("n must be >= 0");
  let result = 1;
  for (let i = 2; i <= n; i++) result *= i;
  return result;
}

// Self-check
if (factorial(5) !== 120) throw new Error("factorial(5) should be 120");
`,
  },
];

// ---------------------------------------------------------------------------
// Python
// ---------------------------------------------------------------------------

export const PYTHON_SNIPPETS: Snippet[] = [
  {
    name: "hello",
    keywords: ["hello", "greet", "greeting", "welcome"],
    code: `def greet(name="world"):
    return f"Hello, {name}!"


if greet("ForgeKit") != "Hello, ForgeKit!":
    raise AssertionError("greet() failed")
if greet() != "Hello, world!":
    raise AssertionError("greet() default failed")
`,
  },
  {
    name: "fibonacci",
    keywords: ["fibonacci", "fib", "sequence", "fibs"],
    code: `def fibonacci(n):
    if n < 0:
        raise ValueError("n must be >= 0")
    seq = []
    a, b = 0, 1
    for _ in range(n):
        seq.append(a)
        a, b = b, a + b
    return seq


fib10 = fibonacci(10)
assert len(fib10) == 10, "fibonacci(10) length"
assert fib10[9] == 34, "fibonacci(10)[9] should be 34"
`,
  },
  {
    name: "sum",
    keywords: ["sum", "add", "addition", "total"],
    code: `def sum_numbers(numbers):
    return sum(numbers)


assert sum_numbers([1, 2, 3, 4]) == 10, "sum([1,2,3,4]) should be 10"
assert sum_numbers([]) == 0, "sum([]) should be 0"
`,
  },
  {
    name: "sort",
    keywords: ["sort", "order", "arrange", "sorted"],
    code: `def sort_ascending(arr):
    return sorted(arr)


assert sort_ascending([3, 1, 4, 1, 5]) == [1, 1, 3, 4, 5], "sort failed"
`,
  },
  {
    name: "fizzbuzz",
    keywords: ["fizzbuzz", "fizz", "buzz"],
    code: `def fizzbuzz(limit):
    out = []
    for i in range(1, limit + 1):
        if i % 15 == 0:
            out.append("FizzBuzz")
        elif i % 3 == 0:
            out.append("Fizz")
        elif i % 5 == 0:
            out.append("Buzz")
        else:
            out.append(str(i))
    return out


fb = fizzbuzz(15)
assert fb[2] == "Fizz", "fizzbuzz[2]"
assert fb[4] == "Buzz", "fizzbuzz[4]"
assert fb[14] == "FizzBuzz", "fizzbuzz[14]"
`,
  },
  {
    name: "palindrome",
    keywords: ["palindrome", "palindromic"],
    code: `import re


def is_palindrome(value):
    text = re.sub(r"[^a-z0-9]", "", str(value).lower())
    return text == text[::-1]


assert is_palindrome("A man, a plan, a canal: Panama"), "palindrome positive"
assert not is_palindrome("forgekit"), "palindrome negative"
`,
  },
  {
    name: "factorial",
    keywords: ["factorial", "fact"],
    code: `def factorial(n):
    if n < 0:
        raise ValueError("n must be >= 0")
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


assert factorial(5) == 120, "factorial(5) should be 120"
`,
  },
];

// ---------------------------------------------------------------------------
// Arduino (C++)
// ---------------------------------------------------------------------------

export const ARDUINO_SNIPPETS: Snippet[] = [
  {
    name: "blink",
    keywords: ["blink", "led", "onboard", "on-board"],
    code: `// Blink: the Arduino "hello world".
const int LED_PIN = 13;

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  delay(1000);
  digitalWrite(LED_PIN, LOW);
  delay(1000);
}
`,
  },
  {
    name: "pwm-fade",
    keywords: ["pwm", "fade", "brightness", "dim"],
    code: `// Fade an LED with PWM (pin ~9 on Uno).
const int LED_PIN = 9;

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  for (int brightness = 0; brightness <= 255; brightness++) {
    analogWrite(LED_PIN, brightness);
    delay(10);
  }
  for (int brightness = 255; brightness >= 0; brightness--) {
    analogWrite(LED_PIN, brightness);
    delay(10);
  }
}
`,
  },
  {
    name: "serial-echo",
    keywords: ["serial", "print", "monitor", "echo"],
    code: `// Read serial input and echo it back.
void setup() {
  Serial.begin(9600);
}

void loop() {
  if (Serial.available() > 0) {
    String incoming = Serial.readString();
    Serial.print("Echo: ");
    Serial.println(incoming);
  }
}
`,
  },
  {
    name: "button",
    keywords: ["button", "switch", "input", "press"],
    code: `// Read a button (with pull-up) and light an LED.
const int BUTTON_PIN = 2;
const int LED_PIN = 13;

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  int pressed = digitalRead(BUTTON_PIN) == LOW;
  digitalWrite(LED_PIN, pressed ? HIGH : LOW);
}
`,
  },
];

// ---------------------------------------------------------------------------
// Raspberry Pi (Python + GPIO)
// ---------------------------------------------------------------------------

export const RPI_SNIPPETS: Snippet[] = [
  {
    name: "blink",
    keywords: ["blink", "led", "gpio", "onboard"],
    code: `"""Blink an LED on a Raspberry Pi (gpiozero)."""
from gpiozero import LED
from time import sleep

led = LED(17)

for _ in range(10):
    led.on()
    sleep(0.5)
    led.off()
    sleep(0.5)

print("blink complete")
`,
  },
  {
    name: "button",
    keywords: ["button", "switch", "press", "input"],
    code: `"""React to a button press on a Raspberry Pi."""
from gpiozero import Button
from time import sleep

button = Button(2, pull_up=True)

while True:
    if button.is_pressed:
        print("button pressed")
    sleep(0.1)
`,
  },
  {
    name: "pwm",
    keywords: ["pwm", "fade", "brightness"],
    code: `"""Fade an LED using PWM on a Raspberry Pi."""
from gpiozero import PWMLED
from time import sleep

led = PWMLED(17)

while True:
    for duty in range(0, 101, 5):
        led.value = duty / 100
        sleep(0.05)
    for duty in range(100, -1, -5):
        led.value = duty / 100
        sleep(0.05)
`,
  },
  {
    name: "sensor",
    keywords: ["sensor", "temperature", "read", "probe"],
    code: `"""Read a value from an analog/digital sensor via GPIO."""
try:
    from gpiozero import MCP3008
except ImportError:
    MCP3008 = None


def read_sensor():
    if MCP3008 is None:
        return 0.0
    channel = MCP3008(channel=0)
    return round(channel.value, 4)


print(f"sensor: {read_sensor()}")
`,
  },
];

// ---------------------------------------------------------------------------
// C#
// ---------------------------------------------------------------------------

export const CSHARP_SNIPPETS: Snippet[] = [
  {
    name: "hello",
    keywords: ["hello", "greet", "welcome", "console"],
    code: `using System;

class Program
{
    static string Greet(string name = "world")
    {
        return $"Hello, {name}!";
    }

    static void Main(string[] args)
    {
        Console.WriteLine(Greet("ForgeKit"));
    }
}
`,
  },
  {
    name: "fibonacci",
    keywords: ["fibonacci", "fib", "sequence"],
    code: `using System;
using System.Collections.Generic;

class Program
{
    static List<long> Fibonacci(int n)
    {
        var seq = new List<long>();
        long a = 0, b = 1;
        for (int i = 0; i < n; i++)
        {
            seq.Add(a);
            long next = a + b;
            a = b;
            b = next;
        }
        return seq;
    }

    static void Main(string[] args)
    {
        var fib = Fibonacci(10);
        Console.WriteLine(string.Join(",", fib));
    }
}
`,
  },
  {
    name: "sum",
    keywords: ["sum", "add", "total"],
    code: `using System;
using System.Linq;

class Program
{
    static int Sum(int[] numbers)
    {
        return numbers.Sum();
    }

    static void Main(string[] args)
    {
        Console.WriteLine(Sum(new int[] { 1, 2, 3, 4 }));
    }
}
`,
  },
];

// ---------------------------------------------------------------------------
// YAML
// ---------------------------------------------------------------------------

export const YAML_SNIPPETS: Snippet[] = [
  {
    name: "server-config",
    keywords: ["server", "web", "http", "service", "config", "configuration"],
    code: `# Generated by the ForgeKit YAML agent — web server configuration
server:
  host: 0.0.0.0
  port: 8080
  workers: 4
  tls:
    enabled: true
    cert_path: /etc/ssl/server.crt
    key_path: /etc/ssl/server.key
logging:
  level: info
  format: json
routes:
  - path: /health
    method: GET
    handler: health.check
  - path: /api
    method: ANY
    handler: api.router
`,
  },
  {
    name: "database-config",
    keywords: ["database", "db", "postgres", "mysql", "sql", "connection"],
    code: `# Database connection configuration
database:
  engine: postgres
  host: localhost
  port: 5432
  name: appdb
  pool:
    min: 2
    max: 10
    idle_timeout_seconds: 300
  ssl: require
replication:
  enabled: false
  replicas: []
`,
  },
  {
    name: "ci-pipeline",
    keywords: ["ci", "pipeline", "build", "deploy", "workflow", "github"],
    code: `# CI pipeline configuration
pipeline:
  name: build-and-test
  stages:
    - name: install
      commands:
        - bun install
    - name: typecheck
      commands:
        - bun tsc --noEmit
    - name: test
      commands:
        - bun test
  artifacts:
    - dist/**
  on:
    push: [main]
    pull_request: true
`,
  },
  {
    name: "monitoring-config",
    keywords: ["monitoring", "metrics", "alert", "prometheus", "grafana"],
    code: `# Monitoring & alerting configuration
monitoring:
  scrape_interval: 15s
  metrics:
    - name: http_requests_total
      type: counter
      help: Total HTTP requests
    - name: memory_usage_bytes
      type: gauge
      help: Current memory usage
alerts:
  - name: high-error-rate
    condition: error_rate > 0.05
    severity: critical
    channels: [email, slack]
`,
  },
];
