/**
 * Advanced coding tools: static code analysis with heuristics — language
 * sniffing, lint-style issue detection, complexity and structure reports.
 */

import { occurrences } from "./generate.js";

export interface CodeIssue {
  line: number;
  severity: "error" | "warning" | "info";
  message: string;
}

export interface CodeAnalysis {
  language: string | null;
  lines: number;
  characters: number;
  issues: CodeIssue[];
  bracesBalanced: boolean;
  semicolonCount: number;
  todoCount: number;
  functionCount: number;
  complexity: number;
  longestLine: number;
}

export function detectLanguage(code: string): string | null {
  const sample = code.slice(0, 4000);
  if (/^\s*#include\s*[<"].*\.h[>"]/m.test(sample) || /\bvoid\s+(setup|loop)\s*\(/.test(sample)) return "cpp";
  if (/^\s*using\s+\w+;/m.test(sample) && /\bclass\s+\w+/.test(sample)) return "csharp";
  if (
    /^\s*(export\s|import\s+.*\bfrom\b|const\s+\w+|let\s+\w+|=>|console\.log\s*\(|require\s*\()/m.test(sample)
  ) {
    return "javascript";
  }
  if (/^\s*(import\s+\w+|from\s+\w+\s+import|def\s+\w+\s*\(|print\s*\()/m.test(sample)) return "python";
  if (/^\s*[\w.-]+\s*:\s/m.test(sample)) return "yaml";
  return null;
}

export function analyzeCode(code: string, language?: string): CodeAnalysis {
  const lines = code.split("\n");
  const issues: CodeIssue[] = [];
  const detected = language ?? detectLanguage(code);

  for (const [index, rawLine] of lines.entries()) {
    const lineNo = index + 1;
    const line = rawLine.replace(/\t/g, "    ");
    if (rawLine.includes("\t")) {
      issues.push({ line: lineNo, severity: "warning", message: "Line contains a tab (use spaces)." });
    }
    if (line.length > 120) {
      issues.push({ line: lineNo, severity: "warning", message: `Line is ${line.length} chars (limit 120).` });
    }
    if (/^\s*(console\.log|print)\s*\(/.test(line)) {
      issues.push({ line: lineNo, severity: "info", message: "Debug print/log statement left in code." });
    }
    if (/TODO|FIXME|HACK/.test(line)) {
      issues.push({ line: lineNo, severity: "info", message: "TODO/FIXME marker present." });
    }
    if (detected === "python" && /^\s*(else|elif|except|finally)\s*:\s*$/.test(line) === false && /\b(if|for|while|def|class|with|try|except|elif|else)\b[^:]*[^:]\s*$/.test(line) && /:\s*$/.test(line) === false && /\b(if|for|while|def|class|with|try|except)\b/.test(line) && line.includes(":") === false && line.includes("=") === false) {
      issues.push({ line: lineNo, severity: "warning", message: "Python block statement may be missing a trailing ':'." });
    }
    if (detected === "yaml" && rawLine.includes("\t")) {
      issues.push({ line: lineNo, severity: "error", message: "Tabs are not allowed in YAML." });
    }
  }

  const open = occurrences(code, "{");
  const close = occurrences(code, "}");
  const bracesBalanced = open === close;

  return {
    language: detected,
    lines: lines.length,
    characters: code.length,
    issues,
    bracesBalanced,
    semicolonCount: occurrences(code, ";"),
    todoCount: occurrences(code, "TODO") + occurrences(code, "FIXME"),
    functionCount: (code.match(/\bfunction\s+\w+|^\s*def\s+\w+|^\s*(public|private|protected|internal)?\s*(static\s+)?[\w<>\[\],\s]+\s+\w+\s*\(/gm) ?? []).length,
    complexity: complexityScore(code),
    longestLine: lines.reduce((max, line) => Math.max(max, line.length), 0),
  };
}

/** Rough cyclomatic complexity: decision points + boolean operators. */
export function complexityScore(code: string): number {
  const decisionPoints = (code.match(/\b(if|for|while|case|catch|switch)\b/g) ?? []).length;
  const booleanOperators = (code.match(/&&|\|\|/g) ?? []).length;
  return 1 + decisionPoints + booleanOperators;
}

/** Extract a list of declared identifiers (functions/variables) — best-effort. */
export function extractIdentifiers(code: string, language: string | null): string[] {
  const names = new Set<string>();
  if (language === "python") {
    for (const match of code.matchAll(/^\s*(?:def|class)\s+(\w+)/gm)) names.add(match[1]!);
    for (const match of code.matchAll(/^\s*(\w+)\s*=/gm)) names.add(match[1]!);
  } else if (language === "javascript" || language === "cpp" || language === "csharp") {
    for (const match of code.matchAll(/\b(?:function|const|let|var|class)\s+(\w+)/g)) names.add(match[1]!);
  }
  return [...names];
}
