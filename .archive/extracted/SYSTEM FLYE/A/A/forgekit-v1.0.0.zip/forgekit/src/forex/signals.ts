/**
 * Signal engine: combines EMA cross, RSI, MACD, Bollinger and ADX into a
 * single score with a buy/sell/neutral recommendation and human-readable
 * reasons. Deterministic and unit-testable.
 */

import type { Ohlc } from "../core/types.js";
import { adx, bollinger, ema, macd, rsi, type Series } from "./indicators.js";

export interface SignalConfig {
  emaFast?: number;
  emaSlow?: number;
  rsiPeriod?: number;
  rsiOversold?: number;
  rsiOverbought?: number;
  bollingerPeriod?: number;
  adxPeriod?: number;
  /** ADX above this value = a strong trend. */
  adxStrong?: number;
}

export interface SignalAnalysis {
  signal: "buy" | "sell" | "neutral";
  /** 0..1 conviction. */
  strength: number;
  score: number;
  trend: "up" | "down" | "ranging";
  reasons: string[];
  indicators: {
    emaFast: number | null;
    emaSlow: number | null;
    emaCrossedUp: boolean;
    emaCrossedDown: boolean;
    rsi: number | null;
    macdHistogram: number | null;
    priceVsBollinger: "above" | "below" | "inside" | null;
    adx: number | null;
  };
}

function last<T>(values: Array<T | null>): T | null {
  for (let i = values.length - 1; i >= 0; i--) {
    const value = values[i];
    if (value !== null && value !== undefined) return value;
  }
  return null;
}

function at(values: Array<number | null>, offset: number): number | null {
  const index = values.length - 1 - offset;
  if (index < 0) return null;
  const value = values[index];
  return value === null || value === undefined ? null : value;
}

export function analyzeSignals(candles: Ohlc[], config: SignalConfig = {}): SignalAnalysis {
  const closes = candles.map((c) => c.close);
  const emaFast = ema(closes, config.emaFast ?? 10);
  const emaSlow = ema(closes, config.emaSlow ?? 30);
  const rsiSeries = rsi(closes, config.rsiPeriod ?? 14);
  const macdResult = macd(closes);
  const boll = bollinger(closes, { period: config.bollingerPeriod ?? 20 });
  const adxResult = adx(candles, config.adxPeriod ?? 14);

  const fastNow = last(emaFast);
  const fastPrev = at(emaFast, 1);
  const slowNow = last(emaSlow);
  const slowPrev = at(emaSlow, 1);
  const rsiNow = last(rsiSeries);
  const macdHist = last(macdResult.histogram);
  const adxNow = last(adxResult.adx);
  const closeNow = closes[closes.length - 1] ?? null;

  const emaCrossedUp = fastNow !== null && slowNow !== null && fastPrev !== null && slowPrev !== null
    ? fastPrev <= slowPrev && fastNow > slowNow
    : false;
  const emaCrossedDown = fastNow !== null && slowNow !== null && fastPrev !== null && slowPrev !== null
    ? fastPrev >= slowPrev && fastNow < slowNow
    : false;
  const emaBullish = fastNow !== null && slowNow !== null ? fastNow > slowNow : null;

  let priceVsBollinger: SignalAnalysis["indicators"]["priceVsBollinger"] = null;
  const upper = last(boll.upper);
  const lower = last(boll.lower);
  if (closeNow !== null && upper !== null && lower !== null) {
    if (closeNow > upper) priceVsBollinger = "above";
    else if (closeNow < lower) priceVsBollinger = "below";
    else priceVsBollinger = "inside";
  }

  const score = { value: 0 };
  const reasons: string[] = [];
  const strongTrend = adxNow !== null && adxNow > (config.adxStrong ?? 25);

  if (emaCrossedUp) {
    score.value += 3;
    reasons.push("EMA fast crossed above slow (bullish cross)");
  } else if (emaCrossedDown) {
    score.value -= 3;
    reasons.push("EMA fast crossed below slow (bearish cross)");
  } else if (emaBullish === true) {
    score.value += 1.5;
    reasons.push("EMA stack is bullish");
  } else if (emaBullish === false) {
    score.value -= 1.5;
    reasons.push("EMA stack is bearish");
  }

  const oversold = config.rsiOversold ?? 30;
  const overbought = config.rsiOverbought ?? 70;
  if (rsiNow !== null) {
    if (rsiNow < oversold) {
      score.value += 2;
      reasons.push(`RSI oversold (${rsiNow.toFixed(1)} < ${oversold})`);
    } else if (rsiNow > overbought) {
      score.value -= 2;
      reasons.push(`RSI overbought (${rsiNow.toFixed(1)} > ${overbought})`);
    }
  }

  if (macdHist !== null) {
    if (macdHist > 0) {
      score.value += 1;
      reasons.push("MACD histogram positive (momentum up)");
    } else {
      score.value -= 1;
      reasons.push("MACD histogram negative (momentum down)");
    }
  }

  if (priceVsBollinger === "below") {
    score.value += 1;
    reasons.push("Price below lower Bollinger band (oversold extension)");
  } else if (priceVsBollinger === "above") {
    score.value -= 1;
    reasons.push("Price above upper Bollinger band (overbought extension)");
  }

  let trend: SignalAnalysis["trend"] = "ranging";
  if (strongTrend) {
    // The trend label follows the EMA stack (the directional signal), not the
    // aggregate score (which contains contrarian RSI/Bollinger components).
    if (emaBullish === true) {
      score.value += 1;
      trend = "up";
      reasons.push(`Strong uptrend confirmed (ADX ${adxNow!.toFixed(1)})`);
    } else if (emaBullish === false) {
      score.value -= 1;
      trend = "down";
      reasons.push(`Strong downtrend confirmed (ADX ${adxNow!.toFixed(1)})`);
    }
  }

  const signal: SignalAnalysis["signal"] = score.value >= 2 ? "buy" : score.value <= -2 ? "sell" : "neutral";
  const strength = Math.min(1, Math.abs(score.value) / 8);

  return {
    signal,
    strength,
    score: score.value,
    trend,
    reasons,
    indicators: {
      emaFast: fastNow,
      emaSlow: slowNow,
      emaCrossedUp,
      emaCrossedDown,
      rsi: rsiNow,
      macdHistogram: macdHist,
      priceVsBollinger,
      adx: adxNow,
    },
  };
}
