/**
 * Dependency-free PDF creator: build multi-page PDFs with text, lines and
 * rectangles, then save them to a Buffer or a file. Generates valid PDF 1.4
 * with a correct cross-reference table (verified by the test suite).
 *
 * Fonts: the 14 standard PDF fonts (Helvetica, Helvetica-Bold,
 * Helvetica-Oblique). Coordinates are top-left origin (y grows downward),
 * which is converted to PDF's bottom-left origin internally.
 */

import { writeFile } from "node:fs/promises";
import { PdfError } from "../core/errors.js";

export interface PdfDocumentOptions {
  title?: string;
  author?: string;
  /** Page width in points (default 595.28 = A4). */
  pageWidth?: number;
  /** Page height in points (default 841.89 = A4). */
  pageHeight?: number;
  /** Default margin in points (default 56.7 ≈ 2cm). */
  margin?: number;
}

export interface TextOptions {
  size?: number;
  align?: "left" | "center" | "right";
  /** RGB color, 0..255 each. */
  color?: [number, number, number];
  bold?: boolean;
  italic?: boolean;
}

export interface RectOptions {
  fill?: boolean;
  stroke?: boolean;
  lineWidth?: number;
  color?: [number, number, number];
}

export interface LineOptions {
  lineWidth?: number;
  color?: [number, number, number];
}

const FONT_IDS = { regular: "/F1", bold: "/F2", italic: "/F3" } as const;
const FONT_NAMES = { regular: "Helvetica", bold: "Helvetica-Bold", italic: "Helvetica-Oblique" } as const;

const A4_WIDTH = 595.28;
const A4_HEIGHT = 841.89;

function fmt(value: number): string {
  return String(Math.round(value * 1000) / 1000);
}

function escapePdfString(text: string): string {
  let out = "";
  for (const char of text) {
    if (char === "(") out += "\\(";
    else if (char === ")") out += "\\)";
    else if (char === "\\") out += "\\\\";
    else if (char.charCodeAt(0) < 32 || char.charCodeAt(0) > 126) out += "?";
    else out += char;
  }
  return out;
}

function colorOp(color: [number, number, number] | undefined): string {
  if (!color) return "";
  return `${fmt(color[0]! / 255)} ${fmt(color[1]! / 255)} ${fmt(color[2]! / 255)} `;
}

/** Approximate rendered width of a string in the given font size. */
export function textWidth(text: string, size: number): number {
  return text.length * size * 0.5;
}

interface Page {
  width: number;
  height: number;
  operations: string[];
}

export class PdfDocument {
  readonly width: number;
  readonly height: number;
  readonly margin: number;
  private pages: Page[] = [];
  private title: string;
  private author: string;
  private fontSize = 12;

  constructor(options: PdfDocumentOptions = {}) {
    this.width = options.pageWidth ?? A4_WIDTH;
    this.height = options.pageHeight ?? A4_HEIGHT;
    this.margin = options.margin ?? 56.7;
    this.title = options.title ?? "ForgeKit PDF";
    this.author = options.author ?? "ForgeKit";
    this.addPage();
  }

  /** Start a new page and return the document (chainable). */
  addPage(): this {
    this.pages.push({ width: this.width, height: this.height, operations: [] });
    return this;
  }

  get pageCount(): number {
    return this.pages.length;
  }

  private current(): Page {
    const page = this.pages[this.pages.length - 1];
    if (!page) throw new PdfError("No pages in document");
    return page;
  }

  /** Draw text at (x, y) with the top-left origin. */
  text(x: number, y: number, value: string, options: TextOptions = {}): this {
    const page = this.current();
    const size = options.size ?? this.fontSize;
    const font = options.bold ? FONT_IDS.bold : options.italic ? FONT_IDS.italic : FONT_IDS.regular;
    let cursorX = x;
    if (options.align === "center") cursorX = x - textWidth(value, size) / 2;
    else if (options.align === "right") cursorX = x - textWidth(value, size);
    const pdfY = page.height - y;
    const color = colorOp(options.color);
    page.operations.push(`BT ${font} ${fmt(size)} Tf ${color}${fmt(cursorX)} ${fmt(pdfY)} Td (${escapePdfString(value)}) Tj ET`);
    return this;
  }

  /** Draw a straight line from (x1, y1) to (x2, y2), top-left origin. */
  line(x1: number, y1: number, x2: number, y2: number, options: LineOptions = {}): this {
    const page = this.current();
    const width = options.lineWidth ?? 1;
    const color = colorOp(options.color);
    const topY1 = page.height - y1;
    const topY2 = page.height - y2;
    page.operations.push(`${color}${fmt(width)} w ${fmt(x1)} ${fmt(topY1)} m ${fmt(x2)} ${fmt(topY2)} l S`);
    return this;
  }

  /** Draw (and optionally fill/stroke) a rectangle, top-left origin. */
  rect(x: number, y: number, width: number, height: number, options: RectOptions = {}): this {
    const page = this.current();
    const color = colorOp(options.color);
    const topY = page.height - y;
    const fill = options.fill ?? false;
    const stroke = options.stroke ?? false;
    const op = fill ? "f" : stroke ? "S" : "";
    if (!fill && !stroke) throw new PdfError("rect() needs fill or stroke");
    const widthOp = options.lineWidth ? `${fmt(options.lineWidth)} w ` : "";
    page.operations.push(`${color}${widthOp}${fmt(x)} ${fmt(topY)} ${fmt(width)} ${fmt(height)} re ${op}`);
    return this;
  }

  /** Draw a filled text band (useful for table headers / rules). */
  rule(x: number, y: number, width: number, options: LineOptions = {}): this {
    return this.line(x, y, x + width, y, options);
  }

  save(): Uint8Array {
    if (this.pages.length === 0) throw new PdfError("Cannot save an empty PDF");
    const objects: string[] = [];
    const infoId = 1;
    const catalogId = 2;
    const pagesId = 3;
    const fontBaseId = 4;
    const pageStartId = fontBaseId + 3; // F1..F3
    const contentStartId = pageStartId + this.pages.length;

    objects.push(`<< /Title (${escapePdfString(this.title)}) /Author (${escapePdfString(this.author)}) /Producer (forgekit) /CreationDate (D:${new Date().toISOString().slice(0, 10).replace(/-/g, "")}000000Z) >>`);
    objects.push(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    objects.push(
      `<< /Type /Pages /Kids [${this.pages.map((_, i) => `${pageStartId + i} 0 R`).join(" ")}] /Count ${this.pages.length} >>`,
    );

    for (const fontName of Object.values(FONT_NAMES)) {
      objects.push(`<< /Type /Font /Subtype /Type1 /BaseFont /${fontName} /Encoding /WinAnsiEncoding >>`);
    }

    this.pages.forEach((page, index) => {
      const pageId = pageStartId + index;
      const contentId = contentStartId + index;
      objects.push(
        `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${fmt(page.width)} ${fmt(page.height)}] /Resources << /Font << /F1 ${fontBaseId} 0 R /F2 ${fontBaseId + 1} 0 R /F3 ${fontBaseId + 2} 0 R >> >> /Contents ${contentId} 0 R >>`,
      );
    });

    this.pages.forEach((page) => {
      const stream = page.operations.join("\n");
      objects.push(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
    });

    let buffer = "%PDF-1.4\n";
    const offsets: number[] = [0];
    objects.forEach((body, index) => {
      const objectNumber = index + 1;
      offsets.push(Buffer.byteLength(buffer, "latin1"));
      buffer += `${objectNumber} 0 obj\n${body}\nendobj\n`;
    });

    const xrefOffset = Buffer.byteLength(buffer, "latin1");
    buffer += `xref\n0 ${offsets.length}\n0000000000 65535 f \n`;
    for (let i = 1; i < offsets.length; i++) {
      buffer += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
    }
    buffer += `trailer\n<< /Size ${offsets.length} /Root ${catalogId} 0 R /Info ${infoId} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

    return new TextEncoder().encode(buffer);
  }

  async saveToFile(path: string): Promise<void> {
    await writeFile(path, this.save());
  }
}

export const PAGE_SIZES = {
  a4: { width: A4_WIDTH, height: A4_HEIGHT },
  letter: { width: 612, height: 792 },
  a5: { width: 419.53, height: 595.28 },
} as const;

export function createPdf(options: PdfDocumentOptions = {}): PdfDocument {
  return new PdfDocument(options);
}
