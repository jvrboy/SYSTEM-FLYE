/**
 * The Agents Council: many coding agents (a "swarm") deliberate on the same
 * task and the council aggregates their results — weighted voting on status
 * and a score-based election of the best implementation.
 *
 * `AgentsCouncil.swarm(agent, { count: 700 })` spawns 700 clones of an agent,
 * each with its own seeded brain and voting weight, so you get a genuine
 * council of independent agents.
 */

import { BaseCodingAgent, type AgentStatus, type CodeTaskResult } from "./base.js";

export interface CouncilMember {
  agent: BaseCodingAgent;
  weight: number;
}

export interface CouncilVote {
  agent: string;
  status: AgentStatus;
  confidence: number;
  score: number;
  weight: number;
}

export interface CouncilVerdict {
  task: string;
  decision: {
    status: AgentStatus;
    confidence: number;
    chosenBy: string;
  };
  best: CodeTaskResult;
  votes: CouncilVote[];
  weightedTally: Record<AgentStatus, number>;
  totalWeight: number;
}

function scoreResult(result: CodeTaskResult): number {
  const statusScore = result.status === "pass" ? 10 : result.status === "unverified" ? 5 : 0;
  return (
    statusScore +
    result.confidence * 2 -
    Math.max(0, result.iterations - 1) * 0.5 -
    Math.min(result.code.length / 4000, 1)
  );
}

export class AgentsCouncil {
  private members: CouncilMember[] = [];

  add(agent: BaseCodingAgent, weight = 1): this {
    this.members.push({ agent, weight });
    return this;
  }

  get size(): number {
    return this.members.length;
  }

  getMembers(): readonly CouncilMember[] {
    return this.members;
  }

  /** Ask every member to code the task, then aggregate the results. */
  async deliberate(task: string): Promise<CouncilVerdict> {
    const results = await Promise.all(
      this.members.map(async (member) => ({
        member,
        result: await member.agent.code(task),
      })),
    );

    const votes: CouncilVote[] = results.map(({ member, result }) => ({
      agent: member.agent.name,
      status: result.status,
      confidence: result.confidence,
      score: scoreResult(result) * member.weight,
      weight: member.weight,
    }));

    const weightedTally: Record<AgentStatus, number> = { pass: 0, fail: 0, unverified: 0 };
    for (const vote of votes) {
      weightedTally[vote.status] += vote.weight;
    }
    const totalWeight = votes.reduce((n, v) => n + v.weight, 0);

    const statuses: AgentStatus[] = ["pass", "unverified", "fail"];
    let decision: AgentStatus = "unverified";
    let bestWeight = -1;
    for (const status of statuses) {
      if (weightedTally[status] > bestWeight) {
        bestWeight = weightedTally[status];
        decision = status;
      }
    }

    let best = results[0]?.result;
    let bestMember = results[0]?.member;
    let bestScore = -Infinity;
    for (const { member, result } of results) {
      const score = scoreResult(result);
      if (score > bestScore) {
        bestScore = score;
        best = result;
        bestMember = member;
      }
    }
    if (!best) throw new Error("Council has no members — add agents first.");

    const confidence = Math.min(0.99, bestWeight / Math.max(totalWeight, 1));
    return {
      task,
      decision: { status: decision, confidence, chosenBy: bestMember?.agent.name ?? "council" },
      best,
      votes,
      weightedTally,
      totalWeight,
    };
  }

  /**
   * Spawn a swarm of `count` clones of a base agent. Each clone gets an
   * independent, deterministically-seeded brain and a distinct weight, so the
   * council vote reflects many genuinely different "minds".
   */
  static swarm(base: BaseCodingAgent, options: { count?: number; seed?: number } = {}): AgentsCouncil {
    const count = Math.max(1, options.count ?? 12);
    const seed = options.seed ?? 1;
    const council = new AgentsCouncil();
    for (let i = 0; i < count; i++) {
      const clone = base.clone(seed + i * 1013);
      council.add(clone, 0.5 + ((i % 5) * 0.15));
    }
    return council;
  }
}
