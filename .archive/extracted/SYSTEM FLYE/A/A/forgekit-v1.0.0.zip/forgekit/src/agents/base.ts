/**
 * Base coding agent: every agent owns a brain (neural network + skill
 * learning), a knowledge base, and a debugger. The `code()` method runs the
 * agentic loop:
 *
 *   generate → static validate → run (when a runtime is available) →
 *   diagnose failures → apply patches / regenerate with hints → re-validate
 *
 * Statuses:
 *   - "pass":       produced code that executed cleanly (runtime available).
 *   - "unverified": produced code that passes all static checks but no runtime
 *                   could be executed on this host (e.g. no compiler).
 *   - "fail":       could not produce clean code within maxIterations.
 */

import { NeuralBrain } from "./brain.js";
import { Debugger, type Diagnostic, type Fix } from "./debugger.js";
import type { KnowledgeBase } from "./knowledge.js";
import { Sandbox } from "../sandbox/index.js";
import type { ProcessResult } from "../core/types.js";
import { hashString } from "../core/utils.js";

export interface AgentOptions {
  name: string;
  language: string;
  knowledge: KnowledgeBase;
  brain?: NeuralBrain;
  debuggerTool?: Debugger;
  sandbox?: Sandbox;
  maxIterations?: number;
}

export interface DynamicValidation {
  ok: boolean;
  stdout: string;
  stderr: string;
  exitCode: number | null;
}

export type AgentStatus = "pass" | "fail" | "unverified";

export interface CodeTaskResult {
  code: string;
  status: AgentStatus;
  iterations: number;
  diagnostics: Diagnostic[];
  fixesApplied: Fix[];
  confidence: number;
  durationMs: number;
  run: DynamicValidation | null;
  report: string[];
}

/** Count a character in a string (used by the brace-balance heuristic). */
export function countChar(code: string, char: string): number {
  let count = 0;
  for (let i = 0; i < code.length; i++) if (code[i] === char) count += 1;
  return count;
}

/** Language-agnostic static checks shared by every agent. */
export function defaultStaticChecks(code: string): string[] {
  const issues: string[] = [];
  const pairs: Array<[string, string, string]> = [
    ["{", "}", "braces"],
    ["(", ")", "parentheses"],
    ["[", "]", "brackets"],
  ];
  for (const [open, close, label] of pairs) {
    const balance = countChar(code, open) - countChar(code, close);
    if (balance > 0) issues.push(`Unbalanced ${label}: ${balance} more opening than closing.`);
    else if (balance < 0) issues.push(`Unbalanced ${label}: ${-balance} more closing than opening.`);
  }
  if (code.trim().length === 0) issues.push("Generated empty code.");
  return issues;
}

export function seedFromName(name: string): number {
  return parseInt(hashString(name).slice(0, 8), 16) >>> 0;
}

export abstract class BaseCodingAgent {
  readonly name: string;
  readonly language: string;
  protected readonly knowledge: KnowledgeBase;
  protected brain: NeuralBrain;
  protected readonly debuggerTool: Debugger;
  protected readonly sandbox: Sandbox;
  protected readonly maxIterations: number;

  constructor(options: AgentOptions) {
    this.name = options.name;
    this.language = options.language;
    this.knowledge = options.knowledge;
    this.brain = options.brain ?? new NeuralBrain({ sizes: [8, 12, 3], seed: seedFromName(this.name) });
    this.debuggerTool = options.debuggerTool ?? new Debugger(this.knowledge);
    this.sandbox = options.sandbox ?? new Sandbox({ concurrency: 2 });
    this.maxIterations = options.maxIterations ?? 5;
  }

  /** Agentic code generation with the debug loop described above. */
  async code(task: string, options: { test?: string } = {}): Promise<CodeTaskResult> {
    const started = Date.now();
    let code = this.generate(task, []);
    const diagnostics: Diagnostic[] = [];
    const fixesApplied: Fix[] = [];
    const report: string[] = [];
    let status: AgentStatus = "unverified";
    let run: DynamicValidation | null = null;
    let iterations = 0;

    for (iterations = 1; iterations <= this.maxIterations; iterations++) {
      const staticIssues = this.staticValidate(code);
      const dynamic = await this.dynamicValidate(code, options.test);
      if (dynamic) run = dynamic;

      if (staticIssues.length === 0 && (!dynamic || dynamic.ok)) {
        status = dynamic ? "pass" : "unverified";
        report.push(`Iteration ${iterations}: validation clean (${status}).`);
        break;
      }

      const analysis = this.debuggerTool.analyze(code, dynamic && !dynamic.ok ? dynamic : null, staticIssues);
      diagnostics.push(...analysis.diagnostics);
      fixesApplied.push(...analysis.fixes);
      report.push(
        `Iteration ${iterations}: ${analysis.diagnostics.length} issue(s) found — ${analysis.diagnostics
          .map((d) => d.message.slice(0, 80))
          .join(" | ")}`,
      );

      const patched = this.debuggerTool.applyPatches(code, analysis.fixes);
      if (patched !== code) {
        code = patched;
      } else {
        const hints = analysis.fixes.map((fix) => fix.hint).filter((hint) => hint.length > 0);
        code = this.regenerate(task, code, hints);
      }

      if (iterations === this.maxIterations) {
        status = "fail";
        report.push(`Gave up after ${this.maxIterations} iterations.`);
      }
    }

    this.learn(task, status, iterations);
    return {
      code,
      status,
      iterations,
      diagnostics,
      fixesApplied,
      confidence: this.confidenceFor(status, iterations),
      durationMs: Date.now() - started,
      run,
      report,
    };
  }

  /** Alias for `code()` — makes the "test what you generate" intent explicit. */
  test(task: string): Promise<CodeTaskResult> {
    return this.code(task);
  }

  /** Produce a first candidate implementation for a task. */
  protected abstract generate(task: string, hints: string[]): string;

  /** Produce a follow-up candidate given hints from the debugger. */
  protected regenerate(task: string, previousCode: string, hints: string[]): string {
    void previousCode;
    return this.generate(task, hints);
  }

  /** Domain static checks. Default: brace balance + non-empty. */
  protected staticValidate(code: string): string[] {
    return defaultStaticChecks(code);
  }

  /** Execute the code when a runtime is available; otherwise return null. */
  protected async dynamicValidate(code: string, test: string | undefined): Promise<DynamicValidation | null> {
    void code;
    void test;
    return null;
  }

  /** Run source through the sandbox and map the result to a validation. */
  protected async runViaSandbox(
    kind: "javascript" | "python",
    source: string,
  ): Promise<DynamicValidation | null> {
    let result: ProcessResult;
    try {
      result = kind === "javascript" ? await this.sandbox.javascript(source) : await this.sandbox.python(source);
    } catch (error) {
      return { ok: false, stdout: "", stderr: String(error), exitCode: -1 };
    }
    return {
      ok: result.exitCode === 0 && !result.timedOut,
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
    };
  }

  /** Update brain skills after a task. */
  protected learn(task: string, status: AgentStatus, iterations: number): void {
    void task;
    const outcome = status === "pass" ? 0.2 : status === "fail" ? -0.3 : 0.02;
    this.brain.learn(`lang:${this.language}`, outcome);
    this.brain.learn(`iter:${Math.min(iterations, 6)}`, status === "pass" ? 0.1 : -0.1);
  }

  private confidenceFor(status: AgentStatus, iterations: number): number {
    const base = status === "pass" ? 0.9 : status === "unverified" ? 0.6 : 0.2;
    return Math.max(0.05, Math.min(0.99, base - (iterations - 1) * 0.1));
  }

  getBrain(): NeuralBrain {
    return this.brain;
  }

  getKnowledge(): KnowledgeBase {
    return this.knowledge;
  }

  /** A fresh copy with the same class, knowledge and tools but a new brain. */
  clone(seed?: number): BaseCodingAgent {
    const copy = Object.create(Object.getPrototypeOf(this)) as BaseCodingAgent;
    for (const key of Object.keys(this)) {
      const value = (this as unknown as Record<string, unknown>)[key];
      (copy as unknown as Record<string, unknown>)[key] = value;
    }
    copy.brain = this.brain.clone(seed ?? seedFromName(this.name));
    return copy;
  }
}
