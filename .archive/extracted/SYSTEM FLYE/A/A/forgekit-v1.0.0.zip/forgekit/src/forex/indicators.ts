/**
 * Advanced forex technical analysis: classic indicators implemented from
 * scratch. Every series output is aligned to the input (`number | null`
 * during warm-up), so it can be zipped straight onto candles or fed into
 * `charts.indicatorsToOverlays`.
 */

import type { Ohlc } from "../core/types.js";
import { mean, stdDev, minOf, maxOf } from "../core/utils.js";

export type Series = Array<number | null>;

export function sma(values: number[], period: number): Series {
  const out: Series = new Array(values.length).fill(null);
  let windowSum = 0;
  for (let i = 0; i < values.length; i++) {
    windowSum += values[i]!;
    if (i >= period) windowSum -= values[i - period]!;
    if (i >= period - 1) out[i] = windowSum / period;
  }
  return out;
}

export function ema(values: number[], period: number): Series {
  const out: Series = new Array(values.length).fill(null);
  if (values.length < period || period < 1) return out;
  const multiplier = 2 / (period + 1);
  let seed = 0;
  for (let i = 0; i < period; i++) seed += values[i]!;
  let previous = seed / period;
  out[period - 1] = previous;
  for (let i = period; i < values.length; i++) {
    previous = (values[i]! - previous) * multiplier + previous;
    out[i] = previous;
  }
  return out;
}

/** Wilder's RSI. */
export function rsi(values: number[], period = 14): Series {
  const out: Series = new Array(values.length).fill(null);
  if (values.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = values[i]! - values[i - 1]!;
    if (diff >= 0) gain += diff;
    else loss -= diff;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = rsiFromAvgs(avgGain, avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const diff = values[i]! - values[i - 1]!;
    const currentGain = diff > 0 ? diff : 0;
    const currentLoss = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + currentGain) / period;
    avgLoss = (avgLoss * (period - 1) + currentLoss) / period;
    out[i] = rsiFromAvgs(avgGain, avgLoss);
  }
  return out;
}

function rsiFromAvgs(avgGain: number, avgLoss: number): number {
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

export interface MacdResult {
  macd: Series;
  signal: Series;
  histogram: Series;
}

export function macd(
  values: number[],
  options: { fast?: number; slow?: number; signal?: number } = {},
): MacdResult {
  const fast = options.fast ?? 12;
  const slow = options.slow ?? 26;
  const signalPeriod = options.signal ?? 9;
  const emaFast = ema(values, fast);
  const emaSlow = ema(values, slow);

  const macdLine: Series = new Array(values.length).fill(null);
  for (let i = 0; i < values.length; i++) {
    const f = emaFast[i] ?? null;
    const s = emaSlow[i] ?? null;
    if (f !== null && s !== null) macdLine[i] = f - s;
  }

  // Signal = EMA of the MACD line over its non-null segment.
  const valid: number[] = [];
  const validIndex: number[] = [];
  for (let i = 0; i < macdLine.length; i++) {
    const v = macdLine[i] ?? null;
    if (v !== null) {
      valid.push(v);
      validIndex.push(i);
    }
  }
  const signalValid = ema(valid, signalPeriod);
  const signal: Series = new Array(values.length).fill(null);
  for (let i = 0; i < valid.length; i++) {
    const value = signalValid[i] ?? null;
    if (value !== null) signal[validIndex[i]!] = value;
  }

  const histogram: Series = new Array(values.length).fill(null);
  for (let i = 0; i < values.length; i++) {
    const m = macdLine[i] ?? null;
    const s = signal[i] ?? null;
    if (m !== null && s !== null) histogram[i] = m - s;
  }
  return { macd: macdLine, signal, histogram };
}

export interface BollingerResult {
  upper: Series;
  middle: Series;
  lower: Series;
}

export function bollinger(
  values: number[],
  options: { period?: number; stdDev?: number } = {},
): BollingerResult {
  const period = options.period ?? 20;
  const k = options.stdDev ?? 2;
  const middle = sma(values, period);
  const upper: Series = new Array(values.length).fill(null);
  const lower: Series = new Array(values.length).fill(null);
  for (let i = period - 1; i < values.length; i++) {
    const window = values.slice(i - period + 1, i + 1);
    const mid = middle[i]!;
    const sd = stdDev(window);
    upper[i] = mid + k * sd;
    lower[i] = mid - k * sd;
  }
  return { upper, middle, lower };
}

/** Average True Range (Wilder). */
export function atr(candles: Ohlc[], period = 14): Series {
  const out: Series = new Array(candles.length).fill(null);
  if (candles.length <= period) return out;
  const trs = candles.map((candle, i) => trueRange(candle, i > 0 ? candles[i - 1] : undefined));
  let prev = 0;
  for (let i = 0; i < period; i++) prev += trs[i]!;
  prev /= period;
  out[period - 1] = prev;
  for (let i = period; i < trs.length; i++) {
    prev = (prev * (period - 1) + trs[i]!) / period;
    out[i] = prev;
  }
  return out;
}

export function trueRange(candle: Ohlc, previous?: Ohlc): number {
  if (!previous) return candle.high - candle.low;
  return Math.max(
    candle.high - candle.low,
    Math.abs(candle.high - previous.close),
    Math.abs(candle.low - previous.close),
  );
}

export interface StochasticResult {
  k: Series;
  d: Series;
}

export function stochastic(
  candles: Ohlc[],
  options: { k?: number; d?: number } = {},
): StochasticResult {
  const kPeriod = options.k ?? 14;
  const dPeriod = options.d ?? 3;
  const k: Series = new Array(candles.length).fill(null);
  for (let i = kPeriod - 1; i < candles.length; i++) {
    const window = candles.slice(i - kPeriod + 1, i + 1);
    const highest = maxOf(window.map((c) => c.high));
    const lowest = minOf(window.map((c) => c.low));
    if (highest === lowest) k[i] = 50;
    else k[i] = ((candles[i]!.close - lowest) / (highest - lowest)) * 100;
  }
  const validK: number[] = [];
  const validIndex: number[] = [];
  for (let i = 0; i < k.length; i++) {
    const v = k[i] ?? null;
    if (v !== null) {
      validK.push(v);
      validIndex.push(i);
    }
  }
  const dValid = sma(validK, dPeriod);
  const d: Series = new Array(candles.length).fill(null);
  for (let i = 0; i < validK.length; i++) {
    const value = dValid[i] ?? null;
    if (value !== null) d[validIndex[i]!] = value;
  }
  return { k, d };
}

export interface AdxResult {
  adx: Series;
  plusDi: Series;
  minusDi: Series;
}

/** Average Directional Index (Wilder). */
export function adx(candles: Ohlc[], period = 14): AdxResult {
  const n = candles.length;
  const plusDi: Series = new Array(n).fill(null);
  const minusDi: Series = new Array(n).fill(null);
  const adxOut: Series = new Array(n).fill(null);
  if (n <= 2 * period) return { adx: adxOut, plusDi, minusDi };

  const tr: number[] = [];
  const plusDm: number[] = [];
  const minusDm: number[] = [];
  for (let i = 0; i < n; i++) {
    tr.push(trueRange(candles[i]!, i > 0 ? candles[i - 1] : undefined));
    if (i === 0) {
      plusDm.push(0);
      minusDm.push(0);
    } else {
      const up = candles[i]!.high - candles[i - 1]!.high;
      const down = candles[i - 1]!.low - candles[i]!.low;
      plusDm.push(up > down && up > 0 ? up : 0);
      minusDm.push(down > up && down > 0 ? down : 0);
    }
  }

  let smoothTr = 0;
  let smoothPlus = 0;
  let smoothMinus = 0;
  for (let i = 0; i < period; i++) {
    smoothTr += tr[i]!;
    smoothPlus += plusDm[i]!;
    smoothMinus += minusDm[i]!;
  }

  const dxValues: number[] = [];
  const dxIndex: number[] = [];
  for (let i = period; i < n; i++) {
    if (i > period) {
      smoothTr = smoothTr - smoothTr / period + tr[i]!;
      smoothPlus = smoothPlus - smoothPlus / period + plusDm[i]!;
      smoothMinus = smoothMinus - smoothMinus / period + minusDm[i]!;
    }
    const plus = smoothTr === 0 ? 0 : (smoothPlus / smoothTr) * 100;
    const minus = smoothTr === 0 ? 0 : (smoothMinus / smoothTr) * 100;
    plusDi[i] = plus;
    minusDi[i] = minus;
    const sum = plus + minus;
    if (sum > 0) {
      dxValues.push((Math.abs(plus - minus) / sum) * 100);
      dxIndex.push(i);
    }
  }

  if (dxValues.length >= period) {
    let adxSum = 0;
    for (let i = 0; i < period; i++) adxSum += dxValues[i]!;
    let prevAdx = adxSum / period;
    const startIndex = dxIndex[period - 1]!;
    adxOut[startIndex] = prevAdx;
    for (let i = period; i < dxValues.length; i++) {
      prevAdx = (prevAdx * (period - 1) + dxValues[i]!) / period;
      adxOut[dxIndex[i]!] = prevAdx;
    }
  }
  return { adx: adxOut, plusDi, minusDi };
}

export interface IchimokuResult {
  tenkan: Series;
  kijun: Series;
  senkouA: Series;
  senkouB: Series;
  chikou: Series;
  /** The 26-bar displacement used when plotting the cloud. */
  shift: number;
}

export function ichimoku(
  candles: Ohlc[],
  options: { tenkan?: number; kijun?: number; senkouB?: number } = {},
): IchimokuResult {
  const tenkanPeriod = options.tenkan ?? 9;
  const kijunPeriod = options.kijun ?? 26;
  const senkouBPeriod = options.senkouB ?? 52;
  const n = candles.length;

  const midPoint = (period: number): Series => {
    const out: Series = new Array(n).fill(null);
    for (let i = period - 1; i < n; i++) {
      const window = candles.slice(i - period + 1, i + 1);
      out[i] = (maxOf(window.map((c) => c.high)) + minOf(window.map((c) => c.low))) / 2;
    }
    return out;
  };

  const tenkan = midPoint(tenkanPeriod);
  const kijun = midPoint(kijunPeriod);
  const senkouB = midPoint(senkouBPeriod);

  const senkouA: Series = new Array(n).fill(null);
  for (let i = 0; i < n; i++) {
    const t = tenkan[i] ?? null;
    const k = kijun[i] ?? null;
    if (t !== null && k !== null) senkouA[i] = (t + k) / 2;
  }

  const chikou: Series = new Array(n).fill(null);
  for (let i = kijunPeriod; i < n; i++) {
    chikou[i - kijunPeriod] = candles[i]!.close;
  }

  return { tenkan, kijun, senkouA, senkouB, chikou, shift: kijunPeriod };
}

export function donchian(candles: Ohlc[], period = 20): { upper: Series; lower: Series } {
  const n = candles.length;
  const upper: Series = new Array(n).fill(null);
  const lower: Series = new Array(n).fill(null);
  for (let i = period - 1; i < n; i++) {
    const window = candles.slice(i - period + 1, i + 1);
    upper[i] = maxOf(window.map((c) => c.high));
    lower[i] = minOf(window.map((c) => c.low));
  }
  return { upper, lower };
}

export type PivotType = "classic" | "fibonacci" | "camarilla";

export interface PivotLevels {
  pivot: number;
  resistances: number[];
  supports: number[];
}

/** Pivot points from the previous period's high/low/close. */
export function pivotPoints(
  high: number,
  low: number,
  close: number,
  type: PivotType = "classic",
): PivotLevels {
  const pivot = (high + low + close) / 3;
  const range = high - low;
  if (type === "classic") {
    return {
      pivot,
      resistances: [2 * pivot - low, pivot + range, high + 2 * (pivot - low)],
      supports: [2 * pivot - high, pivot - range, low - 2 * (high - pivot)],
    };
  }
  if (type === "fibonacci") {
    return {
      pivot,
      resistances: [pivot + 0.382 * range, pivot + 0.618 * range, pivot + range],
      supports: [pivot - 0.382 * range, pivot - 0.618 * range, pivot - range],
    };
  }
  // Camarilla
  const factor = range * 1.1;
  return {
    pivot,
    resistances: [
      close + factor / 12,
      close + factor / 6,
      close + factor / 4,
      close + factor / 2,
    ],
    supports: [
      close - factor / 12,
      close - factor / 6,
      close - factor / 4,
      close - factor / 2,
    ],
  };
}

export interface SwingLevel {
  price: number;
  touches: number;
  index: number;
}

/** Support/resistance levels from swing highs and lows. */
export function swingLevels(
  candles: Ohlc[],
  options: { window?: number; minTouches?: number } = {},
): { supports: SwingLevel[]; resistances: SwingLevel[] } {
  const window = options.window ?? 3;
  const minTouches = options.minTouches ?? 1;
  const highs: number[] = [];
  const lows: number[] = [];
  const highIndex: number[] = [];
  const lowIndex: number[] = [];

  for (let i = window; i < candles.length - window; i++) {
    const candle = candles[i]!;
    const before = candles.slice(i - window, i);
    const after = candles.slice(i + 1, i + window + 1);
    if (
      candle.high > maxOf(before.map((c) => c.high)) &&
      candle.high >= maxOf(after.map((c) => c.high))
    ) {
      highs.push(candle.high);
      highIndex.push(i);
    }
    if (
      candle.low < minOf(before.map((c) => c.low)) &&
      candle.low <= minOf(after.map((c) => c.low))
    ) {
      lows.push(candle.low);
      lowIndex.push(i);
    }
  }

  const cluster = (prices: number[], indices: number[]): SwingLevel[] => {
    const groups: Array<{ sum: number; count: number; lastIndex: number }> = [];
    for (let i = 0; i < prices.length; i++) {
      const price = prices[i]!;
      const tolerance = price * 0.002;
      let placed = false;
      for (const group of groups) {
        const avg = group.sum / group.count;
        if (Math.abs(avg - price) <= tolerance) {
          group.sum += price;
          group.count += 1;
          group.lastIndex = indices[i]!;
          placed = true;
          break;
        }
      }
      if (!placed) groups.push({ sum: price, count: 1, lastIndex: indices[i]! });
    }
    return groups
      .filter((g) => g.count >= minTouches)
      .map((g) => ({ price: g.sum / g.count, touches: g.count, index: g.lastIndex }))
      .sort((a, b) => b.price - a.price);
  };

  return {
    supports: cluster(lows, lowIndex).reverse(),
    resistances: cluster(highs, highIndex),
  };
}

/** Linear regression slope over a window — a simple momentum proxy. */
export function slope(values: number[], period = 14): Series {
  const out: Series = new Array(values.length).fill(null);
  for (let i = period - 1; i < values.length; i++) {
    const window = values.slice(i - period + 1, i + 1);
    const xMean = (period - 1) / 2;
    const yMean = mean(window);
    let numerator = 0;
    let denominator = 0;
    for (let j = 0; j < period; j++) {
      numerator += (j - xMean) * (window[j]! - yMean);
      denominator += (j - xMean) ** 2;
    }
    out[i] = denominator === 0 ? 0 : numerator / denominator;
  }
  return out;
}

export { mean, stdDev };
