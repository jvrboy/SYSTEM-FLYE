/**
 * A small template engine: `{{var}}` interpolation, `{{#if cond}}...{{else}}...
 * {{/if}}` conditionals and `{{#each list}}...{{/each}}` loops (with `{{this}}`,
 * `{{@index}}` and nested property access).
 */

import { TemplateError } from "../core/errors.js";

export type TemplateValue = unknown;
export type TemplateContext = Record<string, TemplateValue>;

interface Token {
  type: "text" | "var" | "open" | "else" | "close";
  value: string;
}

const TOKEN_RE = /{{(\/?)([^}]+)}}/g;

export function tokenizeTemplate(template: string): Token[] {
  const tokens: Token[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = TOKEN_RE.exec(template)) !== null) {
    if (match.index > lastIndex) {
      tokens.push({ type: "text", value: template.slice(lastIndex, match.index) });
    }
    const closing = match[1] === "/";
    const name = match[2]!.trim();
    if (closing) tokens.push({ type: "close", value: name });
    else if (name.startsWith("#")) tokens.push({ type: "open", value: name.slice(1).trim() });
    else if (name === "else") tokens.push({ type: "else", value: "" });
    else tokens.push({ type: "var", value: name });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < template.length) {
    tokens.push({ type: "text", value: template.slice(lastIndex) });
  }
  return tokens;
}

export function resolvePath(context: TemplateContext, path: string): TemplateValue {
  if (path === "this") return context;
  const parts = path.split(".");
  let current: TemplateValue = context;
  for (const part of parts) {
    if (typeof current !== "object" || current === null) return undefined;
    current = (current as Record<string, unknown>)[part];
  }
  return current;
}

function isTruthy(value: TemplateValue): boolean {
  if (value === undefined || value === null) return false;
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") return value.length > 0;
  if (Array.isArray(value)) return value.length > 0;
  return true;
}

function renderTokens(tokens: Token[], index: number, context: TemplateContext): { output: string; next: number } {
  let output = "";
  let i = index;
  while (i < tokens.length) {
    const token = tokens[i]!;
    if (token.type === "text") {
      output += token.value;
      i += 1;
    } else if (token.type === "var") {
      const value = resolvePath(context, token.value);
      output += value === undefined ? "" : String(value);
      i += 1;
    } else if (token.type === "open") {
      const [kind = "", ...rest] = token.value.split(/\s+/);
      const argument = rest.join(" ");
      const closeName = kind === "if" ? "if" : "each";

      // Find matching {{/kind}} (and the first {{else}} for if).
      let depth = 1;
      let cursor = i + 1;
      let elseIndex = -1;
      while (cursor < tokens.length && depth > 0) {
        const t = tokens[cursor]!;
        if (t.type === "open" && t.value.startsWith(kind)) depth += 1;
        else if (t.type === "close" && t.value === closeName) depth -= 1;
        else if (t.type === "else" && depth === 1 && kind === "if") elseIndex = cursor;
        if (depth > 0) cursor += 1;
      }
      if (depth !== 0) {
        throw new TemplateError(`Unclosed {{#${kind}}} section (found "${token.value}").`);
      }
      const endIndex = cursor;
      const bodyEnd = elseIndex >= 0 ? elseIndex : endIndex;
      const elseEnd = elseIndex >= 0 ? endIndex : -1;

      if (kind === "if") {
        const condition = resolvePath(context, argument);
        if (isTruthy(condition)) {
          const rendered = renderTokens(tokens, i + 1, context);
          output += rendered.output;
          i = endIndex + 1;
        } else if (elseIndex >= 0) {
          const rendered = renderTokens(tokens, elseIndex + 1, context);
          output += rendered.output;
          i = endIndex + 1;
        } else {
          i = endIndex + 1;
        }
      } else if (kind === "each") {
        const list = resolvePath(context, argument);
        if (!Array.isArray(list)) {
          throw new TemplateError(`{{#each ${argument}}} requires an array, got ${typeof list}.`);
        }
        for (let itemIndex = 0; itemIndex < list.length; itemIndex++) {
          const item = list[itemIndex];
          const itemContext: TemplateContext = {
            ...context,
            this: item,
            "@index": itemIndex,
            "@first": itemIndex === 0,
            "@last": itemIndex === list.length - 1,
          };
          if (typeof item === "object" && item !== null) {
            Object.assign(itemContext, item as Record<string, unknown>);
          }
          const rendered = renderTokens(tokens, i + 1, itemContext);
          output += rendered.output;
        }
        i = endIndex + 1;
      } else {
        throw new TemplateError(`Unknown section "{{#${kind}}}".`);
      }
    } else if (token.type === "else" || token.type === "close") {
      // Handled by the section renderer; bail out for the caller.
      return { output, next: i };
    } else {
      i += 1;
    }
  }
  return { output, next: i };
}

export function renderTemplate(template: string, data: TemplateContext): string {
  const tokens = tokenizeTemplate(template);
  const { output } = renderTokens(tokens, 0, data);
  return output;
}

/** Convenience wrapper that throws on unknown keys used as variables. */
export function renderStrict(template: string, data: TemplateContext): string {
  const tokens = tokenizeTemplate(template);
  for (const token of tokens) {
    if (token.type === "var" && resolvePath(data, token.value) === undefined) {
      throw new TemplateError(`Unknown template variable "{{${token.value}}}".`);
    }
  }
  return renderTemplate(template, data);
}
