/**
 * Small, well-tested utilities shared across ForgeKit.
 */

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function round(value: number, decimals = 2): number {
  const factor = 10 ** decimals;
  return Math.round((value + Number.EPSILON) * factor) / factor;
}

export function sum(values: number[]): number {
  let total = 0;
  for (const v of values) total += v;
  return total;
}

export function mean(values: number[]): number {
  if (values.length === 0) return Number.NaN;
  return sum(values) / values.length;
}

/** Population standard deviation. */
export function stdDev(values: number[]): number {
  if (values.length === 0) return Number.NaN;
  const m = mean(values);
  const variance = sum(values.map((v) => (v - m) ** 2)) / values.length;
  return Math.sqrt(variance);
}

export function minOf(values: number[]): number {
  if (values.length === 0) return Number.NaN;
  let min = Number.POSITIVE_INFINITY;
  for (const v of values) if (v < min) min = v;
  return min;
}

export function maxOf(values: number[]): number {
  if (values.length === 0) return Number.NaN;
  let max = Number.NEGATIVE_INFINITY;
  for (const v of values) if (v > max) max = v;
  return max;
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** FNV-1a 32-bit hash → hex string. Deterministic across platforms. */
export function hashString(input: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

/** Split text into lowercase alphanumeric word tokens. */
export function tokenize(text: string): string[] {
  const out: string[] = [];
  for (const match of text.toLowerCase().matchAll(/[a-z0-9]+/g)) {
    const word = match[0];
    if (word.length > 1) out.push(word);
  }
  return out;
}

function vectorize(words: string[], vocab: Map<string, number>): number[] {
  const vec = new Array<number>(vocab.size).fill(0);
  for (const w of words) {
    const idx = vocab.get(w);
    if (idx !== undefined) vec[idx]! += 1;
  }
  return vec;
}

/** Cosine similarity of two texts (0..1). Used by knowledge retrieval. */
export function cosineSimilarity(a: string, b: string): number {
  const vocab = new Map<string, number>();
  for (const w of new Set([...tokenize(a), ...tokenize(b)])) {
    if (!vocab.has(w)) vocab.set(w, vocab.size);
  }
  if (vocab.size === 0) return 0;
  const va = vectorize(tokenize(a), vocab);
  const vb = vectorize(tokenize(b), vocab);
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < va.length; i++) {
    dot += va[i]! * vb[i]!;
    na += va[i]! * va[i]!;
    nb += vb[i]! * vb[i]!;
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

export function deepClone<T>(value: T): T {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value)) as T;
}

export function unique<T>(values: T[]): T[] {
  return [...new Set(values)];
}

export function chunk<T>(values: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < values.length; i += size) {
    out.push(values.slice(i, i + size));
  }
  return out;
}

/** Deterministic PRNG (mulberry32). Same seed → same sequence everywhere. */
export function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return function next() {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function times<T>(count: number, fn: (index: number) => T): T[] {
  const out: T[] = [];
  for (let i = 0; i < count; i++) out.push(fn(i));
  return out;
}

export function range(start: number, end: number, step = 1): number[] {
  const out: number[] = [];
  for (let i = start; i < end; i += step) out.push(i);
  return out;
}

export function isDefined<T>(value: T | null | undefined): value is T {
  return value !== null && value !== undefined;
}

export function lastOf<T>(values: T[]): T | undefined {
  return values.length > 0 ? values[values.length - 1] : undefined;
}

export function approxEqual(a: number, b: number, epsilon = 1e-6): boolean {
  return Math.abs(a - b) <= epsilon;
}

/** Percentile (0..100) using linear interpolation between closest ranks. */
export function percentile(values: number[], p: number): number {
  if (values.length === 0) return Number.NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const rank = (p / 100) * (sorted.length - 1);
  const lower = Math.floor(rank);
  const upper = Math.ceil(rank);
  if (lower === upper) return sorted[lower]!;
  const weight = rank - lower;
  return sorted[lower]! * (1 - weight) + sorted[upper]! * weight;
}

/** Shuffle a copy of the array with a seeded RNG (deterministic). */
export function shuffle<T>(values: T[], seed = 1): T[] {
  const rand = mulberry32(seed);
  const out = [...values];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const tmp = out[i];
    out[i] = out[j]!;
    out[j] = tmp!;
  }
  return out;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let value = bytes / 1024;
  let unit = units[0]!;
  for (let i = 1; i < units.length && value >= 1024; i++) {
    value /= 1024;
    unit = units[i]!;
  }
  return `${value.toFixed(1)} ${unit}`;
}

export function indent(text: string, spaces = 2): string {
  const pad = " ".repeat(spaces);
  return text
    .split("\n")
    .map((line) => (line.length === 0 ? line : pad + line))
    .join("\n");
}
