/**
 * Python coding agent: embedded Python knowledge, generators and a real
 * runtime debug loop — generated code is executed with the host interpreter
 * and failures are diagnosed from the traceback.
 */

import { BaseCodingAgent, defaultStaticChecks, type DynamicValidation } from "../base.js";
import { KnowledgeBase, type KnowledgeEntry } from "../knowledge.js";
import { NeuralBrain } from "../brain.js";
import type { Sandbox } from "../../sandbox/index.js";
import { matchSnippet, PYTHON_SNIPPETS } from "../../coding/snippets.js";
import { commentHeader } from "../../coding/generate.js";

const PYTHON_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "py-basics",
    topic: "Variables and types",
    content:
      "Python is dynamically typed. Common builtins: int, float, str, bool, None, list, dict, tuple, set. f-strings interpolate: f\"{value:.2f}\". Type hints (def f(x: int) -> str:) are optional but recommended.",
    tags: ["variable", "type", "int", "str", "float", "f-string", "none"],
  },
  {
    id: "py-functions",
    topic: "Functions",
    content:
      "def name(params): ... — the body must be indented (4 spaces). Return a value with return; no return gives None. Defaults: def f(x, scale=1.0). *args/**kwargs collect extra positional/keyword arguments.",
    tags: ["def", "function", "return", "default", "args", "kwargs", "lambda"],
  },
  {
    id: "py-data-structures",
    topic: "Data structures",
    content:
      "list: [1, 2] append/extend/insert; dict: {'k': v} get/setdefault/items; tuple: (1, 2) immutable; set: {1, 2} add/union. Comprehensions: [x * 2 for x in xs if x > 0].",
    tags: ["list", "dict", "tuple", "set", "comprehension", "append"],
  },
  {
    id: "py-control-flow",
    topic: "Control flow",
    content:
      "if/elif/else, for x in iterable:, while cond:, break/continue/pass. range(n) for numeric loops, enumerate(xs) for index+value, zip(a, b) to pair iterables. Python has no switch — use if/elif or a dict.",
    tags: ["if", "elif", "for", "while", "range", "enumerate", "zip", "break"],
  },
  {
    id: "py-modules",
    topic: "Modules and imports",
    content:
      "import math / from math import sqrt / import numpy as np. Imports run the module once (cached in sys.modules). __name__ == '__main__' guards the entry point so modules can be imported without side effects.",
    tags: ["import", "from", "module", "main", "sys.modules"],
  },
  {
    id: "py-errors",
    topic: "Exceptions",
    content:
      "try/except/else/finally handles errors. raise ValueError('...') raises. Common exceptions: ValueError, TypeError, KeyError, IndexError, ZeroDivisionError, FileNotFoundError. Always read the last line of the traceback first.",
    tags: ["try", "except", "raise", "traceback", "valueerror", "keyerror"],
    errors: [
      {
        id: "py-keyerror",
        pattern: /KeyError: ['"]([^'"]+)['"]/i.source,
        explanation: "A dict lookup used a key that is not present.",
        hint: "Use dict.get(key, default) or check 'key in dict' before access.",
      },
      {
        id: "py-indexerror",
        pattern: /IndexError: list index out of range/i.source,
        explanation: "An index was outside the list bounds.",
        hint: "Check the list length before indexing (len(xs)) or use xs[-1] for the last element.",
      },
      {
        id: "py-typeerror",
        pattern: /TypeError: ([^\n]*)/i.source,
        explanation: "An operation used incompatible types.",
        hint: "Check the operand types — e.g. converting strings with int()/float(), or matching str with str.",
      },
    ],
  },
  {
    id: "py-strings",
    topic: "Strings",
    content:
      "Strings are immutable; slicing s[1:4], s[::-1] reverses. Methods: .strip(), .split(), .join(), .replace(), .upper(). f-strings are the modern formatting tool.",
    tags: ["string", "slice", "split", "join", "strip", "format"],
  },
  {
    id: "py-file-io",
    topic: "File I/O",
    content:
      "with open('file.txt', 'r') as f: data = f.read() — the with block closes the file automatically. Modes: r, w, a, rb, wb, r+. JSON: import json; json.load(f) / json.dump(obj, f).",
    tags: ["open", "file", "read", "write", "json", "with"],
  },
  {
    id: "py-oop",
    topic: "Classes",
    content:
      "class Dog: with __init__(self, name): methods take self first. Properties via @property. dataclasses (from dataclasses import dataclass) give __init__/__repr__ for free. Inheritance: class Puppy(Dog):",
    tags: ["class", "init", "self", "dataclass", "property", "oop"],
  },
  {
    id: "py-common-errors",
    topic: "Common error patterns",
    content:
      "NameError: name used before definition or misspelled. IndentationError: mixed spaces/tabs or inconsistent blocks. SyntaxError: missing colon/paren/quote. Python 3 requires print(...) with parentheses.",
    tags: ["nameerror", "indentationerror", "syntaxerror", "print", "debug"],
  },
];

const FALLBACK_MODULE = `def solve():
    # TASK: ${"${task}"}
    return "forgekit python agent: task accepted"


if solve() is None:
    raise AssertionError("solve() returned None")
`;

export class PythonCodingAgent extends BaseCodingAgent {
  constructor(options: { sandbox?: Sandbox; brain?: NeuralBrain; maxIterations?: number } = {}) {
    super({
      name: "python-agent",
      language: "python",
      knowledge: new KnowledgeBase({ entries: PYTHON_KNOWLEDGE }),
      sandbox: options.sandbox,
      brain: options.brain,
      maxIterations: options.maxIterations,
    });
  }

  protected override generate(task: string, hints: string[]): string {
    const snippet = matchSnippet(task, PYTHON_SNIPPETS);
    const header = commentHeader("python", this.name, task);
    const hintBlock = hints.length > 0 ? `# Debug notes: ${hints.join("; ")}\n` : "";
    if (snippet) return `${header}${hintBlock}${snippet.code}`;
    return `${header}${hintBlock}${FALLBACK_MODULE.replace("${task}", task)}`;
  }

  protected override staticValidate(code: string): string[] {
    const issues = defaultStaticChecks(code);
    const lines = code.split("\n");
    lines.forEach((line, index) => {
      if (line.includes("\t")) issues.push(`Line ${index + 1}: tabs are not allowed in Python; use spaces.`);
    });
    return issues;
  }

  protected override async dynamicValidate(code: string, test: string | undefined): Promise<DynamicValidation | null> {
    const source = test ? `${code}\n\n# ---- test harness ----\n${test}\n` : code;
    return this.runViaSandbox("python", source);
  }
}

export function buildPythonKnowledge(): KnowledgeBase {
  return new KnowledgeBase({ entries: PYTHON_KNOWLEDGE });
}
