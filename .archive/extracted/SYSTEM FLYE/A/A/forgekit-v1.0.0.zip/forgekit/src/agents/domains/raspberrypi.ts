/**
 * Raspberry Pi coding agent: Python with embedded GPIO knowledge (RPi.GPIO,
 * gpiozero), wiring guidance and Pi-specific error patterns.
 */

import { BaseCodingAgent, defaultStaticChecks, type DynamicValidation } from "../base.js";
import { KnowledgeBase, type KnowledgeEntry } from "../knowledge.js";
import { NeuralBrain } from "../brain.js";
import type { Sandbox } from "../../sandbox/index.js";
import { matchSnippet, RPI_SNIPPETS } from "../../coding/snippets.js";
import { commentHeader } from "../../coding/generate.js";

const RPI_KNOWLEDGE: KnowledgeEntry[] = [
  {
    id: "rpi-python-basics",
    topic: "Python on the Pi",
    content:
      "Raspberry Pi OS ships Python 3. Scripts run with python3. GPIO access needs either the RPi.GPIO or gpiozero package, and raw RPi.GPIO access may need sudo (or the 'gpio' group). Use consistent indentation: Python is whitespace-sensitive.",
    tags: ["python", "python3", "script", "indentation"],
  },
  {
    id: "rpi-gpio-basics",
    topic: "RPi.GPIO basics",
    content:
      "import RPi.GPIO as GPIO; GPIO.setmode(GPIO.BCM) selects broadcom pin numbers (GPIO.setmode(GPIO.BOARD) selects physical pin numbers). GPIO.setup(pin, GPIO.OUT|GPIO.IN, initial=...) configures a pin. GPIO.output(pin, GPIO.HIGH|LOW) drives outputs; GPIO.input(pin) reads inputs. Always GPIO.cleanup() at the end.",
    tags: ["gpio", "rpi.gpio", "setmode", "bcm", "board", "output", "input", "cleanup"],
    errors: [
      {
        id: "rpi-mode-already-set",
        pattern: /RuntimeError: A different mode has already been set/i.source,
        explanation: "GPIO.setmode was called twice with different numbering schemes.",
        hint: "Call GPIO.setmode exactly once, at the top of the program.",
      },
      {
        id: "rpi-not-root",
        pattern: /must be run as root|PermissionError: \[Errno 13\]/i.source,
        explanation: "GPIO access requires privileges the current user does not have.",
        hint: "Run with sudo, or add the user to the gpio group and reboot.",
      },
      {
        id: "rpi-module-not-found",
        pattern: /ModuleNotFoundError: No module named ['"]RPi\.GPIO['"]|ModuleNotFoundError: No module named ['"]gpiozero['"]/i.source,
        explanation: "The GPIO library is not installed.",
        hint: "Install it: sudo apt install python3-gpiozero python3-rpi.gpio (or pip install gpiozero RPi.GPIO).",
      },
    ],
  },
  {
    id: "rpi-gpiozero",
    topic: "gpiozero (recommended)",
    content:
      "gpiozero is higher-level: LED(pin).on()/.off()/.toggle()/.blink(); Button(pin, pull_up=True).is_pressed; PWMLED(pin).value = 0.5 for dimming; Buzzer, Servo, DistanceSensor, MCP3008 exist too. Great default for new projects.",
    tags: ["gpiozero", "led", "button", "pwml", "pwmled", "sensor"],
  },
  {
    id: "rpi-pwm",
    topic: "PWM with RPi.GPIO",
    content:
      "pwm = GPIO.PWM(pin, frequency_hz); pwm.start(duty_cycle_percent) (0-100); pwm.ChangeDutyCycle(percent); pwm.ChangeFrequency(hz); pwm.stop(). Software PWM has jitter; for precise servo control use a hardware PWM chip or pigpio.",
    tags: ["pwm", "duty", "frequency", "gpio.pwm"],
  },
  {
    id: "rpi-pin-numbering",
    topic: "BCM vs BOARD numbering",
    content:
      "GPIO.BCM uses the processor's Broadcom pin numbers (e.g. GPIO17). GPIO.BOARD uses physical header positions (e.g. pin 11). Mixing the two schemes is a classic wiring bug — pick one and be consistent.",
    tags: ["bcm", "board", "numbering", "pinout", "wiring"],
  },
  {
    id: "rpi-i2c",
    topic: "I2C on the Pi",
    content:
      "Enable I2C with raspi-config. Use smbus2: bus = SMBus(1); bus.write_byte_data(addr, reg, value); bus.read_byte_data(addr, reg). Detect devices with 'i2cdetect -y 1'. Typical addresses: 0x27 (LCD), 0x48 (ADS1115), 0x76 (BME280).",
    tags: ["i2c", "smbus", "smbus2", "i2cdetect", "sensor"],
  },
  {
    id: "rpi-spi",
    topic: "SPI on the Pi",
    content:
      "Enable SPI with raspi-config. Use the spidev package: spi = spidev.SpiDev(); spi.open(0, 0); spi.max_speed_hz = 1000000; bytes = spi.xfer2([cmd, 0, 0]).",
    tags: ["spi", "spidev", "xfer", "mcp3008"],
  },
  {
    id: "rpi-serial",
    topic: "Serial (UART) on the Pi",
    content:
      "Use pyserial: import serial; ser = serial.Serial('/dev/serial0', 9600, timeout=1); ser.write(b'data'); line = ser.readline(). /dev/serial0 is the hardware UART alias. Disable the serial console in raspi-config to use it freely.",
    tags: ["serial", "uart", "pyserial", "/dev/serial0"],
  },
  {
    id: "rpi-filesystem",
    topic: "GPIO via sysfs (old style)",
    content:
      "Legacy: echo 17 > /sys/class/gpio/export; echo out > /sys/class/gpio/gpio17/direction; echo 1 > /sys/class/gpio/gpio17/value. Prefer RPi.GPIO or gpiozero on modern systems.",
    tags: ["sysfs", "/sys/class/gpio", "export", "legacy"],
  },
  {
    id: "rpi-cleanup",
    topic: "Cleanup and exits",
    content:
      "Call GPIO.cleanup() when the program ends so pins return to a safe state; use try/finally so cleanup runs even on errors. KeyboardInterrupt (Ctrl+C) is the usual exit for infinite-loop GPIO scripts.",
    tags: ["cleanup", "try", "finally", "keyboardinterrupt", "exit"],
  },
  {
    id: "rpi-temperature",
    topic: "Reading CPU temperature",
    content:
      "Read the SoC temperature from /sys/class/thermal/thermal_zone0/temp (millidegrees Celsius): with open('/sys/class/thermal/thermal_zone0/temp') as f: temp = int(f.read()) / 1000.",
    tags: ["temperature", "thermal", "thermal_zone0", "cpu"],
  },
];

const FALLBACK_SCRIPT = `# Generic Raspberry Pi starter: toggle an LED and read a button.
from time import sleep

try:
    from gpiozero import LED, Button
except ImportError:
    raise SystemExit("gpiozero is not installed: sudo apt install python3-gpiozero")

led = LED(17)
button = Button(2, pull_up=True)

for _ in range(10):
    if button.is_pressed:
        led.on()
    else:
        led.off()
    sleep(0.2)
`;

export class RaspberryPiCodingAgent extends BaseCodingAgent {
  constructor(options: { sandbox?: Sandbox; brain?: NeuralBrain; maxIterations?: number } = {}) {
    super({
      name: "raspberry-pi-agent",
      language: "python",
      knowledge: new KnowledgeBase({ entries: RPI_KNOWLEDGE }),
      sandbox: options.sandbox,
      brain: options.brain,
      maxIterations: options.maxIterations,
    });
  }

  protected override generate(task: string, hints: string[]): string {
    const snippet = matchSnippet(task, RPI_SNIPPETS);
    const header = commentHeader("python", this.name, task);
    const hintBlock = hints.length > 0 ? `# Debug notes: ${hints.join("; ")}\n` : "";
    const body = snippet ? snippet.code : FALLBACK_SCRIPT;
    return `${header}${hintBlock}${body}`;
  }

  protected override staticValidate(code: string): string[] {
    const issues = defaultStaticChecks(code);
    const lines = code.split("\n");
    lines.forEach((line, index) => {
      if (line.includes("\t")) issues.push(`Line ${index + 1}: tabs are not allowed in Python; use spaces.`);
    });
    return issues;
  }

  protected override async dynamicValidate(code: string): Promise<DynamicValidation | null> {
    // Run it — but a missing gpio lib means "can't verify on this host",
    // which is not a bug in the generated code.
    const run = await this.runViaSandbox("python", code);
    if (run && !run.ok && /ModuleNotFoundError|ImportError/.test(run.stderr)) return null;
    return run;
  }
}

export function buildRaspberryPiKnowledge(): KnowledgeBase {
  return new KnowledgeBase({ entries: RPI_KNOWLEDGE });
}
