# ForgeKit

A production-ready **TypeScript backend toolkit** you can embed in any TypeScript
app. Zero runtime dependencies. Ships with an agentic sandbox, self-debugging
coding agents with an agents council, TradingView lightweight-charts data
builders, CSV and PDF creators, advanced forex technical analysis, and a suite
of coding tools.

```
forgekit v1.0.0 · MIT · Node >= 18 · ESM
```

## Quick start

```bash
bun install           # or: npm install
bun run build         # compile dist/ (js + .d.ts)
bun test              # 117 tests across every module
```

Then import it:

```ts
import { Sandbox, JavaScriptCodingAgent, AgentsCouncil } from "forgekit";

const sandbox = new Sandbox({ concurrency: 4 });
const out = await sandbox.python("print(sum(range(100)))"); // "4950"

const agent = new JavaScriptCodingAgent();
const result = await agent.code("write a function that computes the fibonacci sequence");
// result.status === "pass"  (generated code was executed & self-tested)

const council = AgentsCouncil.swarm(agent, { count: 700 }); // 700 brains, one verdict
```

Subpath imports are also available: `forgekit/sandbox`, `forgekit/agents`,
`forgekit/charts`, `forgekit/csv`, `forgekit/pdf`, `forgekit/forex`,
`forgekit/coding`, `forgekit/core`.

## The Sandbox — `forgekit/sandbox`

Run **CMD, shell, bash, JavaScript and Python** from your backend, with:

- **Micro-kernels** — isolated, trackable execution units (`MicroKernel`,
  `KernelPool`) with bounded concurrency and a fair queue.
- **An agentic brain** (`SandboxBrain`) — every failed run is classified
  (timeout / output-limit / not-found / permission / syntax / runtime) with
  evidence and confidence, and `agenticRun()` retries with concrete fixes
  (e.g. raising the time limit, enlarging the output buffer).
- **Speed & performance boosters**:
  - `ExecutionCache` — memoizes identical runs (TTL + LRU eviction).
  - `NodeWorkerPool` — warm long-lived Node processes that execute JS modules
    without per-task process spawn cost.
  - `AdaptiveConcurrency` — measures latency and adjusts parallelism.

```ts
import { Sandbox } from "forgekit";

const sandbox = new Sandbox({ concurrency: 4, cache: true, warmWorkers: 2 });

await sandbox.shell("npm run build");          // host shell
await sandbox.bash("for i in 1 2 3; do echo $i; done");
await sandbox.cmd("dir /b");                   // Windows hosts
await sandbox.javascript("export default 40 + 2;");
await sandbox.python("print('hello from python')");

// Agentic: diagnose & retry with fixes
const report = await sandbox.agentic({ kind: "shell", payload: "sleep 999", options: { timeoutMs: 500 } });
// report.attempts[0].diagnosis.kind === "timeout" → retried with a bigger timeout

// Warm worker pool
const workerResult = await sandbox.runInWorker("export default 6 * 7;"); // { ok: true, result: "42" }
```

Every run returns a `ProcessResult`: `{ exitCode, stdout, stderr, durationMs,
timedOut, outputLimitExceeded, signal, command }`. Timeouts, output caps and
stdin injection are built in.

## Coding agents — `forgekit/agents`

Six domain agents, each with **its own brain** (a real neural network with
backpropagation + online skill learning), **its own knowledge base** (embedded
documentation + error patterns) and **debugging tools** (the debug loop:

generate → static-validate → run → diagnose → patch/regenerate → re-validate).

| Agent                    | Knowledge embedded                               | Debugging                       |
| ------------------------ | ------------------------------------------------ | ------------------------------- |
| `ArduinoCodingAgent`     | Sketch structure, pins, digital/analog, PWM, serial, I2C/SPI, timers, memory, compiler errors | setup/loop + brace checks, real `avr-gcc` compile when available |
| `RaspberryPiCodingAgent` | Python + GPIO (RPi.GPIO, gpiozero), PWM, I2C/SPI/UART, sysfs, common errors | runs under Python; missing GPIO lib → "unverified" |
| `CSharpCodingAgent`      | Program structure, types, LINQ, async, collections, CSxxxx error codes | real `dotnet build` when the SDK exists |
| `YamlCodingAgent`        | Structure, indentation, quoting, anchors, multi-line scalars | structural validator (indentation, key/value shape, quotes), `yamllint` when present |
| `JavaScriptCodingAgent`  | Syntax, async, Node ESM/CJS, error taxonomy | **executes the generated code** with Node and self-tests |
| `PythonCodingAgent`      | Syntax, data structures, exceptions, file I/O   | **executes the generated code** with the host interpreter |

```ts
import { PythonCodingAgent, AgentsCouncil } from "forgekit";

const agent = new PythonCodingAgent({ maxIterations: 5 });
const result = await agent.code("write a function that computes the fibonacci sequence");
// {
//   code: "...",           // generated, executed, verified
//   status: "pass",        // "pass" | "unverified" | "fail"
//   iterations: 1,         // debug-loop iterations used
//   diagnostics: [],       // what the debugger found
//   fixesApplied: [],      // fixes the debugger applied
//   confidence: 0.9,
//   report: ["Iteration 1: validation clean (pass)."],
// }
```

### Agents council — 700 agents, one verdict

`AgentsCouncil.swarm(base, { count })` spawns N clones of an agent — each with
an independently seeded brain and a distinct voting weight — deliberates the
same task, tallies a **weighted vote** on status and **elects the best**
implementation by score.

```ts
const base = new JavaScriptCodingAgent();
const council = AgentsCouncil.swarm(base, { count: 700, seed: 42 }); // instant
const verdict = await council.deliberate("write a fibonacci function");
// verdict.decision.status, verdict.decision.confidence, verdict.best.code
```

### Neural brains

`NeuralBrain` is a real feed-forward MLP (sigmoid, backprop, seeded init):

```ts
const brain = new NeuralBrain({ sizes: [2, 4, 1], seed: 7 });
brain.train(xorSamples, { epochs: 2000, learningRate: 0.5 });
brain.predict([1, 0]);   // ~1

brain.learn("lang:python", 0.2);   // online skill learning, clamped to [-1, 1]
brain.getSkill("lang:python");
```

## TradingView lightweight-charts — `forgekit/charts`

Dependency-free builders that produce the exact data shapes the
[`lightweight-charts`](https://www.npmjs.com/package/lightweight-charts)
package consumes:

```ts
import { buildChartPayload, indicatorsToOverlays } from "forgekit";

const payload = buildChartPayload(bars, indicatorsToOverlays(bars, [
  { id: "sma20", label: "SMA 20", values: sma20 },
  { id: "bb-upper", label: "BB Upper", values: bbUpper, color: "rgba(...)" },
]));
// payload.candles  → { time (seconds), open, high, low, close }[]
// payload.overlays → line/area/histogram series ready for addSeries()
```

Also: `resample()` (1m → 5m/1h/1d aggregation), `intervalToSeconds()`,
`tradeMarkers()` (backtest trades → chart markers), `toLineSeries()`.

## CSV creator — `forgekit/csv`

```ts
import { toCsv, parseCsv, CsvWriter, streamCsv } from "forgekit";

const csv = toCsv([{ symbol: "EURUSD", pip: 0.0001 }, { symbol: "USDJPY", pip: 0.01 }]);
// name,pip\nEURUSD,0.0001\nUSDJPY,0.01\n

parseCsv(csv);                 // records keyed by header
new CsvWriter({ columns: ["a", "b"] }).addRow({ a: 1, b: 2 }).toString();
await streamCsv(batches, writableStream);   // backpressure-aware streaming
```

Spec-compliant escaping (quotes, commas, newlines), custom delimiters,
delimiter sniffing, header-less parsing.

## PDF creator — `forgekit/pdf`

A dependency-free PDF 1.4 writer with a correct cross-reference table:

```ts
import { PdfDocument } from "forgekit";

const doc = new PdfDocument({ title: "Report", author: "ForgeKit" });
doc.text(50, 50, "Quarterly report", { size: 18, bold: true });
doc.line(50, 70, 300, 70);
doc.rect(50, 90, 200, 24, { fill: true, color: [120, 80, 40] });
doc.addPage();
await doc.saveToFile("report.pdf");
```

Helvetica / Helvetica-Bold / Helvetica-Oblique, colors, multi-page, A4/Letter/A5.

## Forex technical analysis — `forgekit/forex`

Advanced indicators implemented from scratch (all aligned `number | null`
series so they zip straight onto candles):

- `sma`, `ema`, `rsi` (Wilder), `macd`, `bollinger`, `atr`, `stochastic`,
  `adx` (+DI/-DI), `ichimoku` (tenkan/kijun/cloud/chikou), `donchian`,
  `slope` (linear regression)
- `pivotPoints` (classic / fibonacci / camarilla), `swingLevels`
  (support/resistance clustering)
- `detectCandlestickPatterns` — doji, hammer, shooting star, engulfing,
  morning/evening star, spinning top
- `analyzeSignals` — EMA cross + RSI + MACD + Bollinger + ADX → buy/sell/
  neutral with a score, strength and reasons
- `backtest(strategy, { commissionPct })` — trades, equity curve, and stats:
  return %, win rate, profit factor, max drawdown, Sharpe (approximation)
- `generateBars({ seed, drift, volatility })` — deterministic synthetic
  candles for demos and tests; `FX_PAIRS` catalogue with pip math
  (`toPips`, `roundToPip`)

```ts
import { generateBars, backtest, crossoverStrategy, analyzeSignals, rsi } from "forgekit";

const bars = generateBars({ count: 500, seed: 7, drift: 0.001 });
const result = backtest(bars, crossoverStrategy({ fast: 10, slow: 30 }));
console.log(result.stats); // { totalReturnPct, winRate, profitFactor, maxDrawdownPct, ... }
```

## Coding tools — `forgekit/coding`

- `diffLines` / `diffText` / `formatDiff` / `diffSummary` — LCS diffs
- `renderTemplate` — `{{var}}`, `{{#if}}…{{else}}…{{/if}}`, `{{#each}}` with
  `{{this}}`, `{{@index}}`, nested paths; `renderStrict` validates keys
- `analyzeCode` — language sniffing, lint heuristics, cyclomatic complexity,
  identifier extraction
- `generate` helpers — case converters, headers, boilerplate
- `snippets` — self-testing boilerplate libraries for all six agent domains
  with keyword task matching

## Architecture

```
src/
  core/      shared types, errors, events, logger, utils
  sandbox/   runner · micro-kernels · brain · boosters
  agents/    neural brains · knowledge · debugger · base agent · council · 6 domains
  charts/    lightweight-charts data builders
  csv/       writer, parser, streaming
  pdf/       dependency-free PDF writer
  forex/     indicators · patterns · signals · backtest · data
  coding/    diff · template · analyze · generate · snippets
tests/       one suite per module (bun test)
```

Zero runtime dependencies. Strict TypeScript (`strict`, `noUncheckedIndexedAccess`).
Everything is deterministic where it matters (seeded PRNGs, seeded brains,
stable hash keys).

## Testing

```bash
bun test
```

117 tests cover every module, including real process execution (Node, Python,
shell), a trained neural net, PDF byte-level xref validation, indicator math
against known textbook values, and full agent debug loops.

## License

MIT © ForgeKit Contributors
